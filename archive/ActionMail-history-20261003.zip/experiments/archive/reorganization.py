"""One-time, verified presentation reorganization. No inference or business edits."""
from pathlib import Path
import hashlib, json, shutil, zipfile
project=Path(__file__).resolve().parent
root=(project/'experiments').resolve()
assert root.is_relative_to(project.resolve())
archive=root/'archive'; archive.mkdir(exist_ok=True)
target=archive/'development-history.zip'
if target.exists(): raise SystemExit('Archive already exists; do not overwrite')
artifacts=root/'artifacts'
historical=[p for p in artifacts.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
historical += [root/name for name in ['README.md','STATUS.md','FINAL_PLAN.md','TWO_STAGE_PLAN.md']]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={p.relative_to(project).as_posix():digest(p) for p in historical}
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
    for p in historical: z.write(p,p.relative_to(project).as_posix())
    z.writestr('ARCHIVE_CONTENT_HASHES.json',json.dumps(hashes,indent=2))
with zipfile.ZipFile(target) as z:
    for name,expected in hashes.items():
        if hashlib.sha256(z.read(name)).hexdigest()!=expected: raise SystemExit('Archive verification failed: '+name)
for directory in ['code','data','results']:(root/directory).mkdir(exist_ok=True)
for p in root.glob('*.py'):shutil.move(str(p),str(root/'code'/p.name))
for name in ['tests','configs']:shutil.move(str(root/name),str(root/'code'/name))
shutil.move(str(artifacts/'core-final-c405d29-20261002'),str(root/'data/frozen-core'))
shutil.copyfile(artifacts/'stage1-approved-5usd-20261002.json',root/'code/configs/model-benchmark.json')
run=artifacts/'runs/stage1-20261002-complete'
report=run/'report.md'
body=report.read_text(encoding='utf-8')
# The report already embeds all raw examples, so keep only one maintained document.
body=body.replace('旧简表已保存为 report-summary-before-detailed-20261003.md。','历史过程文件统一归档于 archive/development-history.zip，不作为当前报告版本。')
body=body.replace('也可单独阅读 [原始回答实例](raw_answer_examples.md)。','所有原始回答实例已直接包含在本报告中。')
(root/'REPORT.md').write_text(body,encoding='utf-8')
results=root/'results/model-benchmark'; results.mkdir()
excluded={'report.md','report-original-arm-labels.md','report-summary-before-detailed-20261003.md','raw_answer_examples.md'}
result_hashes={}
for p in run.iterdir():
    if p.is_file() and p.name not in excluded:
        before=digest(p); shutil.move(str(p),str(results/p.name))
        assert digest(results/p.name)==before
        result_hashes[p.name]=before
shutil.move(str(artifacts/'runs/rules-final-c405d29-20261002'),str(root/'results/rules-baseline'))
# Keep old records byte-for-byte. Historical absolute paths resolve through the archive map.
mapping={'old_bundle':'experiments/artifacts/core-final-c405d29-20261002','new_bundle':'experiments/data/frozen-core',
         'old_results':'experiments/artifacts/runs/stage1-20261002-complete','new_results':'experiments/results/model-benchmark',
         'historical_paths':'Other experiments/artifacts paths are preserved inside archive/development-history.zip using original project-relative names.',
         'archive_sha256':digest(target),'verified_archived_files':len(hashes),'relocated_result_sha256':result_hashes,
         'note':'Original run metadata and raw observations were not rewritten. One active frozen core; past executable harness snapshots are compressed in the archive.'}
(archive/'index.json').write_text(json.dumps(mapping,indent=2)+'\n',encoding='utf-8')
for name in ['STATUS.md','FINAL_PLAN.md','TWO_STAGE_PLAN.md']:
    p=root/name
    # Already verified in archive; narrow explicit file deletion.
    assert hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.relative_to(project).as_posix()]
    p.unlink()
print(json.dumps({'verified_archived_files':len(hashes),'results_relocated':len(result_hashes),'archive_bytes':target.stat().st_size,'remaining_artifacts_to_remove':str(artifacts)},ensure_ascii=False))
