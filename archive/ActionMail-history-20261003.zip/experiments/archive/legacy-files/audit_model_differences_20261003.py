"""Read-only log audit and explicitly offline fence-only diagnostic. No inference."""
from pathlib import Path
from collections import Counter, defaultdict
from dataclasses import asdict
import json, sys, re, hashlib
root = Path(__file__).resolve().parents[1]
folder = root / 'artifacts/runs/stage1-20261002-complete'
bundle = root / 'artifacts/core-final-c405d29-20261002'
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def lines(p): return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s]
sys.path.insert(0, str(root / 'artifacts/protocol-freeze-20261002-b'))
from pipeline import verify_bundle, activate
verify_bundle(bundle); activate(bundle)
from actionmail.reasoning.multi_response import parse_multi_response
from actionmail.workflow.coverage import parse_plan
from actionmail.workflow.multi_pipeline import _validate
from actionmail.application.store import decode_email
rows, calls = lines(folder/'rows.jsonl'), lines(folder/'calls.jsonl')
config = read(folder/'config.json'); summary = read(folder/'summary.json'); ops = read(folder/'operations.json')
dataset = {c['case_id']: c for c in lines(bundle/'dataset.jsonl')}
generations = {g.get('response_id'): g for g in lines(folder/'generations.jsonl') if g.get('response_id')}
arms = {a['id']: a for a in config['arms']}
first_by_case = defaultdict(list)
for c in calls:
    if c['call'] == 1: first_by_case[c['case_id']].append(c)
first_context = []
for cid, group in first_by_case.items():
    fingerprints = {hashlib.sha256(json.dumps({k:v for k,v in c['transport']['request_payload'].items() if k!='model'},sort_keys=True).encode()).hexdigest() for c in group}
    first_context.append({'case_id':cid, 'models':len(group), 'distinct_payloads_without_model':len(fingerprints)})
diagnostics, model_stats = [], {}
fence = re.compile(r'\A\s*```(?:json)?\s*\n([\s\S]*?)\n```\s*\Z', re.IGNORECASE)
for arm, definition in arms.items():
    rr = [r for r in rows if r['arm']==arm]; cc = [c for c in calls if c['arm']==arm]
    repair_events = [e for r in rr for e in r['result']['repairs']]
    repairs = [c for c in cc if '\n\nVALIDATION FEEDBACK (untrusted prior reply and source excerpts):\n' in c['prompt']]
    repair_cost = sum((generations.get((c['transport'].get('response_json') or {}).get('id'),{}).get('data') or {}).get('total_cost',0) or 0 for c in repairs)
    probe_counts = Counter(); recovered_status = Counter(); raw_format = Counter()
    for c in cc:
        content = (c.get('reply') or {}).get('content','')
        match = fence.fullmatch(content)
        raw_format['whole_json_fence' if match else 'other'] += 1
        if not match: continue
        stage = 'planning' if c['system'].startswith('Plan external reading') else 'extraction' if c['system'].startswith('You identify all current next steps') else 'other'
        entry = {'arm':arm,'case_id':c['case_id'],'call':c['call'],'stage':stage,'is_repair':c in repairs,'raw_prefix':content[:35]}
        normalized = match.group(1)
        try:
            json.loads(normalized); entry['json_parses_after_fence_removal']=True
            if stage=='planning':
                email = decode_email(dataset[c['case_id']]['email'])
                selections = parse_plan(normalized, email.external_sources)
                entry['schema_passes_after_fence_removal']=True
            elif stage=='extraction':
                decision = parse_multi_response(normalized, require_explanation=True)
                entry.update(schema_passes_after_fence_removal=True, raw_status=decision.status)
                # Direct first extraction only; excludes plans/merges/retries and external cases.
                if c['call']==1 and not dataset[c['case_id']]['email'].get('external_sources'):
                    email = decode_email(dataset[c['case_id']]['email'])
                    validated, errors = _validate(email, decision, 3)
                    entry['offline_original_source_errors']=list(errors)
                    entry['raw_status_matches_gold']=decision.status==dataset[c['case_id']]['gold']['status']
                    entry['source_validated_status_matches_gold']=validated.status==dataset[c['case_id']]['gold']['status']
                    entry['diagnostic_scope']='Original-email evidence validation; not full workflow or semantic review.'
                    recovered_status['direct_first_extraction'] += 1
                    recovered_status['raw_status_matches'] += entry['raw_status_matches_gold']
                    recovered_status['source_validated_status_matches'] += entry['source_validated_status_matches_gold']
                    recovered_status['source_validation_passes'] += not errors
        except (ValueError, TypeError, KeyError) as exc: entry['normalization_error']=str(exc)
        probe_counts['fenced_calls'] += 1
        probe_counts['json_parses'] += entry.get('json_parses_after_fence_removal',False)
        probe_counts['schema_passes'] += entry.get('schema_passes_after_fence_removal',False)
        diagnostics.append(entry)
    provider = Counter((c['transport'].get('response_json') or {}).get('provider','unknown') for c in cc)
    finish = Counter(((c['transport'].get('response_json') or {}).get('choices') or [{}])[0].get('finish_reason','unknown') for c in cc)
    token_stats = Counter()
    for c in cc:
        usage=(c['transport'].get('response_json') or {}).get('usage') or {}
        token_stats['input_tokens'] += usage.get('prompt_tokens') or 0
        token_stats['output_tokens'] += usage.get('completion_tokens') or 0
        token_stats['reasoning_tokens'] += (usage.get('completion_tokens_details') or {}).get('reasoning_tokens') or 0
        token_stats['cached_input_tokens'] += (usage.get('prompt_tokens_details') or {}).get('cached_tokens') or 0
    model_stats[arm] = {'model_id':config['models'][definition['model']]['id'],
        'metrics':summary['arms'][arm], 'operations':ops['by_arm'][arm],
        'providers':dict(provider),'finish_reasons':dict(finish),'tokens':dict(token_stats),
        'repair_attempted_cases':sum(any(e.get('attempted') for e in r['result']['repairs']) for r in rr),
        'repair_outcomes':dict(Counter(e['outcome'] for e in repair_events)),
        'repair_initial_errors':dict(Counter(e['initial_error'] for e in repair_events)),
        'repair_stages':dict(Counter(e['stage'] for e in repair_events)),
        'quote_diagnostic_events':sum(bool(e.get('quote_diagnostics')) for e in repair_events),
        'repair_calls_detected_from_prompt':len(repairs),'repair_calls_legacy_flag':sum(bool(c.get('is_validation_repair')) for c in cc),
        'repair_billed_cost_usd':repair_cost,'repair_wall_ms':sum(c['wall_ms'] for c in repairs),
        'api_errors':dict(Counter(c['error'] for c in cc if c.get('error'))),
        'final_engineering_errors':dict(Counter(e for r in rr for e in r['result']['engineering_errors'])),
        'wrong_status_cases':[{'case_id':r['case_id'],'gold':r['gold']['status'],'prediction':r['result']['prediction']['status'],'reason':r['result']['prediction']['reason'],'errors':r['result']['engineering_errors']} for r in rr if r['result']['prediction']['status']!=r['gold']['status']],
        'fence_only_diagnostic':dict(probe_counts),'direct_first_extraction_fence_probe':dict(recovered_status),
        'categories':{cat:{'matched':sum(r['gold']['status']==r['result']['prediction']['status'] for r in rr if r['category']==cat),'n':sum(r['category']==cat for r in rr)} for cat in sorted({r['category'] for r in rr})}}
result={'scope':'Offline descriptive audit of the frozen 360-case/model run. No inference, no model-specific edits, no replacement of original scores.',
    'request_keys':dict(Counter(','.join(sorted(c['transport']['request_payload'])) for c in calls)),
    'parameter_pairs':dict(Counter(str((c['transport']['request_payload'].get('temperature'),c['transport']['request_payload'].get('max_tokens'))) for c in calls)),
    'first_call_context_parity':first_context,'models':model_stats,
    'counterfactual_limit':'Removing one whole-response Markdown fence only. Raw reply schema/evidence probes cannot recreate unexecuted downstream planning/extraction and are not a corrected benchmark.',
    'billing':read(folder/'billing.json')}
(folder/'model_difference_audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
(folder/'fence_only_diagnostics.jsonl').write_text(''.join(json.dumps(d,ensure_ascii=False)+'\n' for d in diagnostics),encoding='utf-8')
for arm, m in model_stats.items():
    print(arm,json.dumps({k:m[k] for k in ['repair_attempted_cases','repair_outcomes','repair_initial_errors','repair_stages','repair_calls_detected_from_prompt','repair_calls_legacy_flag','repair_billed_cost_usd','quote_diagnostic_events','fence_only_diagnostic','direct_first_extraction_fence_probe','tokens']},ensure_ascii=False))
print('First-call parity:',Counter(x['distinct_payloads_without_model'] for x in first_context))
