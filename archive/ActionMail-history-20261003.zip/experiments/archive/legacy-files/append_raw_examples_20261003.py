"""Expose actual final-answer text and API metadata; do not reproduce reasoning transcripts."""
from pathlib import Path
import json
folder=Path(__file__).resolve().parent/'runs/stage1-20261002-complete'
calls=[json.loads(s) for s in (folder/'calls.jsonl').read_text(encoding='utf-8').splitlines()]
names={'full_m03':'Gemini 3.5 Flash Lite','full_m04':'Gemini 3.8 Flash','full_m02':'GLM-5.3 Flash'}
selected=[('full_m03','N01',1),('full_m03','N01',2),('full_m04','N01',1),('full_m04','N01',2),('full_m04','E01',1),('full_m04','E01',2),('full_m04','E01',3),('full_m02','C11',1)]
out=['# 原始最终回答与失败现场', '',
'以下模型回答 content 按日志逐字展示，不改写、不补字段。API 元数据仅摘录明确列出的字段；缺失正文显示为 null，不用推理过程冒充最终回答。新分析没有付费调用。', '',
'## 代码围栏到底是什么', '',
'三个反引号是 Markdown 的代码块显示标记，后面的 json 只是显示语言标签。它们不属于 JSON。网页聊天中通常会把它渲染成漂亮的代码块，但这里接口实际返回的字符串包含这些字符。程序 json.loads 期待第一个非空字符是合法 JSON 的起始符号；碰到反引号立即拒收，所以报错 line 1 column 1 (char 0)。', '',
'两层区别：HTTP 接口的外层 JSON 正常；外层 message.content 里存放的模型回答，包了一层 Markdown，因此它本身不是直接可解析的 JSON。这次失败发生在内层回答解析，不能称为网络或外层接口 JSON 失败。', '',
'所有模型的文字提示都要求 Return only JSON，但没有使用接口的 response_format 强制格式，冻结解析器也没有移除这层展示标记。模型没有严格遵守格式要求；workflow 对可机械消除的包装问题也缺乏兼容，造成不必要的付费重试。', '',
'## 逐条原始回答', '',
'N01 的邮件正文是 “Looks great. I like it!”；标注为 no_action。E01 正文指向发票附件，附件要求批准 INV-104，标注为 action。C11 为包含地点问题和资料清单的邮件线程。']
records=[]
for arm,cid,num in selected:
 c=next(x for x in calls if x['arm']==arm and x['case_id']==cid and x['call']==num)
 raw=c['transport'].get('response_json') or {}; choice=(raw.get('choices') or [{}])[0]; msg=choice.get('message') or {}; usage=raw.get('usage') or {}
 metadata={'provider':raw.get('provider'),'request_max_tokens':c['transport']['request_payload']['max_tokens'],
 'finish_reason':choice.get('finish_reason'),'native_finish_reason':choice.get('native_finish_reason'),
 'prompt_tokens':usage.get('prompt_tokens'),'completion_tokens':usage.get('completion_tokens'),
 'reasoning_tokens':(usage.get('completion_tokens_details') or {}).get('reasoning_tokens'),
 'response_reported_cost_usd':usage.get('cost'),'wall_ms':c['wall_ms'],'local_error':c.get('error')}
 record={'model':names[arm],'case_id':cid,'call':num,'original_answer_content':msg.get('content'),'api_metadata_excerpt':metadata}
 records.append(record)
 out+=['',f"### {names[arm]} · {cid} · 第 {num} 次调用",'',
        '原始回答：','', '````text',msg.get('content') if msg.get('content') is not None else 'null','````','',
        '接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：','','```json',json.dumps(metadata,indent=2,ensure_ascii=False),'```']
out+=['', '## Gemini 的失败链，按实际回答解释', '',
'N01：Flash Lite 第一次已经写出正确的 no_action，但是开头/结尾都有围栏。解析器未进入 status 字段就报错。重试的回答仍有围栏，于是再次拒收，最终输出由系统回退成 needs_review。这不是模型把赞许邮件理解成任务。Flash 第一次也有围栏，但重试返回裸 JSON，才被接受。', '',
'E01：Flash 第一次规划有围栏，第二次规划修复为裸 JSON，用掉唯一修复；第三次任务提取已给出批准发票的 action，但又有围栏。各阶段共享一次修复，没有第二次机会，系统最终复核。正文和任务其实很短，失败来自串联的格式验证与预算规则。', '',
'## GLM 为什么短答案也会达到上限', '',
'这次请求的 max_tokens=2048 没有另外控制 reasoning。多数 OpenRouter provider 会把模型推理与最终回答合并计入输出上限。可能最终答案只需一两百 token，但模型在输出答案前已经使用了大量推理 token。官方说明明确包含 finish_reason=length、content 为空且推理仍收费的情况：[OpenRouter reasoning tokens 文档](https://openrouter.ai/docs/guides/best-practices/reasoning-tokens)。', '',
'C11 的事实是：接口返回 finish_reason=length、completion_tokens=2048、content=null，同时有大量推理输出；因此程序根本没有收到最终 JSON。请求未显式设置 reasoning，当前推理默认值不受实验统一控制。这应归类为输出/推理预算兼容失败，不能判为已经给出错误最终答案。', '',
'该条 provider 报告 reasoning_tokens=2069，竟然大于 completion_tokens=2048，两字段不完全自洽。保留原值并标注计数差异，不使用两者相减去杜撰可见输出长度，也不声称精确到 token 的消耗分配。可确认的行为依据是 length 和 content=null；原因与文档所述预算耗尽一致。', '',
'我的设计问题在于：以“最终 JSON 很短”为理由设置统一 cap，却没有单独校验各家的默认推理行为。这一设置既不能证明 GLM 能力差，也不足以支持公平的纯模型能力排名。', '',
'## 所有达到上限的调用', '',
'| 模型 | 案例 / 调用 | provider | 最终正文字符数 | completion tokens | reasoning tokens |',
'| --- | --- | --- | ---: | ---: | ---: |']
for c in calls:
 raw=c['transport'].get('response_json') or {}; choice=(raw.get('choices') or [{}])[0]
 if choice.get('finish_reason')!='length': continue
 msg=choice.get('message') or {}; usage=raw.get('usage') or {}
 out.append(f"| {names.get(c['arm'],c['model_requested'])} | {c['case_id']} / {c['call']} | {raw.get('provider')} | {len(msg.get('content') or '')} | {usage.get('completion_tokens')} | {(usage.get('completion_tokens_details') or {}).get('reasoning_tokens')} |")
text='\n'.join(out)+'\n'
(folder/'raw_answer_examples.md').write_text(text,encoding='utf-8')
(folder/'raw_answer_examples.json').write_text(json.dumps(records,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
report=folder/'report.md'
body=report.read_text(encoding='utf-8')
marker='\n## 10. 原始回答与格式/输出上限解释\n'
body=body.split(marker)[0]
report.write_text(body+marker+'\n以下附录给出逐字原始回答，避免只看分类统计无法理解问题。也可单独阅读 [原始回答实例](raw_answer_examples.md)。\n\n'+text,encoding='utf-8')
print('Saved eight raw final-answer examples and all output-limit events; report appendix added.')
