"""Complete the unchanged frozen matrix through separate, explicitly masked runs.

The frozen runner's reservation cap is deliberately pessimistic and does not
release unused reservations. Each new batch receives ONLY the remaining actual
USD 5 experiment budget. No core, prompts, decoding or frozen source is edited.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
FROZEN = ROOT / 'artifacts/protocol-freeze-20261002-b'
BUNDLE = ROOT / 'artifacts/core-final-c405d29-20261002'
ORIGINAL = ROOT / 'artifacts/runs/stage1-20261002-a'
OUTPUT = ROOT / 'artifacts/runs/stage1-20261002-complete'
CAP = 5.0


def read(path): return json.loads(path.read_text(encoding='utf-8'))
def lines(path): return [json.loads(s) for s in path.read_text(encoding='utf-8').splitlines() if s] if path.exists() else []
def dump(path, value): path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
def write_lines(path, values):
    with path.open('x', encoding='utf-8') as f:
        for value in values: f.write(json.dumps(value, ensure_ascii=False) + '\n')
def row_key(row): return row['arm'], row['case_id'], row['trial']


for line in (ROOT / '.env').read_text(encoding='utf-8-sig').splitlines():
    line = line.strip()
    if not line or line.startswith('#') or '=' not in line: continue
    name, value = line.split('=', 1); value = value.strip()
    if len(value) > 1 and value[0] == value[-1] and value[0] in ['"', "'"]: value = value[1:-1]
    name = name.strip().removeprefix('export ').strip()
    if name in ['OPENROUTER_API_KEY', 'OPENROUTER_MANAGEMENT_KEY']: os.environ[name] = value

manifest = read(FROZEN / 'freeze-manifest.json')
for name, expected in manifest['files'].items():
    if hashlib.sha256((FROZEN / name).read_bytes()).hexdigest() != expected:
        raise SystemExit('Frozen source mismatch: ' + name)
sys.path.insert(0, str(FROZEN))
from billing import Accounting
from pipeline import verify_bundle
verify_bundle(BUNDLE)
accounting = Accounting(os.environ['OPENROUTER_API_KEY'], os.getenv('OPENROUTER_MANAGEMENT_KEY'))
config = read(ROOT / 'artifacts/stage1-approved-5usd-20261002.json')
baseline = read(ORIGINAL / 'billing-baseline.json')
cases = lines(BUNDLE / 'dataset.jsonl')
arms = [a['id'] for a in config['arms']]
expected = {(arm, c['case_id'], 1) for c in cases for arm in arms}
sources = [ORIGINAL]
ledger_path = ROOT / 'artifacts/stage1-completion-ledger-20261002.json'
controller_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def observed_spend():
    snapshot = accounting.snapshot()
    if snapshot.get('key_usage_usd') is None:
        raise SystemExit('Actual usage unavailable; no new inference authorized by controller')
    counter = snapshot['key_usage_usd'] - baseline['key_usage_usd']
    if counter < -1e-9: raise SystemExit('Usage counter reset; stop')
    # Retain full reservations for any calls whose billed usage is unknown.
    conservative = 0.0
    for source in sources:
        for call in lines(source / 'calls.jsonl'):
            raw = (call.get('transport') or {}).get('response_json') or {}
            cost = raw.get('usage', {}).get('cost') if isinstance(raw, dict) else None
            conservative += cost if isinstance(cost, (int, float)) else call['reservation_usd']
    return max(counter, conservative), snapshot


for part in range(1, 9):
    completed = [r for source in sources for r in lines(source / 'rows.jsonl')]
    done = {row_key(r) for r in completed}
    if len(done) != len(completed): raise SystemExit('Duplicate completed observations; stop')
    pending = expected - done
    spend, snapshot = observed_spend()
    dump(ledger_path, {'sources': [str(s) for s in sources], 'completed': len(done),
         'expected': 360, 'observed_or_held_spend_usd': spend, 'total_cap_usd': CAP,
         'controller_sha256': controller_hash, 'frozen_manifest': str(FROZEN / 'freeze-manifest.json'),
         'updated_utc': datetime.now(timezone.utc).isoformat(),
         'policy': 'Case masks only; same frozen workflow. Prior completed observations are never rerun.'})
    print(f'Coverage {len(done)}/360; actual/held spend USD {spend:.6f}; ceiling USD 5.', flush=True)
    if not pending: break
    if CAP - spend < .10: raise SystemExit('Insufficient remaining global budget; results retained')
    first = next(c['case_id'] for c in cases if any((a, c['case_id'], 1) in pending for a in arms))
    missing_arms = tuple(a for a in arms if (a, first, 1) in pending)
    selected_cases = [c['case_id'] for c in cases if tuple(a for a in arms if (a, c['case_id'], 1) in pending) == missing_arms]
    batch = json.loads(json.dumps(config))
    batch['budget_usd'] = CAP - spend
    batch['arms'] = [{**a, 'selector': 'stability'} for a in config['arms'] if a['id'] in missing_arms]
    batch['stability_ids'] = selected_cases
    batch['continuation'] = {'original_run': str(ORIGINAL), 'completed_before': len(done),
        'selected_case_ids': selected_cases, 'global_usage_baseline': baseline,
        'global_total_cap_usd': CAP, 'previous_consumption_or_held_usd': spend,
        'note': 'Existing explicit-ID selector used only as a case mask; trial count remains one. Scientific matrix is the union of completed observations.'}
    config_path = ROOT / f'artifacts/stage1-remaining-{part}-20261002.json'
    if config_path.exists(): raise SystemExit('Batch config already exists; preserve history')
    dump(config_path, batch)
    output = ROOT / f'artifacts/runs/stage1-remaining-{part}-20261002'
    with (ROOT / f'artifacts/stage1-remaining-{part}-20261002-console.txt').open('x', encoding='utf-8') as log:
        result = subprocess.run([sys.executable, str(FROZEN / 'pipeline.py'), 'run', '--bundle', str(BUNDLE),
            '--config', str(config_path), '--approve-paid', '--output', str(output)], stdout=log, stderr=log, env=os.environ.copy())
    sources.append(output)
    new_rows = lines(output / 'rows.jsonl')
    if not new_rows: raise SystemExit('No completed analysis in the last batch; stop and inspect retained logs')
else:
    raise SystemExit('Batch limit reached; preserve all results')

if {row_key(r) for source in sources for r in lines(source / 'rows.jsonl')} != expected:
    raise SystemExit('Matrix incomplete; no complete benchmark created')
OUTPUT.mkdir(exist_ok=False)
all_rows, all_calls, analysis_calls, orphan_calls, all_events = [], [], [], [], []
for source in sources:
    rows = lines(source / 'rows.jsonl'); completed = {row_key(r) for r in rows}
    all_rows.extend({**r, 'source_run': str(source)} for r in rows)
    for c in lines(source / 'calls.jsonl'):
        record = {**c, 'source_run': str(source), 'analysis_completed_in_source': row_key(c) in completed}
        all_calls.append(record)
        (analysis_calls if row_key(c) in completed else orphan_calls).append(record)
    all_events.extend({**e, 'source_run': str(source)} for e in lines(source / 'events.jsonl'))
write_lines(OUTPUT / 'rows.jsonl', all_rows)
write_lines(OUTPUT / 'calls.jsonl', analysis_calls)
write_lines(OUTPUT / 'orphan_calls.jsonl', orphan_calls)
write_lines(OUTPUT / 'events.jsonl', all_events)
dump(OUTPUT / 'config.json', config)
dump(OUTPUT / 'billing-baseline.json', baseline)
audit = accounting.reconcile(OUTPUT, baseline, all_calls)
metadata = {'mode': 'live composite of disjoint completed observations', 'complete': True,
    'planned_analyses': 360, 'bundle': str(BUNDLE), 'bundle_sha256': read(ORIGINAL / 'run.json')['bundle_sha256'],
    'experiment_code': read(ORIGINAL / 'run.json')['experiment_code'],
    'started_utc': read(ORIGINAL / 'run.json')['started_utc'], 'ended_utc': datetime.now(timezone.utc).isoformat(),
    'paid_calls': len(all_calls), 'measured_usd': sum(c.get('cost_usd') or 0 for c in all_calls),
    'reserved_usd': sum(c['reservation_usd'] for c in all_calls), 'budget_usd': CAP,
    'source_runs': [str(s) for s in sources], 'controller_sha256': controller_hash,
    'source_rows_sha256': {str(s): hashlib.sha256((s / 'rows.jsonl').read_bytes()).hexdigest() for s in sources},
    'budget_interruption_calls_without_completed_analysis': len(orphan_calls),
    'cost_policy': 'Comparison tables use completed-analysis bills; global actual consumption includes any budget-interrupted orphan calls.',
    'note': 'Preserved incomplete source runs. Composite coverage means all 360 distinct frozen case/model/trial observations exist; no observation copied as a fresh trial.'}
dump(OUTPUT / 'run.json', metadata)
from scoring import score_run
score_run(OUTPUT)
print('Completed benchmark:', OUTPUT, flush=True)
print('Actual total USD:', audit['key_usage_delta_usd'], 'reconciled:', audit['reconciled'], flush=True)
