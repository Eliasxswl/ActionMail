# Model benchmark first, selected-model ablations second

2 October 2026. Owner requested a broader model comparison before selecting two or three models for ablations. This protocol supersedes the earlier two-model, 310-analysis proposal in `FINAL_PLAN.md`. No paid inference has been executed and no models were chosen from observed experiment scores.

## Shared fixed conditions

Use `artifacts/core-final-c405d29-20261002`, Git HEAD c405d29, manifest SHA-256 `a90d9238047679fa9b1654ccdaf7c2cf0de8fd16a827ac7d20fdbcb5f1395c58`. Dataset, recipient definitions, original attachment/snapshot bytes, prompts, output schema, file/coverage limits, one-repair allowance and evaluation policies remain fixed. The 60 cases are a reused development/regression suite, not independent held-out data.

The frozen API requests the same temperature/output cap for all models. Some providers do not list/support all parameters, and reasoning defaults differ. Record actual resolved model, usage, repair/error behavior and stage-level trace. This is an operational model substitution comparison under a common client, not proof of identical decoding across architectures.

## Stage one: seven models, complete workflow

| Key | Model | Family | Price tier | Input / output USD per million text tokens |
| --- | --- | --- | --- | ---: |
| m01 | GPT-6 Luna | OpenAI | Low | 0.10 / 0.50 |
| m02 | Gemini 2.5 Flash Lite | Google | Low | 0.10 / 0.40 |
| m03 | Qwen3 8B | Qwen | Low | 0.117 / 0.455 |
| m04 | DeepSeek V3.2 | DeepSeek | Middle | 0.28 / 0.42 |
| m05 | GPT-4.1 Mini | OpenAI | Middle | 0.40 / 1.60 |
| m06 | Claude Haiku 4.5 | Anthropic | Middle | 1.00 / 5.00 |
| m07 | Claude Sonnet 4.6 | Anthropic | High | 3.00 / 15.00 |

All IDs, prices and listed parameters were verified against the [public OpenRouter catalog](https://openrouter.ai/api/v1/models). Original selected entries/timestamp are in `artifacts/multimodel-pricing-20261002.json`. Tiers describe listed price, not measured performance. Similar price does not establish similar capability; the experiment will determine actual outcomes.

Each model runs the **full workflow on all 60 cases once**: 420 model analyses. Keep the already completed same-bundle rule baseline as an offline reference. No per-model prompt tuning, special-case parser, retry budget or hand-picked case subset is introduced. Run order is round-robin by case: model 1-7 on the first case, then the next case. This distributes elapsed-time effects but does not remove routing/provider variability.

Measure strict and approved-outcome classification/counts, original quote provenance, supported non-null deadlines separately from nulls, review burden/appropriateness, semantic task correctness/omissions, failures/repair incidence, model calls/tokens, actual recorded wall/call time, measured usage-based cost. Slice by case category and origin. Semantic judgments must be attributed; pending fields are not treated as Pass. A single trial per case does not measure repeatability; repeated trials are in stage two.

Config: `configs/stage1-model-benchmark-proposed.json`. Command after owner approval:

```powershell
python experiments/pipeline.py run --bundle experiments/artifacts/core-final-c405d29-20261002 --config experiments/configs/stage1-model-benchmark-proposed.json --approve-paid --output experiments/artifacts/runs/stage1-NEWID
python experiments/pipeline.py screen --run experiments/artifacts/runs/stage1-NEWID
```

`screen` presents evidence and eligibility, not an automatic winner. Budget/model API failures remain visible; incomplete runs must not be ranked as complete seven-model comparisons.

## Selection rule written before results

Select two or three **distinct** models with recorded reasons:

1. Quality leader: semantic task correctness and omissions when reviewed, then classification/count quality and operating failures. Do not select on exact quotes alone.
2. Cost-efficient candidate: cheapest measured cost among quality-eligible models; initial classification screening thresholds are precision >=90%, recall >=90%, no model API failures and exact final quote checks. Passing these does not establish semantic eligibility.
3. Optional informative contrast: a different family/price tier or a meaningfully different failure profile. Its inclusion should explain whether mechanisms behave differently, rather than just add another near-identical score.

If roles yield duplicate models, choose the next informative distinct contrast or keep two. If no model meets the target, report that finding rather than lower thresholds or relabel; explicitly justify any diagnostic selection below the target. Record ties and whether semantic review was complete at selection. No model performance/ranking claim is final while semantic review is pending. Do not tune prompts on stage-one failures before stage two; that would change the experimental question and require a new version.

Comparison on the same tuned set makes model selection and subsequent ablations exploratory/developmental; there is no newly independent test set merely because different models ran. A future unused, independently labelled set would be needed for a stronger generalization claim.

## Stage two: same ablations on selected models

Generate only after a complete stage-one run, choosing two or three model keys and a reason:

```powershell
# Example syntax, not a preselection:
python experiments/pipeline.py stage2-config --benchmark-run experiments/artifacts/runs/stage1-NEWID --model m01 --model m02 --reason "Record the actual quality/cost/contrast rationale" --output experiments/configs/stage2-NEWID.json
```

The generator verifies the completed benchmark, model membership and full 60-case result per selected model. It records the parent run/hash and semantic review state. The runner rejects a stage-two bundle that differs from stage one. Model keys here are examples; selection has not happened.

| Arm, per selected model | Analyses |
| --- | ---: |
| Fresh full-workflow reference | 60 |
| One-call prompt baseline | 60 |
| Remove historical thread | 12 |
| Disable external reading, retain inventory | 17 |
| Read all declared sources within limits | 17 |
| Disable repair, retain validation | 60 |
| Eight predefined cases x three fresh trials | 24 |
| **Total per selected model** | **250** |

Two selected models: 500 analyses; three: 750. Complete both-stage totals: **920 or 1,170 model analyses**, plus the offline rule reference. Each analysis can use multiple API calls. Selection is adaptive by design; disclose the selection rule. The same subsets and arm definitions are used across selected models, so mechanism-by-model interactions can be compared without changing the question for each model.

Fresh full references are paired to each model's ablations in the same stage-two run. Stage-one rows are retained as history, not copied as fresh trials. Do not attribute every full versus one-call difference to one mechanism: the one-call baseline removes several components. Read-all changes source-selection strategy and planning overhead; make that clear in cost comparisons. Safety validation is never bypassed in delivered outputs; isolated mechanism tests study its effect without releasing unchecked actions.

## Costs and paid scope

Repricing the saved 60-case input/output totals at the seven verified prices gives a rough **stage-one usage estimate of USD 0.892**. This assumes similar token/call behavior and ignores unknown additional charges; stronger/verbose models or extra repairs can differ. This is a forecast, not actual experiment spending.

The runner reserves worst-case input-byte overhead and full output allowance before every request and keeps failed-call reservations. Proposed **stage-one reservation cap: USD 10**. This cap is larger than expected billed usage so conservative reservations do not prematurely exhaust it; it halts future requests in the harness, not provider billing itself. Paid scope/price assumptions must be accepted before execution. The earlier USD 1 two-model proposal does not authorize this expanded stage.

Stage-two cost and reservation cap must be recomputed **after selection**, using actual stage-one tokens, repair behavior and selected model rates. Its generated USD 10 value is a placeholder, not authorization or a finished estimate. Do not fund expensive-model ablations based on the cheap-model mean.

## Pipeline status

Candidate catalog verified; stage-one matrix/config frozen as proposals; scheduling, screening and stage-two generation are implemented in the separate experiment module. Application source, original gold and original saved experiments are unchanged. Real model comparison and selection remain pending; no scientific results are invented from scripted tests.
