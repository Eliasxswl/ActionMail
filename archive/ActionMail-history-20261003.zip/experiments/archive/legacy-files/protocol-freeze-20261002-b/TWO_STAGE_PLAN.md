# Model benchmark first, selected-model ablations second

2 October 2026. Owner requested a broader model comparison before selecting two or three models for ablations. This protocol supersedes the earlier two-model, 310-analysis proposal in `FINAL_PLAN.md`. No paid inference has been executed and no models were chosen from observed experiment scores.

## Two equally important experiments: model robustness and agent mechanisms

Model benchmarking and mechanism ablation are both key experiments. Benchmarking asks whether the same workflow delivers acceptable quality, generation speed and cost across suitable model families/price tiers, and where model substitution causes harmful errors, unnecessary review, slow responses or extra repair calls. It also provides the evidence for choosing two or three backbones for the ablations.

Ablation asks how context organization, selective source reading, evidence validation, bounded repair and safe review contribute to supported task extraction. Compare each selected model's full-versus-ablation changes on matched cases and inspect model-by-mechanism interactions. To evaluate whether the workflow mitigates model sensitivity, compare cross-model quality spread and harmful failure patterns for the full workflow versus the one-call baseline on the identical selected models/cases. Low spread can mean uniformly poor quality, so always report absolute correctness and failures alongside agreement. Baseline removes multiple mechanisms; it cannot isolate a single cause.

Neither agent superiority nor reduced model sensitivity is a pre-established finding. Both are hypotheses to evaluate. These exploratory contrasts on a reused development set cannot uniquely separate all agent and model effects. Report quality, speed and cost jointly; identify Pareto tradeoffs rather than select solely by accuracy or listed price. Model API/provider routing and nonidentical reasoning defaults remain confounders.

## Shared fixed conditions

Use `artifacts/core-final-c405d29-20261002`, Git HEAD c405d29, manifest SHA-256 `a90d9238047679fa9b1654ccdaf7c2cf0de8fd16a827ac7d20fdbcb5f1395c58`. Dataset, recipient definitions, original attachment/snapshot bytes, prompts, output schema, file/coverage limits, one-repair allowance and evaluation policies remain fixed. The 60 cases are a reused development/regression suite, not independent held-out data.

The frozen API requests the same temperature/output cap for all models. Some providers do not list/support all parameters, and reasoning defaults differ. Record actual resolved model, usage, repair/error behavior and stage-level trace. This is an operational model substitution comparison under a common client, not proof of identical decoding across architectures.

## Stage one: six currently listed models, complete workflow

| Key | Model ID | Family | Price tier | Input / output USD per million text tokens |
| --- | --- | --- | --- | ---: |
| m01 | openai/gpt-6-luna | OpenAI | low | 0.10 / 0.50 |
| m02 | z-ai/glm-5.3-flash | Z.ai | low | 0.15 / 0.50 |
| m03 | google/gemini-3.5-flash-lite | Google | low | 0.30 / 2.50 |
| m04 | google/gemini-3.8-flash | Google | middle | 0.75 / 3.75 |
| m05 | openai/gpt-6.1-sol | OpenAI | middle | 2.00 / 10.00 |
| m06 | anthropic/claude-sonnet-5.5 | Anthropic | middle | 2.00 / 10.00 |

Revised after current web/catalog research on 2 October 2026. DeepSeek V3.2 and Qwen3 8B are excluded at the owner's request. GPT-4.1 Mini, Gemini 2.5 Flash Lite and the older Claude candidates are replaced by current alternatives. Full public-catalog evidence is saved in `artifacts/current-catalog-20261002.json`; per-model page URLs and catalog creation timestamps are recorded in the config. Catalog timestamps are listing dates, not universally vendor launch dates. Earlier proposal/config and pricing artifacts remain as superseded history; model keys were reassigned before any paid results existed.

Selection architecture: Luna versus GLM Flash provides a near-price low-cost family comparison; GPT-6.1 Sol versus Sonnet 5.5 is an exactly equal listed input/output price comparison. Google Lite versus Flash, OpenAI Luna versus Sol provide within-family cost/quality tradeoffs. The primary matrix covers four families. Price does not establish equal performance. No measured task ranking is available.

The newest Google announcement, [Gemini 4 Argon](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-4-argon/), is rolling out to trusted cyber defenders and is absent from this catalog. It is not an executable candidate yet. Latest aliases, pro modes and batch routes are not used. The owner capped the primary comparison at Sonnet 5.5: Grok 4.7 and Opus 5.5 are removed, and higher-cost flagship extensions are outside the agreed scope.

Each model runs the **full workflow on all 60 cases once**: 360 model analyses. Keep the already completed same-bundle rule baseline as an offline reference. No per-model prompt tuning, special-case parser, retry budget or hand-picked case subset is introduced. Run order is round-robin by case: model 1-6 on the first case, then the next case. This distributes elapsed-time effects but does not remove routing/provider variability.

Measure strict and approved-outcome classification/counts, original quote provenance, supported non-null deadlines separately from nulls, review burden/appropriateness, semantic task correctness/omissions, failures/repair incidence, model calls/tokens, actual recorded wall/call time, billed cost reconciled against before/after consumption counters. Slice by case category and origin. Semantic judgments must be attributed; pending fields are not treated as Pass. A single trial per case does not measure repeatability; repeated trials are in stage two.

Config: `configs/stage1-model-benchmark-proposed.json`. Command after owner approval:

```powershell
python experiments/pipeline.py run --bundle experiments/artifacts/core-final-c405d29-20261002 --config experiments/configs/stage1-model-benchmark-proposed.json --approve-paid --output experiments/artifacts/runs/stage1-NEWID
python experiments/pipeline.py screen --run experiments/artifacts/runs/stage1-NEWID
```

`screen` presents evidence and eligibility, not an automatic winner. Budget/model API failures remain visible; incomplete runs must not be ranked as complete six-model comparisons.

## Selection rule written before results

Select two or three **distinct** models with recorded reasons:

1. Quality leader: semantic task correctness and omissions when reviewed, then classification/count quality and operating failures. Do not select on exact quotes alone.
2. Cost-efficient candidate: cheapest reconciled billed cost among quality-eligible models; initial classification screening thresholds are precision >=90%, recall >=90%, no model API failures and exact final quote checks. Passing these does not establish semantic eligibility.
3. Optional informative contrast: a different family/price tier or a meaningfully different failure profile. Its inclusion should explain whether mechanisms behave differently, rather than just add another near-identical score.

If roles yield duplicate models, choose the next informative distinct contrast or keep two. If no model meets the target, report that finding rather than lower thresholds or relabel; explicitly justify any diagnostic selection below the target. Record ties and whether semantic review was complete at selection. No model performance/ranking claim is final while semantic review is pending. Do not tune prompts on stage-one failures before stage two; that would change the experimental question and require a new version.

Comparison on the same tuned set makes model selection and subsequent ablations exploratory/developmental; there is no newly independent test set merely because different models ran. A future unused, independently labelled set would be needed for a stronger generalization claim.

## Stage two: same ablations on selected models

Generate only after a complete stage-one run, choosing two or three model keys and a reason:

```powershell
# Example syntax, not a preselection:
python experiments/pipeline.py stage2-config --benchmark-run experiments/artifacts/runs/stage1-NEWID --model m01 --model m02 --reason "Record the actual quality/cost/contrast rationale" --output experiments/configs/stage2-NEWID.json
```

The generator verifies the completed benchmark, model membership and full 60-case result per selected model. It records the parent run/hash and semantic review state. The runner rejects a stage-two bundle that differs from stage one. Model keys here are examples; selection has not happened.

| Arm, per selected model | Analyses |
| --- | ---: |
| Fresh full-workflow reference | 60 |
| One-call prompt baseline | 60 |
| Remove historical thread | 12 |
| Disable external reading, retain inventory | 17 |
| Read all declared sources within limits | 17 |
| Disable repair, retain validation | 60 |
| Eight predefined cases x three fresh trials | 24 |
| **Total per selected model** | **250** |

Two selected models: 500 analyses; three: 750. Complete both-stage totals: **860 or 1,110 model analyses**, plus the offline rule reference. Each analysis can use multiple API calls. Selection is adaptive by design; disclose the selection rule. The same subsets and arm definitions are used across selected models, so mechanism-by-model interactions can be compared without changing the question for each model.

Fresh full references are paired to each model's ablations in the same stage-two run. Stage-one rows are retained as history, not copied as fresh trials. Do not attribute every full versus one-call difference to one mechanism: the one-call baseline removes several components. Read-all changes source-selection strategy and planning overhead; make that clear in cost comparisons. Safety validation is never bypassed in delivered outputs; isolated mechanism tests study its effect without releasing unchecked actions.

## Costs and paid scope

Repricing the saved 60-case input/output totals at the six verified prices gives a rough **stage-one usage estimate of USD 0.987**. This assumes similar token/call behavior and ignores unknown additional charges; stronger/verbose models or extra repairs can differ. This is a forecast, not actual experiment spending.

The runner reserves worst-case input-byte overhead and full output allowance before every request and keeps failed-call reservations. Proposed **stage-one reservation cap: USD 10**. This cap is larger than expected billed usage so conservative reservations do not prematurely exhaust it; it halts future requests in the harness, not provider billing itself. Paid scope/price assumptions must be accepted before execution. The earlier USD 1 two-model proposal does not authorize this expanded stage.

Stage-two cost and reservation cap must be recomputed **after selection**, using actual stage-one tokens, repair behavior and selected model rates. Its generated USD 10 value is a placeholder, not authorization or a finished estimate. Do not fund expensive-model ablations based on the cheap-model mean.

## Quote-match repair as an explicit mechanism

The frozen core triggers bounded repair after original-evidence validation failure. Lexical matching supplies candidate source quotes, similarity, high-similarity flags, critical number/negation differences, and uniqueness diagnostics. These are not calibrated confidence scores and never authorize fuzzy acceptance. Every email shares one model repair allowance across planning, segment extraction and merge; exhausted/prompt-budget retries are skipped with a reason. Do not add another automatic network retry layer.

Keep this behavior enabled in every stage-one full workflow. The existing `no_repair` stage-two arm disables the repair opportunity but retains final evidence validation and safe review. Log initial validation errors, original and corrected replies, quote diagnostics, stage, attempted/skipped flag, outcome (validated, validation_failure, api_failure or budget skip), and the turn linking back to its initial response. Aggregate trigger rate, validated correction rate, failed/skipped events, incremental calls/time/tokens and incremental actual billed cost. A validated correction passes the contract/evidence checks; semantic correctness is separately reviewed. Do not equate lexical similarity with semantic confidence.

## Observability, actual billing and timing

Every live call is a numbered turn (one API invocation). Logs use arm/case/trial/call and turn_id. `events.jsonl` records starts and case completions; unfinished starts expose interruptions. `rows.jsonl` stores predictions, gold, reads, plans, coverage, validation and repair events, evidence and replies. Inputs remain in the frozen dataset; actually submitted prompts are in `calls.jsonl`. The experiment-only observed transport retains the frozen inference request contract, output cap, timeout and parsing. No application or frozen bundle code is modified, and no Authorization headers or API keys are written to logs.

OpenRouter's [usage accounting](https://openrouter.ai/docs/cookbook/administration/usage-accounting) returns native token details and `usage.cost`, the amount charged to the account. The [generation endpoint](https://openrouter.ai/docs/api/api-reference/generations/get-request-&-usage-metadata-for-a-generation) supplies `total_cost`, `latency`, `generation_time`, provider and native/cache/reasoning token records. Fetch those records after inference so extra audit requests do not enter model-response timing. Raw generation metadata are in `generations.jsonl`; each turn is joined by response ID and its case/arm/trial/call identity.

Primary total actual consumption is the **after-minus-before cumulative usage counter**, not token count times a price. Record the current API key's `usage` via [GET /key](https://openrouter.ai/docs/api/api-reference/api-keys/get-current-api-key) at run start, immediately before/after every live turn, and after post-run bill retrieval. This API-key delta gives a narrower accounting scope than whole-account balance. If an optional management key is configured through `OPENROUTER_MANAGEMENT_KEY`, also query [GET /credits](https://openrouter.ai/docs/api/api-reference/credits/get-remaining-credits): save total usage, purchased credits and remaining balance. Management credentials are not required for ordinary `/key` accounting; only numeric accounting fields are persisted from key/credits responses.

Compute and retain (1) key usage delta, (2) account total-usage delta when available, (3) balance decrease and credits-added delta, and (4) sum of per-generation bills. Topups can change balance without changing spending, so remaining balance alone is insufficient. Per-request `generation.total_cost` (fallback: response `usage.cost`) attributes actual reported charges to models/cases/repair turns. Compare those sums with the cumulative counter delta; never divide a contaminated account delta arbitrarily among models. An isolated experiment key/window is needed for experiment-only attribution, as concurrent usage can affect even a key's counter. Per-turn counter deltas are provisional when accounting settles asynchronously.

`billing-baseline.json` stores the baseline; `billing.json` stores final observed counters, differences, billed-call coverage, reconciliation gap and status. A run that cannot capture its baseline key usage stops before paid inference. Missing records, negative/reset counters or reconciliation gaps stay visible/pending rather than replaced with estimates. The read-only `reconcile --run PATH` command queries bills/counters again without new inference and archives earlier billing/generation observations. Because a later delta includes any intervening use, keep the key isolated until reconciliation completes. Token-rate estimates and conservative reservations remain forecasts/control values only and are never presented as final actual cost.

Timing remains measurable even when server fields are missing: use the local monotonic end-minus-start interval for every completion and case, while retaining UTC start/end timestamps for cross-checks. Export OpenRouter-reported latency and generation time separately, with missing fields left unavailable. API audit time is retained separately and subtracted from inference/case wall time; inclusive wall time is also saved. No server timing field is silently relabelled as TTFT. Non-streaming local measurements do not provide first-token time or pure decode speed.

Derived `case_metrics.csv` and `turn_metrics.csv` connect quality with timing, tokens, bills, quote diagnostics, repair outcomes and extra repair costs. `operations.json` reports per-arm mean/P50/P95/max case and call time, server timing, billed costs and missing denominators, failures, repair rates/overhead and actual-consumption reconciliation. `cross_model_cases.csv` compares case-level outcomes separately from correctness. Semantic review remains attributed in its own CSV/summary. Report both quality/speed/cost and selected-model paired ablations, model sensitivity and representative traces. No model comparison or measured expenditure is inferred from scripted engineering fixtures.

## Pipeline status

Revised current candidate catalog verified; stage-one matrix/config frozen as proposals; scheduling, screening and stage-two generation are implemented in the separate experiment module. Application source, original gold and original saved experiments are unchanged. Real model comparison and selection remain pending; no scientific results are invented from scripted tests.
