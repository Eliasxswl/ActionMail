# ActionMail experiments

Current owner-directed protocol: **[two-stage model benchmark and selected-model ablations](TWO_STAGE_PLAN.md)**. The fixed original arm matrix below documents the initial implementation; the two-stage protocol supersedes its model/count proposal.

This is an independent experiment module at the **workspace root**, beside `ActionMail/` and `data/`. It does not edit, monkey-patch or import the live application during a run. A preparation step copies the current core and normalizes the selected dataset into a hash-verified local bundle. The harness remains separate, so the experiment asks about a specific frozen implementation rather than whichever code another chat is editing now.

Discuss with the owner in Chinese; source/docs stay English. Core experiments are required; real Gmail/Calendar connectivity is optional. No private-mail transmission or paid inference is implied by preparing a bundle or running an offline check.

## Architecture

```mermaid
flowchart LR
    A[Live core and approved inputs] --> B[Prepare immutable bundle]
    B --> C[Frozen runtime + canonical dataset + hashes]
    D[Versioned protocol and arm config] --> E[Plan case/trial matrix]
    C --> E
    E --> F[Independent runner]
    F --> G[Rules / scripted smoke / authorized API]
    G --> H[Append raw rows and call traces]
    H --> I[Common metrics and paired slices]
    H --> J[Original-source human review]
    J --> K[Semantic task matching]
    I --> L[Report and demo evidence]
    K --> L
```

| File / directory | Responsibility |
| --- | --- |
| `pipeline.py` | Snapshot, plan, execute, score and review CLI; immutable run directories |
| `engine.py` | Thin frozen-core adapters, independent budget accounting, scripted mechanism checks |
| `scoring.py` | Classification, paired comparisons, slices, repeatability and attributed semantic review |
| `configs/core.json` | Frozen experimental conditions, arm definitions, trial IDs and explicit pricing |
| `tests/test_pipeline.py` | Isolation, tamper, paired scoring, budget, repair and ablation checks |
| `artifacts/` | Local runtime/data snapshots, results and reviewer worksheets; excluded from Git |

Dependencies: Python 3.10+ and the frozen core's dependencies, currently pypdf. Use the same Python/pypdf versions when comparing runs; preparation records both. No new framework or installation is necessary in this workspace. No app server, OAuth, Gmail or Calendar is used.

After preparing a bundle and its sibling smoke bundle, run the harness tests:

```powershell
$env:ACTIONMAIL_EXPERIMENT_BUNDLE = 'E:/NTU Learn/PE6201/End_Course_project/experiments/artifacts/core-VERSION'
python -m unittest discover -s experiments/tests -v
```

Without a prepared bundle the pure scoring tests run and frozen-core adapter tests are explicitly skipped. Do not report skipped checks as passed.

## Experimental layers

| Layer | Arm | Factor / question | Current normalized cases |
| --- | --- | --- | ---: |
| Baselines | `rules` | Existing deterministic body/subject keyword rule; one generic task | 60 |
| Baselines | `prompt_only` | One structured-output call using available email/thread; no external reads, repair or segmented merge | 60 |
| Reference | `full` | Frozen full workflow: context, selective reading, evidence validation, one repair | 60 |
| Ablation | `no_thread` | Remove historical thread only; retain latest headers/body and external inventory | 12 |
| Ablation | `no_external` | Disable external reading only; retain inventory/dependency signals and thread | 17 |
| Ablation | `read_all` | Replace model source selection with deterministic read-all; retain file/source/coverage limits | 17 |
| Ablation | `no_repair` | Keep validation but exhaust the one-repair allowance before processing | 60 |
| Model substitution | `comparison_model` | Same full workflow with one explicitly chosen comparison model | 60 |
| Repeatability | `stability` | Eight preselected cases, three isolated trials each | 24 |

Total: **370 analyses, of which 60 are offline rules and 310 require model inference**. Each analysis may use several API calls. Relevant subsets are based only on frozen input presence (`thread`, `external_sources`), never observed failures. Comparator results are sliced to the same case IDs/trials. Do not compare 17-case aggregate rates with the full 60-case rate.

This expanded matrix supersedes the earlier 144-analysis proposal in `ActionMail/docs/core_experiments.md`; no earlier paid approval is assumed. That document's proposed quality gates still apply.

`prompt_only` is an architectural baseline with several absent mechanisms, not a single-factor ablation. `read_all` changes reading strategy: it removes planning calls and may encounter irrelevant damaged material; disclose both when interpreting cost/resolution. `no_thread` assesses contextual information as a whole, not a separate claim about historical-header formatting. Segmentation/merge remain unchanged in these ablations. A segmentation ablation is deliberately not fabricated by silently truncating inputs; propose it separately if warranted.

No arm disables evidence validation for user-facing output. The mechanism experiment observes raw inputs to the validator and final accepted outcomes in an isolated environment. The harness invokes private core functions only for explicit repair injection/one-call validation; it records their frozen hashes. An incompatible future core signature should fail visibly; do not adapt it silently mid-experiment.

## Run the pipeline

From `E:/NTU Learn/PE6201/End_Course_project` (substitute an available Python executable for `python`):

```powershell
# 1. Capture once after the code owner agrees the experimental version is ready.
python experiments/pipeline.py prepare --output experiments/artifacts/core-VERSION

# 2. Inspect the matrix. No key access or network/model calls.
python experiments/pipeline.py plan --bundle experiments/artifacts/core-VERSION

# 3. Offline real-input rule baseline.
python experiments/pipeline.py run --bundle experiments/artifacts/core-VERSION --arm rules --output experiments/artifacts/runs/rules-VERSION

# 4. Isolated evidence/repair mechanism checks. No paid calls.
python experiments/pipeline.py mechanism --bundle experiments/artifacts/core-VERSION --output experiments/artifacts/runs/mechanism-VERSION

# 5. Scripted engineering check of the runner/core boundary.
python experiments/pipeline.py smoke-bundle --bundle experiments/artifacts/core-VERSION
python experiments/pipeline.py run --bundle experiments/artifacts/core-VERSION-smoke --arm full --arm no_repair --arm prompt_only --scripted --output experiments/artifacts/runs/smoke-VERSION

# 6. Recompute derived scores without inference; preserve reviewer edits.
python experiments/pipeline.py score --run experiments/artifacts/runs/rules-VERSION
python experiments/pipeline.py review-score --run experiments/artifacts/runs/rules-VERSION

# Inspect full local source material for semantic review; never calls a model.
python experiments/pipeline.py inspect --bundle experiments/artifacts/core-VERSION --case-id E01
```

Paid mode requires owner authorization plus `--approve-paid`, an environment key, explicit model IDs and verified positive prices in a copied config. `core.json` deliberately leaves prices/comparison ID unset. Choose the comparison model and record a current price source/date in the config before approval. No default fallback model is substituted. Keys are never stored in configs or traces.

```powershell
# Example only: run after the owner approves THIS frozen matrix and budget.
python experiments/pipeline.py run --bundle experiments/artifacts/core-VERSION --config experiments/configs/approved-VERSION.json --approve-paid --output experiments/artifacts/runs/core-VERSION
```

Select arms by repeating `--arm`; paired scores clearly mark missing comparator rows if the reference is absent. For a combined paired report, execute the comparator and experimental arms in one run. Each trial uses a fresh client; no model reply cache or retries across trials. The core still shares one repair allowance across stages within one email.

There is no automatic resume. Interrupted runs are preserved and scored as incomplete; use a fresh run ID and record the repetition. Existing bundles/run directories cannot be overwritten. Never execute any model arm with an unlabelled fake response: scripted mode is restricted to the separate smoke dataset and report headings identify it as engineering evidence.

## Data contract and provenance

Preparation embeds recipient, dates, original body/thread, external inventory, snapshots and actual attachment bytes (base64) in `dataset.jsonl`. It carries existing gold, approved alternatives, origin and original source hashes. Original manifests are retained as `source_registry/` evidence, not reinterpreted as a new held-out dataset. This local normalized dataset is sufficient for subsequent execution without the original working tree/corpus. Do not publish the generated bundle before checking redistribution rights.

Runtime copies must match before/after preparation; references must remain stable during normalization. Manifest checks run before execution, including detection of unexpected Python modules. Git HEAD alone is insufficient: per-file hashes record uncommitted changes. The frozen code copied on 2 October is an experiment snapshot, not a released version. The final experimental snapshot should be prepared again when optimization is complete; keep earlier artifacts.

Any future independent set must supply the canonical case fields and receive labels before inference. A new bundle needs the same hash manifest, an explicit data role and reviewer provenance; there is deliberately no automatic relabel/split command. The tuned 60 must never be renamed held-out. Tests and smoke fixtures are not added to the model evaluation denominator.

## Measurements

`rows.jsonl` stores final outputs, raw replies, usage/latency, actual reads, selection, repairs and coverage. `calls.jsonl` additionally stores the actual public-input model prompts, including failed requests. `run.json` stores bundle/config/harness hashes, exact run mode, completion status and budget use. `summary.json` contains per-arm metrics, category/origin slices, paired comparisons and repeated-trial agreement; `report.md` is a readable table.

Strict action recall counts review/error on an action gold as a miss. Accepted C11 alternatives are a separate joint status/count metric; they do not silently inflate strict precision/recall. Single-action scalar deadline matches are split into non-null versus null. Multitask deadline assignment and task meaning need semantic matching. Literal quote matches prove source provenance only; quote-free engineering failure reviews are not represented as evidence-backed substantive judgments. Stable status/count may still be consistently wrong.

`semantic_review.csv` is blank on creation and never overwritten by rescoring. Review original full source material in the bundle, not only cited quotes. Fill reviewer identity, yes/no/na criteria and expected/proposed/matched task counts (one-to-one semantic matching against pre-fixed references). `review-score` validates that gold/predictions were not edited and produces a separate `semantic_summary.json`. Missing judgments stay pending. Software cannot verify reviewer identity, independence or semantic accuracy; disclose AI assistance and owner review rather than inventing human Pass labels.

## Budget and failures

Before each real call, reserve a conservative input-byte/token allowance plus the frozen client's output-token cap at declared prices. Stop the whole run before a request exceeds the remaining reservation or per-email cap. Failed/unknown-usage calls retain their reservation; do not assume they are free. Recorded `measured_usd` is a usage-based estimate, not confirmed billing. If reported usage exceeds assumptions, halt and inspect. Model/tokenizer/pricing mismatch, provider fees or hidden charges can invalidate estimates; this is not provider-side billing enforcement. Configure an account spending limit if a strict financial cap is required. No paid run is executed in this implementation task.

## Acceptance and communication

Use the proposed project gates in `ActionMail/docs/core_experiments.md`: classification, semantic task precision/recall, supported dates, evidence, safe review, bounded execution, repeatability and reproducibility. Those targets were proposed after the saved development run and must not be called predeclared for historical results. Final report/video must identify the same bundle/commit, distinguish new inference from saved traces, and acknowledge tuned data and synthetic cases. Gmail/Calendar do not determine core acceptance.

Lecture rationale and exact local page references: `ActionMail/docs/course_relevance.md`. Build report tables from this experiment module's results, rather than copying earlier version scores across differing contracts.


## Detailed observability

Model benchmarking and paired mechanism ablation are both key experiments. See `TWO_STAGE_PLAN.md` for the current six-model quality/speed/cost protocol and the model-sensitivity hypothesis. Each scored run now exports `operations.json`, `case_metrics.csv`, `turn_metrics.csv` and `cross_model_cases.csv`, alongside original case/call JSONL and attributed semantic review. Live calls preserve full request payloads, response text/JSON, usage details and finish reasons via a separate observed transport with the same frozen request parameters. `events.jsonl` exposes case/call starts and case completions, including interruptions. No authorization headers are logged. Case inputs are referenced by frozen bundle and case ID. Each turn is one API invocation.

Speed includes response and case wall time distributions; first-token time is unavailable in non-streaming mode, and output token/s is end-to-end rather than pure decoding throughput. Missing cost and incomplete cases remain explicit. Provider-reported cost is kept separate from usage-based estimates and conservative reservations. `score` regenerates derived tables for old runs without changing raw logs or reviewer worksheets; fields absent from old transport traces remain unavailable.


## Actual spend reconciliation and quote repair

Actual spend is captured as before/after cumulative OpenRouter usage deltas, reconciled against per-generation `total_cost` (fallback `usage.cost`), not token-rate estimates. An optional `OPENROUTER_MANAGEMENT_KEY` adds whole-account usage/credit snapshots; ordinary `/key` counters work with the inference key. Keep an experiment key isolated during inference and settlement. `billing-baseline.json`, `billing.json` and `generations.jsonl` preserve observed accounting. A missing baseline stops before paid inference; missing/delayed bills and mismatches remain pending. `python experiments/pipeline.py reconcile --run PATH` performs read-only reconciliation and preserves earlier observations, without inference.

Local monotonic request/case intervals remain available without server timing; generation metadata add server latency/generation time when available. Accounting network overhead is excluded and retained separately. Validation-repair turns are linked to prior replies with original quote diagnostics, and summaries include validated/failed/skipped repairs and incremental actual billed costs. Lexical similarity is not calibrated confidence or fuzzy approval. See `TWO_STAGE_PLAN.md` for full accounting/repair rules.
