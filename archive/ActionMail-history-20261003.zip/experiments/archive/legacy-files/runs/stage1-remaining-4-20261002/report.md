# Experiment results

Mode: live. Complete: True.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| full_m03 | 1 | 1/1 | N/A | N/A | 100.0% |
| full_m04 | 1 | 1/1 | N/A | N/A | 100.0% |
| full_m05 | 1 | 1/1 | N/A | N/A | 100.0% |
| full_m06 | 1 | 1/1 | N/A | N/A | 100.0% |

## Speed and cost

| Arm | Case P50 / P95 ms | Calls | Known billed USD | Missing bill calls | Billed complete |
| --- | ---: | ---: | ---: | ---: | --- |
| full_m03 | 2585.07 / 2585.07 | 2 | 0.001478 | 0 | True |
| full_m04 | 13140.03 / 13140.03 | 2 | 0.006811 | 0 | True |
| full_m05 | 3789.51 / 3789.51 | 1 | 0.001335 | 0 | True |
| full_m06 | 2970.24 / 2970.24 | 1 | 0.005920 | 0 | True |

Actual consumption is measured by before/after usage counters and reconciled against per-generation billed costs. Token-rate estimates remain budget forecasts only.
API-key usage delta USD: 0.0014777999999999736. Account usage delta USD: None. Balance decrease USD: None.
Generation bills reconciled: False. Gap USD: -0.003101250000000026.
Counter delta is observed actual consumption in this time window. Concurrent use can contaminate attribution; isolated key required for experiment-only attribution.

Per-case and per-call details: case_metrics.csv, turn_metrics.csv, operations.json; original logs: rows.jsonl, calls.jsonl, events.jsonl.
TTFT is unavailable with non-streaming requests. Speed includes transport/queueing; token/s is end-to-end, not decode throughput.
See operations.json for denominators, token totals, repair incidence, incomplete-case calls, provider-reported costs and cross-model case agreement.

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
