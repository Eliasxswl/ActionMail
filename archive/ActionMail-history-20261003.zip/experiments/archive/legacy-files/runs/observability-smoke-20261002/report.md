# Experiment results

Mode: scripted engineering. Complete: True.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| prompt_only | 3 | 3/3 | 100.0% | 100.0% | 33.3% |
| full | 3 | 3/3 | 100.0% | 100.0% | 33.3% |
| no_repair | 3 | 3/3 | 100.0% | 100.0% | 33.3% |

## Speed and cost

| Arm | Case P50 / P95 ms | Calls | Known estimated USD | Unknown-cost calls | Cost complete |
| --- | ---: | ---: | ---: | ---: | --- |
| prompt_only | 0.16 / 0.17 | 0 | 0.000000 | 0 | False |
| full | 0.18 / 0.26 | 0 | 0.000000 | 0 | False |
| no_repair | 0.13 / 0.15 | 0 | 0.000000 | 0 | False |

Per-case and per-call details: case_metrics.csv, turn_metrics.csv, operations.json; original logs: rows.jsonl, calls.jsonl, events.jsonl.
TTFT is unavailable with non-streaming requests. Speed includes transport/queueing; token/s is end-to-end, not decode throughput.
See operations.json for denominators, token totals, repair incidence, incomplete-case calls, provider-reported costs and cross-model case agreement.

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
