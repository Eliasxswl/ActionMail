# 六模型横评：结果、失败原因、公平性与消融选型

更新：2026-10-03。实验于新加坡时间 2026-10-02 23:29 完成。六模型各 60 案例，共 360 个独立模型/案例观察。本文分析既有日志，无新增模型调用，也未更改冻结业务代码、提示词、解析器或原始分数。

## 结论与适用范围

当前结果支持：在这套冻结 ActionMail workflow、OpenRouter 路由与参数配置下，Luna 的运行性价比最好，Sol 分类表现相同，Sonnet 同样具备较好的可用性。它不支持“GPT 家族的理解能力远胜 Google / GLM”。Google 的主要损失来自输出格式和跨阶段重试预算，GLM 还受到推理输出预算与服务商路由的影响。

对“是否专门适配 GPT”的回答：审查未发现按 GPT / Gemini / Claude 名称分支的推理或解析逻辑；60 个案例的首轮请求除 model 字段外逐字一致。不过，项目原开发默认模型为 Luna，60 案例明确曾用于开发调参，严格 JSON 解析和单次共享修复又恰好更适合本次 GPT 的输出习惯。因此，不能仅凭同一提示词宣称设计已达到家族中立，也不能排除开发过程中的隐性适配。此前报告没有把这个限制说清楚。

推荐后续主消融使用 **Luna + Sonnet**，分别代表低成本可用方案与另一个家族的可用方案；Sol 作为同家族性能/价格参照已在横评中保留，暂不占第三个消融名额。GLM / Google 需要单独的兼容性诊断，不能把其当前流程失败当作能力淘汰依据。完整任务语义复核仍未完成，主消融选择目前是建议，尚未启动。

## 1. 实验测量的是什么

- 输入：相同 60 个开发/回归案例，27 action、23 no_action、10 needs_review。包含邮件上下文、外部来源、真实附件、长内容和限制/恶意内容。不是独立盲测集。
- 冻结：Git c405d29；相同输入、标注、原始附件/网页快照、收件人、提示词、schema、读取限制和评分规则。
- 执行：按案例轮换六模型；中断后仅补跑未完成模型/案例。每案例一个正式 trial，不能据此估计稳定性或统计显著性。
- 指标：状态正确不等于任务语义正确；任务数相同不等于任务完整；原文引文匹配不等于证据支持结论。人工语义评分仍为空。
- action recall：真实 action 被转人工复核也算漏检，体现端到端业务损失。合法的需要复核与系统报错后的回退须分开解释。

## 2. 状态、速度和实际成本

耗时为单案例本地墙钟时间，包含规划、提取、合并和修复调用，扣除了只读账单查询开销；仍含网络和排队。费用为正式完成案例的逐请求实际账单，不是 token 单价估算。

| 模型 | 严格状态正确 | 允许标注分歧后的状态/数量匹配 | action 精确率 / 召回率 | 复核比例 | P50 / P95 秒 | 60 案例账单 USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6 Luna | 59/60 | 60/60 | 96.4% / 100.0% | 15.0% | 3.99 / 8.72 | 0.012339 |
| GLM-5.3 Flash | 51/60 | 51/60 | 100.0% / 81.5% | 31.7% | 23.29 / 54.89 | 0.056702 |
| Gemini 3.5 Flash Lite | 10/60 | 10/60 | 不可计算 / 0.0% | 100.0% | 2.73 / 3.41 | 0.093015 |
| Gemini 3.8 Flash | 42/60 | 43/60 | 89.5% / 63.0% | 40.0% | 14.73 / 23.57 | 0.523299 |
| GPT-6.1 Sol | 59/60 | 60/60 | 96.4% / 100.0% | 15.0% | 4.04 / 11.61 | 0.190289 |
| Claude Sonnet 5.5 | 58/60 | 59/60 | 96.3% / 96.3% | 16.7% | 2.97 / 7.61 | 0.475764 |

“允许标注分歧”仅使用实验前已有的 accepted_outcomes。C11 同时允许保守复核与一个回答地点的动作；不是为本次 GPT 结果修改答案。严格评分和允许结果都公开。

本实验前后 key usage 差值 **1.344801303 USD**，5 USD 总额度剩余 **3.655198697 USD**。595 条已知 generation 账单合计与该差值一致到浮点精度；另有 1 条 generation 记录缺失，完整审计仍标记 pending。中断时还有未收到返回的请求，其可能扣费包含在总体计数窗口内。比较表只统计完成案例，不能把它与含中断开销的实验总费用混为一谈。

Luna 与 Sol 的状态分数一致，但当前账单 Sol 约为 Luna 的 15.4 倍；Sonnet 约为 Luna 的 38.6 倍，P50 更低。Flash 标价较低但实际流程费用高于 Sonnet，不能用目录单价替代实际完成任务成本。Flash Lite 的低耗时主要来自早期失败/转复核，不能解释为同等任务质量下速度最快。

## 3. 分类别结果：差距在哪个环节扩大

| 案例类别 | 数量 | Luna | GLM | Flash Lite | Flash | Sol | Sonnet |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 无任务 | 15 | 15/15 | 14/15 | 0/15 | 15/15 | 15/15 | 15/15 |
| 显式请求 | 15 | 15/15 | 15/15 | 4/15 | 14/15 | 15/15 | 15/15 |
| 上下文/归属 | 10 | 9/10 | 8/10 | 3/10 | 9/10 | 9/10 | 8/10 |
| 外部内容 | 10 | 10/10 | 6/10 | 0/10 | 0/10 | 10/10 | 10/10 |
| 真实附件 | 4 | 4/4 | 3/4 | 1/4 | 1/4 | 4/4 | 4/4 |
| 长内容 | 2 | 2/2 | 1/2 | 0/2 | 1/2 | 2/2 | 2/2 |
| 混合链接 | 2 | 2/2 | 2/2 | 1/2 | 1/2 | 2/2 | 2/2 |
| 限制/恶意内容 | 2 | 2/2 | 2/2 | 1/2 | 1/2 | 2/2 | 2/2 |

关键读法：GLM 的显式请求仍为 15/15，但在上下文、外部信息和长内容中下降。Flash 的无任务案例为 15/15、显式请求为 14/15，外部内容却为 0/10；这种断崖首先应检查多阶段机制，不应直接判成阅读能力消失。Flash Lite 所有最终结果都为 needs_review，10/60 是恰好与复核标注相同，不是 10 次正常任务提取成功。

## 4. 格式、修复、输出预算：将失败机制拆开

| 模型 | 调用数 | 触发修复的案例 | 修复成功 / 失败 | 因共享次数已用完而跳过 | 达到输出上限的调用 | 修复实际费用 USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6 Luna | 76 | 0/60 | 0 / 0 | 0 | 0 | 0.000000 |
| GLM-5.3 Flash | 110 | 34/60 | 31 / 3 | 4 | 8 | 0.016110 |
| Gemini 3.5 Flash Lite | 120 | 60/60 | 0 / 60 | 0 | 0 | 0.048971 |
| Gemini 3.8 Flash | 136 | 60/60 | 57 / 3 | 16 | 5 | 0.218346 |
| GPT-6.1 Sol | 76 | 0/60 | 0 / 0 | 0 | 0 | 0.000000 |
| Claude Sonnet 5.5 | 77 | 1/60 | 1 / 0 | 0 | 0 | 0.012984 |

修复成功指当次结果通过验证，不等于最终整条 workflow 成功。例如规划修复成功后，提取仍可能失败。所有阶段共享每邮件一次修复，表中跳过次数是事件数，不是新增模型请求。

### Google：围栏 JSON 与跨阶段放大

Flash Lite 的 120/120 条回复均被最外层 Markdown JSON 围栏包裹。Frozen parser 直接 json.loads，不会先移除围栏；每个案例都耗费一次修复，但修复输出仍有围栏，全部失败。43 个案例在提取阶段失败，17 个带外部来源的案例在阅读计划阶段已经失败。

Flash 的 60/60 案例都触发修复，57 次修复当次成功。但 17 个外部来源案例先在规划阶段触发修复，其中 16 个随后在提取阶段再次格式失败，修复预算已用完。例 E01：规划带围栏 → 规划修复为裸 JSON → 读取附件 → 提取再次带围栏 → skipped_retry_budget → 最终 needs_review。日志中的提取原始内容实际上已列出 approve invoice 的动作，不能将最终漏检解释为“没有理解附件”。

这是通用 workflow 的缺陷：它把可机械处理的格式包装问题与原文证据纠错一起消耗同一个昂贵的 LLM 修复预算。冻结实验保留这个行为以避免中途调参，但报告必须将其作为产品兼容性损失披露。

### GLM：格式损失之外还有推理预算与路由

GLM 共 110 次请求，34 案例触发修复；31 次修复成功，2 次在修复调用中 API 正文缺失，1 次仍未通过验证。共有 8 次 finish_reason=length，其中 5 次没有可用正文，最后安全回退人工复核。这不是普通任务语义判断错误。

GLM 日志合计 completion_tokens=91,455，其中 reasoning_tokens=77,777；Flash 分别为 100,735 / 81,955。相同 2048 输出 cap 没有控制“可见回答 + 隐藏推理”的实际分配。请求也没有显式 reasoning 设置，默认推理行为没有做到可比较。不能因为统一参数值就宣称各家获得同等有效输出预算。

GLM 的 110 次请求由 12 个 provider 标签承接，包括 Together、Relace、SiliconFlow 等；速度/超限现象可能受到路由影响，单次实验无法把服务商和模型贡献拆开。其他模型本次分别是 OpenAI、Google，以及 Sonnet 的 Claude Platform on AWS。当前结论应以“请求模型 + 实际路由”表述。

### 原文匹配修复：目前直接证据有限

只有 GLM 与 Sonnet 各 1 个事件具有非空 quote_diagnostics。Sonnet 在 C12 首次引用了并非原文的 “CHASE - READY TO EXECUTE ASAP!”；没有找到原文候选，但模型修复后通过验证。GLM 在 S02 忽略了原邮件的软换行，诊断给出相似度 0.9959、来源唯一且没有关键数字差异的候选；候选不会自动接受，随后修复请求达到输出上限而没有正文，最终复核。它展示了原文匹配诊断确实进入重试链，但不证明本次修复成功。整体修复收益大多来自格式。Luna、Sol 无修复事件，不代表机制对它们无价值，只表示这一次运行没有触发。需要 no_repair 配对消融和机制注入，才能量化证据修复的因果作用。

## 5. 不花钱的格式诊断：证明混杂存在，而非重写成绩

对所有模型采用同一个离线转换：仅当整个回复是一个 Markdown 代码围栏时，删除最外层围栏；不改 JSON 字段、任务、引文、提示词或正文。用冻结 schema 重新检查既有回复，没有重新调用模型。

| 模型 | 完整围栏回复 | 去围栏后可解析 JSON | 通过对应冻结 schema |
| --- | ---: | ---: | ---: |
| GPT-6 Luna | 0 | 0 | 0 |
| GLM-5.3 Flash | 36 | 36 | 35 |
| Gemini 3.5 Flash Lite | 120 | 120 | 118 |
| Gemini 3.8 Flash | 73 | 73 | 73 |
| GPT-6.1 Sol | 0 | 0 | 0 |
| Claude Sonnet 5.5 | 0 | 0 | 0 |

在不含外部来源、首轮直接提取且去围栏后 schema 合格的子集中，Flash Lite 41 条里 36 条状态与标注相同，41 条均通过冻结原邮件证据验证；Flash 42 条里 40 条原始状态匹配，证据验证后为 39 条。该子集有格式和阶段筛选，分母与正式 60 案例不同，不能与主表直接排排名。它足以否定“Flash Lite 的 10/60 主要证明理解能力差”这种解释，同时保留了仍然存在的语义分歧。

规划 schema 能解析不代表规划语义和证据正确；阅读计划修复可能改变后续读取，离线转换没有重放那些未执行的后续调用。因此 **不生成所谓“修正后 60 案例准确率”**。原始成绩始终保留。逐条诊断见 fence_only_diagnostics.jsonl。

## 6. 具体案例：语义差异与系统失败不能混计

| 案例 | 输入/标注要点 | 观察 | 含义 |
| --- | --- | --- | --- |
| N01 | “Looks great. I like it!”；无任务 | Flash Lite 裸内容实际写 no_action，但两次围栏导致最终复核；Flash 修复后正确 | 纯格式失败足以造成巨大总分差 |
| N03 | “FYI. sj”；无任务 | GLM 正常返回复核，认为转发内容未给出而无法判断；其余可用模型返回无任务 | 真正的缺失信息政策/保守程度分歧，不是解析失败 |
| E01 | 附件要求 Alex 批准发票并给出日期 | Flash 已读附件、原始提取中已有动作，但共享修复耗尽；Flash Lite 规划就失败 | 多阶段格式损失，不能归因于附件理解 |
| A18 | 要提交表格，但发件人不确定税表还是供应商表；应复核 | Flash 正常通过格式验证却输出“提交讨论过的表格”；其他可用模型复核 | 存在真实语义过度确定，兼容修复不会解决它 |
| C10 | “we are waiting to hear from Darrell”；标注需要回应 | Luna / Sol / GLM / Flash 提出回应；Sonnet认为具体下一步不明确而复核 | Sonnet 在上下文义务判断更保守；需检查原线程，不能自动认定更大模型更准确 |
| C11 | “Where do you sit?” + 资料清单；严格 gold 为复核，预先允许一个回答动作 | Luna / Sol / Sonnet / Flash 提出回答地点；严格评分扣一分，允许结果匹配 | 标注敏感性；不得把这一个分差当模型能力排序 |
| S04 | workbook 三项任务，包括 confirm projector availability | Luna / Sol / Sonnet 都取出三项，但都使用 perform_task；gold 的第三项是 answer_question | 状态/数量满分仍可能掩盖动作类型差异，语义复核不可省略 |

这些案例只是日志级问题分析，不是已完成的全量语义评分。未对 360 行完成任务单位匹配、承诺强度、证据支持与截止日期复核。

## 7. 公平性审计：确认的事实与仍未解决的风险

| 维度 | 日志/源码证据 | 解释与限制 |
| --- | --- | --- |
| 首轮输入一致 | 60/60 案例各六模型首轮 payload 去掉 model 后相同 | 无按模型增加首轮上下文；后续上下文因模型规划/修复而分叉，是被测行为 |
| 参数一致 | 所有 595 条正式调用均只有 model/messages/temperature/max_tokens；temperature=0、max_tokens=2048 | 相同参数并不控制默认推理、tokenizer、服务商适配后的行为 |
| 代码分支 | 冻结运行时代码检索只发现 UI 默认模型 Luna；未发现按家族分支的推理/解析 | 未发现显式家族优惠，不等于消除了开发数据与输出习惯的偏向 |
| 输出约束 | 没有请求 response_format 或 structured_outputs；靠文字要求 JSON，使用同一严格 parser | 跨家族兼容不足；提示要求已给出，但自动包装应作为接口问题单独评估 |
| 修复公平 | 每邮件、所有阶段共享一次，所有模型相同 | 表面相同却会被格式错误占满，未充分隔离格式与原文纠错 |
| 推理预算 | 日志有 reasoning tokens，但请求未显式控制 | 长推理模型可能在返回正文前耗尽 cap，影响速度、费用及成功率 |
| provider | 未固定 provider，GLM 多 provider | 不能区分模型和服务部署差异 |
| 开发数据偏向 | 文档记录 60 案例已用于开发调参；默认开发模型为 Luna | 可存在对 Luna 的隐性适配；必须新增未参与开发、独立标注案例验证泛化 |
| 缓存/成本 | Luna cached input=63,612；Sol=62,496；Google/Sonnet本次为0 | 当前实付账单真实，但共享长系统提示的暖缓存优势不等于冷启动部署价格。应单列缓存，不能做估算替换 |
| 单次实验 | 每案例一个 trial，样本仅60 | 一分差不是稳健排名；重复实验只测一致性，仍不替代独立测试集 |

预算只对整个实验约束，所有模型跑同样 60 案例，无按成功率提前淘汰；中断后补齐完整矩阵。费用、原始失败、修复和暂停记录全部保留。

## 8. 后续消融选型与建议的兼容性补充实验

### 主消融：Luna + Sonnet，固定原 workflow

Luna：低成本、无需格式修复，在本套数据上状态召回率 100%，适合测量线程、外部读取、规划和修复是否改变任务解决率。Sonnet：另一个家族，状态召回率 96.3%，本次仅一个引文修复，对上下文义务更保守，能检查机制收益是否跨家族成立。两者均达到预先 action precision / recall ≥90% 的候选条件。

Sol：与 Luna 同家族、相同状态错误 C11、相同任务数量表现，暂时缺少足够额外差异支持完整第三份消融；若语义复核揭示遗漏/承诺强度不同，可再讨论加入。

GLM：当前召回率 81.5%，不满足效果主消融门槛；若加入只能明确作为“兼容与失败机制诊断模型”，不能悄悄降低门槛。Google：在原 pipeline 中失败高度集中于格式/共享重试，直接做深消融容易得到“每组都失败”的无信息结果。暂缓它们的效果消融不等于判定其模型能力不合格。

主消融保持原有矩阵：完整方案、one-call prompt baseline、无线程、无外部读取、read-all、无修复以及预先指定案例的重复运行。完整方案需要 fresh run 作为同批配对参考，不把横评观察冒充新 trial。完整语义复核完成后才锁定模型；本报告未启动付费消融。

### 单独的通用兼容性协议 V2：建议，尚未实施

先隔离两个因素，不针对任何单一模型改提示词：
1. **格式因素**：所有模型统一仅移除整个回复的外层代码围栏，仍严格验证 schema、动作限制、原文引文和安全回退。用现有围栏诊断验证转换边界后，再在预先定义的相同案例上运行独立新协议；不能覆盖冻结结果。
2. **输出预算因素**：先只提高所有模型相同的输出 cap，保持提示、格式策略、推理设置不变，比较 finish_reason、正文成功率、时间、reasoning tokens 和实际费用。若再实验显式推理设置，需要单独记录各家参数能力，并承认相同 reasoning_effort 文字值不必代表相同计算量。
3. **部署因素**：GLM 若继续做速度结论，固定可用 provider 或至少按 provider 分层。固定路由会改变所测配置，必须另立版本与记录。
4. **泛化因素**：建立未参与开发、独立标注的收件人/线程/外部材料案例，再验证经过上述通用修正的方案；不能用已调参的60案例再次证明家族中立。

格式、输出预算、provider、提示词和数据集都属于实验因素，不应一次全部修改后声称某一个修正有效。修改业务代码前先向用户说明；目前只新增离线分析和改写报告。付费补充实验与消融共享剩余 3.6552 USD，需要据预计请求量划分额度并以实际计数控制，不把目录单价预算当最终成本。

## 9. 可追溯材料与尚待完成项

- 原始正式日志：rows.jsonl、calls.jsonl、events.jsonl；中断开销：orphan_calls.jsonl。
- 可读模型映射：model_mapping.csv；每案例/每请求数据：case_metrics.csv、turn_metrics.csv。
- 本次审计：model_difference_audit.json；围栏离线诊断：fence_only_diagnostics.jsonl。
- 账单：billing.json、generations.jsonl；实验身份/冻结 hashes：run.json、config.json。
- 尚待完成：全量原文语义复核、独立测试集、消融与重复性实验、缺失账单记录核对。

主表数值来自原始 summary / operations；本次围栏诊断与原始指标分别保存。旧简表已保存为 report-summary-before-detailed-20261003.md。

## 10. 原始回答与格式/输出上限解释

以下附录给出逐字原始回答，避免只看分类统计无法理解问题。也可单独阅读 [原始回答实例](raw_answer_examples.md)。

# 原始最终回答与失败现场

以下模型回答 content 按日志逐字展示，不改写、不补字段。API 元数据仅摘录明确列出的字段；缺失正文显示为 null，不用推理过程冒充最终回答。新分析没有付费调用。

## 代码围栏到底是什么

三个反引号是 Markdown 的代码块显示标记，后面的 json 只是显示语言标签。它们不属于 JSON。网页聊天中通常会把它渲染成漂亮的代码块，但这里接口实际返回的字符串包含这些字符。程序 json.loads 期待第一个非空字符是合法 JSON 的起始符号；碰到反引号立即拒收，所以报错 line 1 column 1 (char 0)。

两层区别：HTTP 接口的外层 JSON 正常；外层 message.content 里存放的模型回答，包了一层 Markdown，因此它本身不是直接可解析的 JSON。这次失败发生在内层回答解析，不能称为网络或外层接口 JSON 失败。

所有模型的文字提示都要求 Return only JSON，但没有使用接口的 response_format 强制格式，冻结解析器也没有移除这层展示标记。模型没有严格遵守格式要求；workflow 对可机械消除的包装问题也缺乏兼容，造成不必要的付费重试。

## 逐条原始回答

N01 的邮件正文是 “Looks great. I like it!”；标注为 no_action。E01 正文指向发票附件，附件要求批准 INV-104，标注为 action。C11 为包含地点问题和资料清单的邮件线程。

### Gemini 3.5 Flash Lite · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris expressed approval for the filing (\"Looks great. I like it!\") but did not assign any new tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 97,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006652,
  "wall_ms": 1124.6195998974144,
  "local_error": null
}
```

### Gemini 3.5 Flash Lite · N01 · 第 2 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris approved the filing without assigning any tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1628,
  "completion_tokens": 83,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006959,
  "wall_ms": 981.9823999423534,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback on prior material and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 302,
  "reasoning_tokens": 219,
  "response_reported_cost_usd": 0.00218925,
  "wall_ms": 4018.7505000503734,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 2 次调用

原始回答：

````text
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1611,
  "completion_tokens": 409,
  "reasoning_tokens": 334,
  "response_reported_cost_usd": 0.002742,
  "wall_ms": 4750.226700096391,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 1 次调用

原始回答：

````text
```json
{
  "sources": [
    {
      "source_id": "attachment:1",
      "relevance": "decisive",
      "reason": "The email directly instructs the recipient to review the attached invoice instructions to determine their next step.",
      "evidence": [
        {
          "source_id": "body",
          "quote": "Please check the attached invoice instructions for your next step."
        }
      ]
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 775,
  "completion_tokens": 367,
  "reasoning_tokens": 256,
  "response_reported_cost_usd": 0.0019575,
  "wall_ms": 4289.634299930185,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 2 次调用

原始回答：

````text
{"sources": [{"source_id": "attachment:1", "relevance": "decisive", "reason": "The sender explicitly directs the recipient to check the attached instructions to determine their next step, delegating the required action/content to the attachment.", "evidence": [{"source_id": "body", "quote": "Please check the attached invoice instructions for your next step."}]}]}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1005,
  "completion_tokens": 302,
  "reasoning_tokens": 221,
  "response_reported_cost_usd": 0.00188625,
  "wall_ms": 4841.576800099574,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 3 次调用

原始回答：

````text
```json
{
  "status": "action",
  "actions": [
    {
      "kind": "perform_task",
      "text": "Approve invoice INV-104",
      "deadline": "2026-10-01",
      "evidence": [
        {
          "source_id": "attachment:1",
          "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
        }
      ]
    }
  ],
  "reason": "The sender directs you to the attached instructions, which ask you to approve invoice INV-104 by October 1, 2026.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Please check the attached invoice instructions for your next step."
    },
    {
      "source_id": "attachment:1",
      "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1477,
  "completion_tokens": 1757,
  "reasoning_tokens": 1502,
  "response_reported_cost_usd": 0.0076965,
  "wall_ms": 13597.290700068697,
  "local_error": null
}
```

### GLM-5.3 Flash · C11 · 第 1 次调用

原始回答：

````text
null
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Relace",
  "request_max_tokens": 2048,
  "finish_reason": "length",
  "native_finish_reason": "length",
  "prompt_tokens": 1579,
  "completion_tokens": 2048,
  "reasoning_tokens": 2069,
  "response_reported_cost_usd": 0.001079265,
  "wall_ms": 27332.371900090948,
  "local_error": "Model API response has no text completion (finish_reason=length, completion_tokens=2048)"
}
```

## Gemini 的失败链，按实际回答解释

N01：Flash Lite 第一次已经写出正确的 no_action，但是开头/结尾都有围栏。解析器未进入 status 字段就报错。重试的回答仍有围栏，于是再次拒收，最终输出由系统回退成 needs_review。这不是模型把赞许邮件理解成任务。Flash 第一次也有围栏，但重试返回裸 JSON，才被接受。

E01：Flash 第一次规划有围栏，第二次规划修复为裸 JSON，用掉唯一修复；第三次任务提取已给出批准发票的 action，但又有围栏。各阶段共享一次修复，没有第二次机会，系统最终复核。正文和任务其实很短，失败来自串联的格式验证与预算规则。

## GLM 为什么短答案也会达到上限

这次请求的 max_tokens=2048 没有另外控制 reasoning。多数 OpenRouter provider 会把模型推理与最终回答合并计入输出上限。可能最终答案只需一两百 token，但模型在输出答案前已经使用了大量推理 token。官方说明明确包含 finish_reason=length、content 为空且推理仍收费的情况：[OpenRouter reasoning tokens 文档](https://openrouter.ai/docs/guides/best-practices/reasoning-tokens)。

C11 的事实是：接口返回 finish_reason=length、completion_tokens=2048、content=null，同时有大量推理输出；因此程序根本没有收到最终 JSON。请求未显式设置 reasoning，当前推理默认值不受实验统一控制。这应归类为输出/推理预算兼容失败，不能判为已经给出错误最终答案。

该条 provider 报告 reasoning_tokens=2069，竟然大于 completion_tokens=2048，两字段不完全自洽。保留原值并标注计数差异，不使用两者相减去杜撰可见输出长度，也不声称精确到 token 的消耗分配。可确认的行为依据是 length 和 content=null；原因与文档所述预算耗尽一致。

我的设计问题在于：以“最终 JSON 很短”为理由设置统一 cap，却没有单独校验各家的默认推理行为。这一设置既不能证明 GLM 能力差，也不足以支持公平的纯模型能力排名。

## 所有达到上限的调用

| 模型 | 案例 / 调用 | provider | 最终正文字符数 | completion tokens | reasoning tokens |
| --- | --- | --- | ---: | ---: | ---: |
| Gemini 3.8 Flash | A20 / 1 | Google | 285 | 2044 | 1963 |
| Gemini 3.8 Flash | A20 / 2 | Google | 297 | 2044 | 1964 |
| GLM-5.3 Flash | C11 / 1 | Relace | 0 | 2048 | 2069 |
| GLM-5.3 Flash | C02 / 2 | Together | 0 | 2048 | 2048 |
| GLM-5.3 Flash | C03 / 1 | StreamLake | 0 | 2048 | 2049 |
| GLM-5.3 Flash | C13 / 1 | StreamLake | 461 | 2048 | 1950 |
| GLM-5.3 Flash | C12 / 1 | SiliconFlow | 761 | 2048 | 1859 |
| GLM-5.3 Flash | C10 / 1 | SiliconFlow | 460 | 2048 | 1927 |
| Gemini 3.8 Flash | E08 / 3 | Google | 232 | 2044 | 1964 |
| GLM-5.3 Flash | S02 / 2 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S02 / 2 | Google | 293 | 2044 | 1964 |
| GLM-5.3 Flash | S04 / 3 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S04 / 3 | Google | 271 | 2044 | 1962 |
