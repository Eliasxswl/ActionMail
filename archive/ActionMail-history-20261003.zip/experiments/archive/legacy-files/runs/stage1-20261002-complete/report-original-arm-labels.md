# Experiment results

Mode: live composite of disjoint completed observations. Complete: True.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| full_m01 | 60 | 59/60 | 96.4% | 100.0% | 15.0% |
| full_m02 | 60 | 51/60 | 100.0% | 81.5% | 31.7% |
| full_m03 | 60 | 10/60 | N/A | 0.0% | 100.0% |
| full_m04 | 60 | 42/60 | 89.5% | 63.0% | 40.0% |
| full_m05 | 60 | 59/60 | 96.4% | 100.0% | 15.0% |
| full_m06 | 60 | 58/60 | 96.3% | 96.3% | 16.7% |

## Speed and cost

| Arm | Case P50 / P95 ms | Calls | Known billed USD | Missing bill calls | Billed complete |
| --- | ---: | ---: | ---: | ---: | --- |
| full_m01 | 3985.78 / 8724.43 | 76 | 0.012339 | 0 | True |
| full_m02 | 23285.21 / 54892.12 | 110 | 0.056702 | 0 | True |
| full_m03 | 2732.05 / 3409.26 | 120 | 0.093015 | 0 | True |
| full_m04 | 14731.98 / 23572.76 | 136 | 0.523299 | 0 | True |
| full_m05 | 4042.04 / 11608.74 | 76 | 0.190289 | 0 | True |
| full_m06 | 2970.75 / 7607.88 | 77 | 0.475764 | 0 | True |

Actual consumption is measured by before/after usage counters and reconciled against per-generation billed costs. Token-rate estimates remain budget forecasts only.
API-key usage delta USD: 1.344801303. Account usage delta USD: None. Balance decrease USD: None.
Generation bills reconciled: False. Gap USD: -2.220446049250313e-16.
Counter delta is observed actual consumption in this time window. Concurrent use can contaminate attribution; isolated key required for experiment-only attribution.

Per-case and per-call details: case_metrics.csv, turn_metrics.csv, operations.json; original logs: rows.jsonl, calls.jsonl, events.jsonl.
TTFT is unavailable with non-streaming requests. Speed includes transport/queueing; token/s is end-to-end, not decode throughput.
See operations.json for denominators, token totals, repair incidence, incomplete-case calls, provider-reported costs and cross-model case agreement.

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
