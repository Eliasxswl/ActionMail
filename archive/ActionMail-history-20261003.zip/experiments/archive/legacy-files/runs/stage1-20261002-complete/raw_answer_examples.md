# 原始最终回答与失败现场

以下模型回答 content 按日志逐字展示，不改写、不补字段。API 元数据仅摘录明确列出的字段；缺失正文显示为 null，不用推理过程冒充最终回答。新分析没有付费调用。

## 代码围栏到底是什么

三个反引号是 Markdown 的代码块显示标记，后面的 json 只是显示语言标签。它们不属于 JSON。网页聊天中通常会把它渲染成漂亮的代码块，但这里接口实际返回的字符串包含这些字符。程序 json.loads 期待第一个非空字符是合法 JSON 的起始符号；碰到反引号立即拒收，所以报错 line 1 column 1 (char 0)。

两层区别：HTTP 接口的外层 JSON 正常；外层 message.content 里存放的模型回答，包了一层 Markdown，因此它本身不是直接可解析的 JSON。这次失败发生在内层回答解析，不能称为网络或外层接口 JSON 失败。

所有模型的文字提示都要求 Return only JSON，但没有使用接口的 response_format 强制格式，冻结解析器也没有移除这层展示标记。模型没有严格遵守格式要求；workflow 对可机械消除的包装问题也缺乏兼容，造成不必要的付费重试。

## 逐条原始回答

N01 的邮件正文是 “Looks great. I like it!”；标注为 no_action。E01 正文指向发票附件，附件要求批准 INV-104，标注为 action。C11 为包含地点问题和资料清单的邮件线程。

### Gemini 3.5 Flash Lite · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris expressed approval for the filing (\"Looks great. I like it!\") but did not assign any new tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 97,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006652,
  "wall_ms": 1124.6195998974144,
  "local_error": null
}
```

### Gemini 3.5 Flash Lite · N01 · 第 2 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris approved the filing without assigning any tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1628,
  "completion_tokens": 83,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006959,
  "wall_ms": 981.9823999423534,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback on prior material and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 302,
  "reasoning_tokens": 219,
  "response_reported_cost_usd": 0.00218925,
  "wall_ms": 4018.7505000503734,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 2 次调用

原始回答：

````text
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1611,
  "completion_tokens": 409,
  "reasoning_tokens": 334,
  "response_reported_cost_usd": 0.002742,
  "wall_ms": 4750.226700096391,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 1 次调用

原始回答：

````text
```json
{
  "sources": [
    {
      "source_id": "attachment:1",
      "relevance": "decisive",
      "reason": "The email directly instructs the recipient to review the attached invoice instructions to determine their next step.",
      "evidence": [
        {
          "source_id": "body",
          "quote": "Please check the attached invoice instructions for your next step."
        }
      ]
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 775,
  "completion_tokens": 367,
  "reasoning_tokens": 256,
  "response_reported_cost_usd": 0.0019575,
  "wall_ms": 4289.634299930185,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 2 次调用

原始回答：

````text
{"sources": [{"source_id": "attachment:1", "relevance": "decisive", "reason": "The sender explicitly directs the recipient to check the attached instructions to determine their next step, delegating the required action/content to the attachment.", "evidence": [{"source_id": "body", "quote": "Please check the attached invoice instructions for your next step."}]}]}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1005,
  "completion_tokens": 302,
  "reasoning_tokens": 221,
  "response_reported_cost_usd": 0.00188625,
  "wall_ms": 4841.576800099574,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 3 次调用

原始回答：

````text
```json
{
  "status": "action",
  "actions": [
    {
      "kind": "perform_task",
      "text": "Approve invoice INV-104",
      "deadline": "2026-10-01",
      "evidence": [
        {
          "source_id": "attachment:1",
          "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
        }
      ]
    }
  ],
  "reason": "The sender directs you to the attached instructions, which ask you to approve invoice INV-104 by October 1, 2026.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Please check the attached invoice instructions for your next step."
    },
    {
      "source_id": "attachment:1",
      "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1477,
  "completion_tokens": 1757,
  "reasoning_tokens": 1502,
  "response_reported_cost_usd": 0.0076965,
  "wall_ms": 13597.290700068697,
  "local_error": null
}
```

### GLM-5.3 Flash · C11 · 第 1 次调用

原始回答：

````text
null
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Relace",
  "request_max_tokens": 2048,
  "finish_reason": "length",
  "native_finish_reason": "length",
  "prompt_tokens": 1579,
  "completion_tokens": 2048,
  "reasoning_tokens": 2069,
  "response_reported_cost_usd": 0.001079265,
  "wall_ms": 27332.371900090948,
  "local_error": "Model API response has no text completion (finish_reason=length, completion_tokens=2048)"
}
```

## Gemini 的失败链，按实际回答解释

N01：Flash Lite 第一次已经写出正确的 no_action，但是开头/结尾都有围栏。解析器未进入 status 字段就报错。重试的回答仍有围栏，于是再次拒收，最终输出由系统回退成 needs_review。这不是模型把赞许邮件理解成任务。Flash 第一次也有围栏，但重试返回裸 JSON，才被接受。

E01：Flash 第一次规划有围栏，第二次规划修复为裸 JSON，用掉唯一修复；第三次任务提取已给出批准发票的 action，但又有围栏。各阶段共享一次修复，没有第二次机会，系统最终复核。正文和任务其实很短，失败来自串联的格式验证与预算规则。

## GLM 为什么短答案也会达到上限

这次请求的 max_tokens=2048 没有另外控制 reasoning。多数 OpenRouter provider 会把模型推理与最终回答合并计入输出上限。可能最终答案只需一两百 token，但模型在输出答案前已经使用了大量推理 token。官方说明明确包含 finish_reason=length、content 为空且推理仍收费的情况：[OpenRouter reasoning tokens 文档](https://openrouter.ai/docs/guides/best-practices/reasoning-tokens)。

C11 的事实是：接口返回 finish_reason=length、completion_tokens=2048、content=null，同时有大量推理输出；因此程序根本没有收到最终 JSON。请求未显式设置 reasoning，当前推理默认值不受实验统一控制。这应归类为输出/推理预算兼容失败，不能判为已经给出错误最终答案。

该条 provider 报告 reasoning_tokens=2069，竟然大于 completion_tokens=2048，两字段不完全自洽。保留原值并标注计数差异，不使用两者相减去杜撰可见输出长度，也不声称精确到 token 的消耗分配。可确认的行为依据是 length 和 content=null；原因与文档所述预算耗尽一致。

我的设计问题在于：以“最终 JSON 很短”为理由设置统一 cap，却没有单独校验各家的默认推理行为。这一设置既不能证明 GLM 能力差，也不足以支持公平的纯模型能力排名。

## 所有达到上限的调用

| 模型 | 案例 / 调用 | provider | 最终正文字符数 | completion tokens | reasoning tokens |
| --- | --- | --- | ---: | ---: | ---: |
| Gemini 3.8 Flash | A20 / 1 | Google | 285 | 2044 | 1963 |
| Gemini 3.8 Flash | A20 / 2 | Google | 297 | 2044 | 1964 |
| GLM-5.3 Flash | C11 / 1 | Relace | 0 | 2048 | 2069 |
| GLM-5.3 Flash | C02 / 2 | Together | 0 | 2048 | 2048 |
| GLM-5.3 Flash | C03 / 1 | StreamLake | 0 | 2048 | 2049 |
| GLM-5.3 Flash | C13 / 1 | StreamLake | 461 | 2048 | 1950 |
| GLM-5.3 Flash | C12 / 1 | SiliconFlow | 761 | 2048 | 1859 |
| GLM-5.3 Flash | C10 / 1 | SiliconFlow | 460 | 2048 | 1927 |
| Gemini 3.8 Flash | E08 / 3 | Google | 232 | 2044 | 1964 |
| GLM-5.3 Flash | S02 / 2 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S02 / 2 | Google | 293 | 2044 | 1964 |
| GLM-5.3 Flash | S04 / 3 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S04 / 3 | Google | 271 | 2044 | 1962 |
