# Experiment results

Mode: scripted engineering. Complete: True.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| prompt_only | 3 | 3/3 | 100.0% | 100.0% | 33.3% |
| full | 3 | 3/3 | 100.0% | 100.0% | 33.3% |
| no_repair | 3 | 3/3 | 100.0% | 100.0% | 33.3% |

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
