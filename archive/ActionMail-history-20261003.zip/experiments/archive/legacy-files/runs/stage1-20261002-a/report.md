# Experiment results

Mode: live. Complete: False.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| full_m01 | 30 | 30/30 | 100.0% | 100.0% | 13.3% |
| full_m02 | 30 | 29/30 | 100.0% | 100.0% | 16.7% |
| full_m03 | 30 | 4/30 | N/A | 0.0% | 100.0% |
| full_m04 | 30 | 29/30 | 91.7% | 100.0% | 10.0% |
| full_m05 | 30 | 30/30 | 100.0% | 100.0% | 13.3% |
| full_m06 | 29 | 29/29 | 100.0% | 100.0% | 13.8% |

## Speed and cost

| Arm | Case P50 / P95 ms | Calls | Known billed USD | Missing bill calls | Billed complete |
| --- | ---: | ---: | ---: | ---: | --- |
| full_m01 | 3014.73 / 4485.64 | 30 | 0.003628 | 0 | True |
| full_m02 | 13690.50 / 31158.28 | 45 | 0.019748 | 0 | True |
| full_m03 | 2680.91 / 3192.79 | 60 | 0.049573 | 0 | True |
| full_m04 | 11493.23 / 19006.99 | 60 | 0.219833 | 0 | True |
| full_m05 | 3593.14 / 4392.79 | 30 | 0.057597 | 0 | True |
| full_m06 | 2522.42 / 3195.43 | 29 | 0.168962 | 0 | True |

Actual consumption is measured by before/after usage counters and reconciled against per-generation billed costs. Token-rate estimates remain budget forecasts only.
API-key usage delta USD: 0.5193411680000002. Account usage delta USD: None. Balance decrease USD: None.
Generation bills reconciled: True. Gap USD: 2.220446049250313e-16.
Counter delta is observed actual consumption in this time window. Concurrent use can contaminate attribution; isolated key required for experiment-only attribution.

Per-case and per-call details: case_metrics.csv, turn_metrics.csv, operations.json; original logs: rows.jsonl, calls.jsonl, events.jsonl.
TTFT is unavailable with non-streaming requests. Speed includes transport/queueing; token/s is end-to-end, not decode throughput.
See operations.json for denominators, token totals, repair incidence, incomplete-case calls, provider-reported costs and cross-model case agreement.

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
