# Live run analysis notes

These are operational observations from an incomplete run, not a final ranking.

Authentication succeeded with two independent HTTP clients before launch. Six model IDs/rates were reverified. The frozen runtime and inference parameters remain unchanged.

Early Flash Lite cases fail the strict V2 response parser, retry once, then route to needs_review. This is response-format/contract behavior under this workflow, not an authentication failure or sufficient evidence about underlying semantic ability. Preserve raw replies, validation errors and repair events; do not tune the parser after observing results.

The owner's USD 5 total cap covers all experimental phases. Token-rate forecasts and conservative request reservations are not actual billed spending. Use the before/after usage counter and generation records for cost reconciliation.
