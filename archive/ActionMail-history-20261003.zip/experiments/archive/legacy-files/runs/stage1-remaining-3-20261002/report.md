# Experiment results

Mode: live. Complete: False.

| Arm | Analyses | Strict status match | Action precision | Action recall | Review rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| full_m01 | 17 | 17/17 | 100.0% | 100.0% | 17.6% |
| full_m02 | 17 | 11/17 | 100.0% | 57.1% | 52.9% |
| full_m03 | 16 | 2/16 | N/A | 0.0% | 100.0% |
| full_m04 | 16 | 3/16 | N/A | 0.0% | 93.8% |
| full_m05 | 16 | 16/16 | 100.0% | 100.0% | 12.5% |
| full_m06 | 16 | 16/16 | 100.0% | 100.0% | 12.5% |

## Speed and cost

| Arm | Case P50 / P95 ms | Calls | Known billed USD | Missing bill calls | Billed complete |
| --- | ---: | ---: | ---: | ---: | --- |
| full_m01 | 6556.45 / 10560.76 | 30 | 0.004964 | 0 | True |
| full_m02 | 34181.37 / 63276.03 | 41 | 0.020176 | 0 | True |
| full_m03 | 2867.11 / 3505.68 | 32 | 0.020711 | 0 | True |
| full_m04 | 19009.52 / 24375.95 | 45 | 0.158960 | 0 | True |
| full_m05 | 8313.93 / 13793.40 | 29 | 0.081168 | 0 | True |
| full_m06 | 5867.33 / 8320.12 | 29 | 0.170174 | 0 | True |

Actual consumption is measured by before/after usage counters and reconciled against per-generation billed costs. Token-rate estimates remain budget forecasts only.
API-key usage delta USD: 0.4561519330000001. Account usage delta USD: None. Balance decrease USD: None.
Generation bills reconciled: True. Gap USD: 1.1102230246251565e-16.
Counter delta is observed actual consumption in this time window. Concurrent use can contaminate attribution; isolated key required for experiment-only attribution.

Per-case and per-call details: case_metrics.csv, turn_metrics.csv, operations.json; original logs: rows.jsonl, calls.jsonl, events.jsonl.
TTFT is unavailable with non-streaming requests. Speed includes transport/queueing; token/s is end-to-end, not decode throughput.
See operations.json for denominators, token totals, repair incidence, incomplete-case calls, provider-reported costs and cross-model case agreement.

Semantic judgment fields are blank. Scripted smoke scores are engineering checks, never model accuracy.
Read paired comparisons on shared case IDs, not whole-arm aggregates with different denominators.
Null deadlines and supported non-null dates are scored separately; task count is not task completeness.
Unknown-usage or failed calls may still be billed; recorded cost is incomplete when those exist.
