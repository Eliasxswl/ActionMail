"""Presentation-only relabeling; keep source observations and frozen protocol intact."""
from pathlib import Path
import json, sys, csv
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scoring import report_arm_label
folder = root / 'artifacts/runs/stage1-20261002-complete'
config = json.loads((folder / 'config.json').read_text(encoding='utf-8'))
arms = {a['id']: a for a in config['arms']}
report = folder / 'report.md'
before = report.read_text(encoding='utf-8')
backup = folder / 'report-original-arm-labels.md'
if not backup.exists(): backup.write_text(before, encoding='utf-8')
after = before.replace('| Arm |', '| Model |')
for arm in arms:
    after = after.replace(f'| {arm} |', f'| {report_arm_label(arm, arms, config)} |')
assert not any(f'| {a} |' in after for a in arms)
assert sum(line.startswith('| ') for line in after.splitlines()) == sum(line.startswith('| ') for line in before.splitlines())
report.write_text(after, encoding='utf-8')
with (folder / 'model_mapping.csv').open('w', encoding='utf-8-sig', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['model_name', 'api_model_id', 'workflow', 'internal_arm_id'])
    for arm, definition in arms.items():
        writer.writerow([report_arm_label(arm, arms, config), config['models'][definition['model']]['id'], definition['mode'], arm])
print('Updated report model names; six rows mapped. Numeric results and raw logs unchanged.')
