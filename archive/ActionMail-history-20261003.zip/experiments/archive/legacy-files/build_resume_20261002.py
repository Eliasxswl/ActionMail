from pathlib import Path
root = Path(__file__).resolve().parent
source = (root / 'finish_stage1_20261002.py').read_text(encoding='utf-8')
source = source.replace('sources = [ORIGINAL]', '''checkpoint = read(ROOT / 'artifacts/stage1-paused-checkpoint-20261002.json')
for name, expected_hash in checkpoint['source_log_sha256'].items():
    if hashlib.sha256(Path(name).read_bytes()).hexdigest() != expected_hash:
        raise SystemExit('Paused log changed; inspect before resuming: ' + name)
sources = [Path(p) for p in checkpoint['sources']]''')
source = source.replace("ledger_path = ROOT / 'artifacts/stage1-completion-ledger-20261002.json'", "ledger_path = ROOT / 'artifacts/stage1-resume-ledger-20261002.json'")
source = source.replace('for part in range(1, 9):', 'for part in range(3, 11):')
source = source.replace("cost = raw.get('usage', {}).get('cost') if isinstance(raw, dict) else None", "cost = (raw.get('usage') or {}).get('cost') if isinstance(raw, dict) else None")
source = source.replace('    return max(counter, conservative), snapshot', '''    # A stopped in-flight request may have no response ID; keep a reservation
    # as well as capturing its possible charge in the global actual counter.
    unresolved_reservations = 0.0
    for source_run in sources:
        finished = {c.get('turn_id') for c in lines(source_run / 'calls.jsonl')}
        unresolved_reservations += sum(e.get('reservation_usd', 0) for e in lines(source_run / 'events.jsonl')
            if e.get('event') == 'call_started' and e.get('turn_id') not in finished)
    dump(ROOT / 'artifacts/stage1-resume-billing-20261002.json', {
        'baseline': baseline, 'current_snapshot': snapshot,
        'actual_counter_delta_usd': counter,
        'unresolved_call_reservation_usd': unresolved_reservations,
        'note': 'Actual counter includes possible paused in-flight charges. Unknown calls also held conservatively; never treat token-price estimates as actual cost.'})
    return max(counter, conservative) + unresolved_reservations, snapshot''')
source = source.replace("'cost_policy': 'Comparison tables", "'pause_checkpoint': str(ROOT / 'artifacts/stage1-paused-checkpoint-20261002.json'),\n    'unlogged_interrupted_requests': checkpoint['started_calls_without_finished_log'],\n    'cost_policy': 'Comparison tables")
target = root / 'resume_stage1_20261002.py'
with target.open('x', encoding='utf-8') as output: output.write(source)
print('Resume controller saved. Frozen experiment source unchanged.')
