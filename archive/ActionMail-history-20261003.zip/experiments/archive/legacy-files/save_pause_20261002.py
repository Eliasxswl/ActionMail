from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import json, hashlib, os, sys

root = Path(__file__).resolve().parents[1]
sources = [root / 'artifacts/runs' / name for name in
           ['stage1-20261002-a', 'stage1-remaining-1-20261002', 'stage1-remaining-2-20261002']]
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def lines(p):
    records, errors = [], []
    if p.exists():
        for n, line in enumerate(p.read_text(encoding='utf-8').splitlines(), 1):
            if not line: continue
            try: records.append(json.loads(line))
            except ValueError: errors.append({'file': str(p), 'line': n})
    return records, errors
def key(r): return (r['arm'], r['case_id'], r['trial'])
rows, calls, events, errors, hashes = [], [], [], [], {}
for source in sources:
    for name, dest in [('rows.jsonl', rows), ('calls.jsonl', calls), ('events.jsonl', events)]:
        path = source / name
        records, malformed = lines(path)
        dest.extend(records); errors.extend(malformed)
        if path.exists(): hashes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
config = read(root / 'artifacts/stage1-approved-5usd-20261002.json')
cases, _ = lines(root / 'artifacts/core-final-c405d29-20261002/dataset.jsonl')
expected = {(a['id'], c['case_id'], 1) for a in config['arms'] for c in cases}
done = {key(r) for r in rows}
finished_turns = {c.get('turn_id') for c in calls}
started = [e for e in events if e.get('event') == 'call_started']
unresolved = [{'arm': e['arm'], 'case_id': e['case_id'], 'trial': e['trial'],
               'turn_id': e.get('turn_id'), 'started_utc': e.get('started_utc')}
              for e in started if e.get('turn_id') not in finished_turns]
for line in (root / '.env').read_text(encoding='utf-8-sig').splitlines():
    line = line.strip()
    if not line or line.startswith('#') or '=' not in line: continue
    name, value = line.split('=', 1)
    value = value.strip()
    if len(value) > 1 and value[0] == value[-1] and value[0] in ['"', "'"]: value = value[1:-1]
    if name.strip() == 'OPENROUTER_API_KEY': os.environ['OPENROUTER_API_KEY'] = value
sys.path.insert(0, str(root / 'artifacts/protocol-freeze-20261002-b'))
from billing import Accounting
snapshot = Accounting(os.environ['OPENROUTER_API_KEY']).snapshot()
baseline = read(sources[0] / 'billing-baseline.json')
actual = snapshot['key_usage_usd'] - baseline['key_usage_usd'] if snapshot['key_usage_usd'] is not None else None
checkpoint = {'status': 'paused_by_owner', 'saved_utc': datetime.now(timezone.utc).isoformat(),
              'sources': [str(p) for p in sources], 'completed_unique': len(done), 'expected': len(expected),
              'completed_by_arm': dict(Counter(r['arm'] for r in rows)),
              'duplicate_completed_rows': len(rows) - len(done),
              'pending': [{'arm': a, 'case_id': c, 'trial': t} for a, c, t in sorted(expected-done)],
              'recorded_calls': len(calls), 'started_calls_without_finished_log': unresolved,
              'calls_without_completed_case': sum(key(c) not in done for c in calls),
              'malformed_log_lines': errors, 'source_log_sha256': hashes,
              'billing_baseline': baseline, 'billing_snapshot_at_pause': snapshot,
              'actual_counter_delta_usd_at_pause': actual, 'total_budget_usd': 5,
              'resume_policy': 'Do not restart old controller; use pending pairs only in new run directories. Reconcile unresolved calls before resuming. Preserve all original logs and frozen workflow.'}
path = root / 'artifacts/stage1-paused-checkpoint-20261002.json'
path.write_text(json.dumps(checkpoint, indent=2, ensure_ascii=False)+'\n', encoding='utf-8')
print(json.dumps({k: checkpoint[k] for k in ['status', 'completed_unique', 'expected', 'completed_by_arm', 'recorded_calls', 'started_calls_without_finished_log', 'malformed_log_lines', 'actual_counter_delta_usd_at_pause']}, ensure_ascii=False))
