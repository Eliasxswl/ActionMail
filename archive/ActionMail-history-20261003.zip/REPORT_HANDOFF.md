# PE6201 ActionMail：最终report写作交接

更新：2026-10-03。核心实验已封板。本文件面向接手写作的Agent，是阅读入口和证据地图，不是课程报告正文。请完成写作，不重启实验或开发业务功能。

## 1. 接手任务与阅读顺序

最终产物是个人PE6201项目的英文business and technical trade-off report，按已找到的课程原始文件要求，正文不超过1,200词。使用第一人称，解释问题、架构选择、测量结果、成本及限制，避免写成代码说明书或通用AI综述。

建议按顺序阅读：

1. 本交接。
2. [原report写作指导，已更新](ActionMail/docs/report_guide.md)：老师要求、原始来源、字数与写作结构。
3. [唯一实验主报告](experiments/REPORT.md)：六模型横评、兼容性诊断、两模型消融、原始回答、语义复核。
4. [封板方案与验收范围](experiments/PROTOCOL.md)、[实验入口](experiments/README.md)。
5. [代码架构](ActionMail/docs/architecture.md)、[代码入口](ActionMail/README.md)、[demo说明](ActionMail/docs/v3_demo.md)。
6. [课件与项目的联系](ActionMail/docs/course_relevance.md)、[课程原始文件入口](ActionMail/docs/course/README.md)。

出现冲突时：老师原始文件约束交付要求；用户最新决定约束项目范围；冻结输入/输出/账单约束事实；实验主报告的明确更正约束数字解释。旧开发报告不能覆盖最新实验。外部事实、数据集论文和服务商文档如要正式引用，需打开原始来源核对；本交接不代替文献。

只维护一份课程报告成稿，建议放在 `report/FINAL_REPORT.md`，在同一文件修订。`experiments/REPORT.md`是详细证据底稿，不是1,200词课程报告。不要生成多份draft/final/v2报告；图表若需要，统一放在 `report/figures/`。本次交接未创建课程报告正文。

## 2. 项目定位及用户已确认的范围

ActionMail为指定收件人识别最新工作邮件中的当前义务，结合邮件线程及必要附件/页面，输出任务、可解析的明确期限、解释和原文证据；信息不足时返回需要复核。目标是帮助人确认下一步，而不是替人执行工作。

论文主线：**通过有边界、可追溯的workflow提高邮件任务识别可靠性，并测量不同模型与组件下质量、速度和实际费用的取舍。** 模型横评是核心实验，不能压缩为只证明某个GPT模型优秀。跨家族格式失败也是workflow稳健性与接口设计的发现。

已确认：核心实验优先；真实Gmail → 模型 → Google Calendar闭环只是锦上添花。CLI是基础，GUI可辅助展示。Python自建编排已实现；UiPath未实现，不要沿用初始proposal写成已交付。业务代码冻结，强制JSON升级未进入本轮实验。模型与消融不再追加。

## 3. 代码端：从哪里读，哪些功能能声称实现

工作区根目录为 `E:\NTU Learn\PE6201\End_Course_project`。其中 `ActionMail/` 是Git仓库；当前 `main` HEAD为 `c405d2901ff1577ebafbc2a3ff151654970bb7ea`，包版本为 `3.0.0.dev0`。历史 `v2.0` 分支HEAD为 `a0b35d7`，不是当前实验冻结commit。实验在c405d29的冻结快照上运行，保留v2任务输出契约；不要把包版本、旧分支与实验版本混为一谈。

| 位置 | 写作所需理解 |
| --- | --- |
| `ActionMail/src/actionmail/ingestion/`、`domain/email.py` | 输入JSON/EML、指定目标收件人、当前正文、历史线程、时间和来源清单 |
| `content/reader.py`、`content/office.py`、`content/links.py` | 有界读取文本、HTML、CSV、文本PDF、DOCX/XLSX及允许的HTTPS内容；实际来源与哈希 |
| `workflow/multi_pipeline.py`、`coverage.py`、`context.py` | 选择性来源规划、读取、提取、长文本分段、候选合并及覆盖控制 |
| `workflow/repair.py`、`guardrails/matching.py`、`guardrails/evidence.py` | 输出与原文验证、纠错候选、每邮件共享一次修复；相似度不自动批准事实变化 |
| `reasoning/api_client.py`、`model_client.py`、`multi_response.py` | OpenRouter模型调用、结构化回答解析及日志 |
| `application/service.py`、`store.py` | 本地持久化、人工接受/修改/拒绝、日历草稿确认及操作记录 |
| `interfaces/`、`cli.py` | CLI、保存结果复核界面及离线应用UI |
| `integrations/` | Gmail/Calendar/OAuth适配器及明确标记的模拟响应；真实账户尚未验证 |
| `tests/`、`tools/check_repository.py` | 离线工程验证及资料完整性检查 |

最短workflow：输入归一化 → 清点来源 → 规划必要读取 → 有界读取 → 当前任务提取/长文合并 → schema与原文证据验证 → 允许时一次修复并再次验证 → action/no_action/needs_review → 人确认。

输出最多三项独立任务；同一交付的子步骤合并。旧请求仅在最新邮件续接时有效。可选建议不自动变成义务；会议/数据日期不自动变成期限。缺执行条件不自动消除可识别任务；缺决定任务内容的关键材料则应复核。

可以写“本地CLI、持久化复核、ICS导出及Google接口适配器已实现并进行离线验证”。不能写“真实账户闭环成功”“自动监控收件箱”“自动发送回复”“模型直接写日历”或“生产级集成可靠性已证明”。默认demo使用人工构造的邮件和scripted模型回答；demo不是新模型准确率实验。

交接时重跑结果：代码端108项、实验端29项离线测试通过。这137项是工程检查，不是137个真实邮件准确率样本；历史文档中的68/92/96等测试数属于不同阶段。

## 4. 实验端：冻结材料与数据口径

实验独立位于根目录 `experiments/`，不依赖另一份业务代码开发入口。`code/`保存执行、计费、观察与评分工具；`data/frozen-core/`保存输入与业务快照；`results/`保存正式结果；`archive/`保存历史，可回溯但不作为当前写作入口。

[finalization.json](experiments/results/finalization.json)记录封板时120个代码/数据/结果文件的SHA-256。封板后的文字更正不改这些原始文件；费用口径更正另记在 [billing_clarification.json](experiments/results/billing_clarification.json)。不要重新运行评分工具覆盖冻结的派生表，也不要改gold或回答以改善分数。

| 数据口径 | 数量与含义 |
| --- | --- |
| 评价单元 | 指定目标收件人的一封最新邮件，共60例 |
| 单一参考状态 | 27 action、23 no_action、10 needs_review |
| 原base 50场景 | 15无任务、15明确请求、10上下文、10附件/链接 |
| 后补10场景 | 2长内容、4实际文件附件场景、2链接/混合、2限制/恶意内容 |
| 输入来源 | 33 MailEx原始线程、1 Enron导出邮件/PDF、19 authored JSON、7 authored EML；34既有邮件来源、26人工构造 |
| 外部来源清单 | 17例包含20个按案例登记的来源：13附件、7链接 |
| 人工构造的外部来源 | 12附件（5短文本快照、7实际文件字节）与7链接（6快照、1不可读footer）；其余1附件是Enron导出PDF |

“实际文件附件”指真的传入文件字节，不等于来自真实职场的自然附件。网页快照不是现场爬取网页。以上是按案例来源清单计数，不是访问次数，也不包括C13旧线程提到但未提供的文档。S03是导出邮件/PDF输入，不是原生EML。

60例曾用于调参和回归，不是独立盲测。不能把MailEx原论文的事件抽取标签称为本项目的任务标签。用户保留的明确人工裁决为A16、C11、C13、E10；A16接受两项独立任务，C11预先允许保守复核或一个回答座位位置的动作。

## 5. 可引用的结果

### 5.1 六模型完整workflow横评

每模型60例、一个正式trial，共360个模型/案例观察。除model字段外首轮请求相同；temperature=0、max_tokens=2048，未启用response_format/强制JSON，未固定provider或单独设置reasoning预算。

| 模型 | 严格状态匹配 | 预先允许的状态/数量匹配 | 案例P50 / P95秒 | 已核generation费用USD |
| --- | ---: | ---: | ---: | ---: |
| GPT-6 Luna | 59/60 | 60/60 | 3.99 / 8.72 | 0.012339495 |
| GLM-5.3 Flash | 51/60 | 51/60 | 23.29 / 54.89 | 0.056702108 |
| Gemini 3.5 Flash Lite | 10/60 | 10/60 | 2.73 / 3.41 | 0.093015000 |
| Gemini 3.8 Flash | 42/60 | 43/60 | 14.73 / 23.57 | 0.523299000 |
| GPT-6.1 Sol | 59/60 | 60/60 | 4.04 / 11.61 | 0.190289100 |
| Claude Sonnet 5.5 | 58/60 | 59/60 | 2.97 / 7.61 | 0.468954000，缺1条账单 |

这些是当前workflow及路由下的端到端结果，不是脱离接口的模型理解能力排名。Flash Lite最终全部复核，10/60来自恰好匹配复核参考，不是10次成功任务提取。其回答均加了Markdown围栏，严格JSON解析器拒收；离线去围栏诊断只说明内容有可用信息，不能冒充重新跑完的60例成绩。GLM的输出上限可能被隐藏推理占用，可见任务本身很短。规划与提取共享一次修复，也放大跨阶段格式问题。

没有发现按GPT/Gemini/Claude名称区别处理的业务分支；但系统最初围绕Luna和这60例开发，不能排除隐性适配。完整横评尚未逐条完成与消融同等深度的语义匹配。

当前同参考规则基线：严格状态31/60，允许解释32/60；status-based action precision 12/20=60%，recall 12/27=44.4%。依据 [rules-baseline/summary.json](experiments/results/rules-baseline/summary.json)。这是已有body/subject规则及未读来源复核的系统基线，不具备同等附件、多任务能力；比较证明系统取舍，不隔离任何单组件因果作用。旧26/50、37/50属于旧合同，不应替代这组60例基线。

### 5.2 Luna与Sonnet的消融及语义复核

每模型250观察：完整60、一次提示基线60、无线程12、无外部读取17、全读17、无修复60、预选8例各重复3次24；共500观察、579次调用。完整组是同阶段fresh run，不把横评当配对组。

| 条件 | Luna严格状态 | Sonnet严格状态 | Luna语义交付通过 | Sonnet语义交付通过 |
| --- | ---: | ---: | ---: | ---: |
| 完整方案 | 58/60 | 59/60 | 59/60 | 60/60 |
| 一次提示基线 | 44/60 | 44/60 | 45/60 | 42/60 |
| 无历史线程 | 9/12 | 9/12 | 9/12 | 6/12 |
| 无外部读取 | 3/17 | 3/17 | 3/17 | 3/17 |
| 读取全部来源 | 16/17 | 16/17 | 15/17 | 15/17 |
| 无模型修复 | 59/60 | 58/60 | 59/60 | 58/60 |
| 重复运行 | 21/24 | 21/24 | 24/24 | 24/24 |

“语义交付通过”综合允许状态/数量、任务单位匹配、归属、承诺强度、期限、证据和复核合理性；没有原文依据的系统兜底不能仅凭状态相同算通过。任务kind与具体性差异另列，不把这列称为完美总体质量。

500条复核由Codex完成，参考用户保存的人工裁决，不是500条新人工裁决，也不是独立、校准的LLM judge研究。原预测、gold和严格分数未改。完整方案任务匹配Luna31/32、Sonnet32/32；precision均100%，recall为96.9%与100%。32是任务单位，60是邮件数。Sonnet完整C10回应合同对象正确，但未直接写出“是否正式修约申请”的细节。Luna等在S04存在kind差异，文字任务含义仍匹配。

配对分母：无线程对应的完整组两模型严格均11/12，语义交付均12/12、任务7/7；无外部读取/全读对应的完整组，Luna严格16/17、Sonnet17/17。不要用12/17例组直接减60例全量正确率。8例×3次不是24个独立样本。

完整方案本阶段P50：Luna3.59秒、Sonnet3.00秒；各60例费用0.013394660与0.480094000 USD，约0.000223与0.008002 USD/例，Sonnet约35.8倍。这是同条件测量的模型服务费用，不含开发、主机、存储、真实OAuth部署或人工复核时间；无已测ROI或节省工时证据。

### 5.3 实际费用与耗时的权威口径

横评前后usage计数差值1.344801303 USD；消融差值1.879727200 USD；累计3.224528503 USD，低于5 USD上限。消融579/579 generation账单与计数核对一致。

横评有一条Sonnet C12首答generation记录缺失。原 `operations.json` / `summary.json` / CSV把其 `response.usage.cost=0.006810` fallback算入了Sonnet小计0.475764；那是接口报告值，不能称已核generation费用。上表采用已核小计0.468954，缺失费用不补零。完成观察的已核小计1.344598703，加中断Luna E04调用已核0.000202600，等于计数窗口的1.344801303；缺失记录仍使全量审计不完整，不据此假设免费或退款。见 [口径更正](experiments/results/billing_clarification.json)，原始派生文件保留未覆盖。

案例耗时采用本地墙钟，包含规划、读取/提取、修复及网络/排队；账单查询时间单列。部分请求还有OpenRouter latency/generation_time，不能与客户端墙钟混用。非流式未测TTFT；端到端token/s不等于模型解码吞吐。token单价估算只用于预算，不作为最终实际消耗。

## 6. 最值得写进正文的案例与结论

| 结论 | 证据与解释 |
| --- | --- |
| 必要上下文能提高可用解决率 | 无外部读取两模型均3/17；大多数因缺关键内容安全复核，而不是胡乱猜任务。安全拒绝和成功交付分开 |
| 相同状态可能掩盖内容损失 | 无线程Sonnet C11把所需数据清单升级为额外义务；C02/C09对象或问题不足；Luna C10也泛化 |
| 选择性阅读有可靠性价值 | S07正文任务明确，footer链接无关；read-all因读不了该链接而阻断。规划会增加调用与费用，不应只说“阅读更多更好” |
| 修复改善原文/解释，未证实稳定提总分 | C12完整组恢复解释和证据，无修复组只剩错误兜底，状态都为复核；S02保住金额原文。独立首答不同，不是同一首答随机对照 |
| 格式成功也是交付条件 | Luna E07两次均理解对任务，却因JSON尾部多出字符被拒收；Gemini围栏问题证明接口约束仍需升级 |
| 模型选择应兼顾质量、速度与费用 | Luna在完整workflow上低成本且质量接近Sonnet；Sonnet提供跨家族行为对照。小样本一分差不支持确定排名 |

原始回答已收入实验主报告第10–12节。需要引用时选一两个短例，不把全量JSON塞进1,200词正文。原文出处、修复前后和最终交付状态不要混淆。不要展示或引用接口中的内部推理链。

## 7. 课程要求、课件对接与正文结构

原始文件在 `ActionMail/docs/course/`：`PE6201_Assessment_Timeline.pdf` p.1要求个人项目、问题陈述、≤1,200词business/technical分析、GitHub代码与录制demo；`PE6201_Project_Proposal_Watchouts (1).pdf` pp.1–3强调baseline、数据、测量、own/rent、成本、限制与可运行性。rubric权重为问题15%、权衡25%、实现35%、展示沟通25%。初始提交proposal是意图，不是交付证明。

用户报告的延期为10月4日，原timeline日期不同；精确截止时刻、视频长度、引用/附录是否计词及最终包装规则尚未在现有资料找到。接手Agent不得自造，也不得擅自联系老师。三个notebook属于A1，不自动是本项目要求。

推荐正文结构及字数：

| 段落 | 建议词数 | 写什么 |
| --- | ---: | --- |
| Problem and success criteria | 140 | 目标收件人、漏任务/过度任务风险、人工确认的任务建议 |
| Technology and business trade-offs | 300 | 规则/一次提示/有界workflow；自建领域规则与租用模型；Python取代初始UiPath计划的理由 |
| Implemented workflow | 180 | 必要上下文、证据、修复预算与复核；离线demo边界 |
| Evaluation and findings | 280 | 开发数据来源、六模型横评、两模型消融、质量/速度/费用的核心发现 |
| Limitations and next steps | 180 | reused suite、AI复核、provider与格式影响、未测人工成本、真实闭环/强制JSON后续 |
| 留给表题/引用/衔接 | 120 | 保守计词；不要假设图表、参考文献或附录免计 |

[course_relevance.md](ActionMail/docs/course_relevance.md)提供精确课件页码：Class2 C4评估/语义与确定性检查；Class3 C2冻结评估与结构化输出；Class4 C2有界调用及恢复；Class6 C1 guardrails是代理指标；Class2 C2 own/rent；Class5 C2总成本含人工复核。用来解释设计选择，不堆砌课程术语，不把课件称为第三方性能证明。

文献入口已核对：[MailEx: Email Event and Argument Extraction](https://aclanthology.org/2023.emnlp-main.801/)（Srivastava et al., EMNLP 2023，pp.12964–12987，DOI 10.18653/v1/2023.emnlp-main.801）；[作者项目仓库](https://github.com/salokr/Email-Event-Extraction)。MailEx研究邮件线程中的事件/论元抽取；本项目另定义收件人任务义务，不直接沿用其全部标签或把其论文分数拿来横比。

## 8. 成稿必须保留的边界与后续工作

必须清楚区分：实现了什么、离线验证了什么、模型测量了什么、未来才做什么。明确数据复用、原Luna调参倾向、C11预先允许解释、Codex辅助代码/样例/标注及本次AI复核身份。原文完全匹配只证明来源，不自动证明任务完整或安全。

未来工作是独立测试集与独立人工评审、固定首答重放、强制JSON接口升级、真实账户闭环；不在本次封板后补跑。安全方面只证明特定损坏/恶意fixture的处理，不声称完全防prompt injection、合规认证或生产保障。不虚构实际节省时间、用户采用率和商业ROI。

## 9. 读数据、复现与demo

| 目的 | 权威文件 |
| --- | --- |
| 冻结协议/数据/代码 | `experiments/PROTOCOL.md`、`data/frozen-core/manifest.json`、`results/finalization.json` |
| 六模型状态指标 | `results/model-benchmark/summary.json`、`model_mapping.csv` |
| 时间、token、重试及provider | 各阶段 `operations.json`、`case_metrics.csv`、`turn_metrics.csv`；横评费用fallback需结合更正 |
| 实际总费用 | 横评 `billing.json`、消融 `billing.json`、`global-billing.json`、`results/billing_clarification.json` |
| 语义裁决与错误类型 | 消融 `semantic_review.csv`、`semantic_summary.json`、`semantic_audit.json` |
| 每case/turn原始过程 | 各阶段 `rows.jsonl`、`calls.jsonl`、`events.jsonl`、`generations.jsonl` |
| 用户原人工裁决 | `ActionMail/backup/v2.0/results/evaluation/v2-full-20261001/adjudication.json`及reference裁决 |

表中未写前缀的结果路径相对 `experiments/`。主报告就是人读入口，无需从archive寻找所谓更完整版本。不要读取、拷贝或引用 `.env`、API key、OAuth凭证或私有应用数据库。

离线验证可运行（在指定目录，Python已安装依赖时）：

```powershell
# 在ActionMail/，只做工程检查
$env:PYTHONPATH = 'src'
python -m unittest discover -s tests -q
python tools/check_repository.py

# 在工作区根，实验工具离线检查
python -m unittest discover -s experiments/code/tests -q
```

不要运行 `actionmail eval` 或任何付费pipeline入口。若需要看demo，可按已有说明用offline `actionmail demo`，标记scripted，不把输出当新准确率。录制视频建议展示：一条可识别任务、一条附件依赖、一条明确复核，以及原文证据与人确认；ICS/模拟日历可选，真实集成不作为验收门槛。

包装提醒：工作区根不是Git仓库，`experiments/`位于 `ActionMail/` Git仓库之外。仅推送ActionMail不会携带本交接或实验包。最终交付负责人须显式安排代码、实验材料、成稿和视频的提交位置；写作Agent不自行移动冻结文件、提交Git或发布。公共语料/课程资料的分发权限须与本地引用区分，凭证和archive不随教师提交包传播。

## 10. 可直接转交给写作Agent的任务

请阅读工作区根REPORT_HANDOFF.md及其中的权威文档，为这个个人PE6201 ActionMail项目撰写一份不超过1,200词的英文business and technical trade-off report。使用第一人称，围绕可追溯的邮件任务识别workflow、模型横评、两模型消融、质量/速度/实际费用展开，保留数据复用、AI复核和接口兼容的限制。核对老师原始要求和最终数字，尤其Sonnet横评费用缺失记录的更正。只维护report/FINAL_REPORT.md一份成稿，给出保守总词数与每个数字的证据路径；必要的图表放report/figures/。引用外部文献时核对原始来源。不要重新跑实验、改代码或标注、启用真实集成、创建其他Agent任务、提交Git或发布材料。完成后对照本交接进行事实与范围自查，并指出尚需用户提供的提交规则，不能猜测。
