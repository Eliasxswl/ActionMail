# 六模型横评与消融实验报告

当前状态：实验已于2026-10-03封板，进入课程报告与demo制作。横评360/360与消融500/500均已完成，累计实际扣费3.224528503 USD。消融结果见第11节；500条消融输出已完成Codex语义复核，见第12节。六模型横评语义复核与强制JSON升级仍待完成。

更新：2026-10-03。实验于新加坡时间 2026-10-02 23:29 完成。六模型各 60 案例，共 360 个独立模型/案例观察。指标和日志统一位于 `results/model-benchmark/`。本文分析既有日志，无新增模型调用，也未更改冻结业务代码、提示词、解析器或原始分数。

## 结论与适用范围

当前结果支持：在这套冻结 ActionMail workflow、OpenRouter 路由与参数配置下，Luna 的运行性价比最好，Sol 分类表现相同，Sonnet 同样具备较好的可用性。它不支持“GPT 家族的理解能力远胜 Google / GLM”。Google 的主要损失来自输出格式和跨阶段重试预算，GLM 还受到推理输出预算与服务商路由的影响。

对“是否专门适配 GPT”的回答：审查未发现按 GPT / Gemini / Claude 名称分支的推理或解析逻辑；60 个案例的首轮请求除 model 字段外逐字一致。不过，项目原开发默认模型为 Luna，60 案例明确曾用于开发调参，严格 JSON 解析和单次共享修复又恰好更适合本次 GPT 的输出习惯。因此，不能仅凭同一提示词宣称设计已达到家族中立，也不能排除开发过程中的隐性适配。此前报告没有把这个限制说清楚。

推荐后续主消融使用 **Luna + Sonnet**，分别代表低成本可用方案与另一个家族的可用方案；Sol 作为同家族性能/价格参照已在横评中保留，暂不占第三个消融名额。GLM / Google 需要单独的兼容性诊断，不能把其当前流程失败当作能力淘汰依据。Luna与Sonnet的500条消融已完成，语义复核见第12节；六模型横评的360条全量语义匹配仍待完成。

## 1. 实验测量的是什么

- 输入：相同 60 个开发/回归案例，27 action、23 no_action、10 needs_review。包含邮件上下文、外部来源、真实附件、长内容和限制/恶意内容。不是独立盲测集。
- 冻结：Git c405d29；相同输入、标注、原始附件/网页快照、收件人、提示词、schema、读取限制和评分规则。
- 执行：按案例轮换六模型；中断后仅补跑未完成模型/案例。每案例一个正式 trial，不能据此估计稳定性或统计显著性。
- 指标：状态正确不等于任务语义正确；任务数相同不等于任务完整；原文引文匹配不等于证据支持结论。原有独立人工语义评分仍为空；本次另完成500条消融的Codex语义复核并明确标注评审身份。
- action recall：真实 action 被转人工复核也算漏检，体现端到端业务损失。合法的需要复核与系统报错后的回退须分开解释。

## 2. 状态、速度和实际成本

耗时为单案例本地墙钟时间，包含规划、提取、合并和修复调用，扣除了只读账单查询开销；仍含网络和排队。费用为正式完成案例中已取得的generation实际账单，不是token单价估算；Sonnet缺1条，因此该行是已核费用小计而非完整实际费用。

| 模型 | 严格状态正确 | 允许标注分歧后的状态/数量匹配 | action 精确率 / 召回率 | 复核比例 | P50 / P95 秒 | 60 案例账单 USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6 Luna | 59/60 | 60/60 | 96.4% / 100.0% | 15.0% | 3.99 / 8.72 | 0.012339 |
| GLM-5.3 Flash | 51/60 | 51/60 | 100.0% / 81.5% | 31.7% | 23.29 / 54.89 | 0.056702 |
| Gemini 3.5 Flash Lite | 10/60 | 10/60 | 不可计算 / 0.0% | 100.0% | 2.73 / 3.41 | 0.093015 |
| Gemini 3.8 Flash | 42/60 | 43/60 | 89.5% / 63.0% | 40.0% | 14.73 / 23.57 | 0.523299 |
| GPT-6.1 Sol | 59/60 | 60/60 | 96.4% / 100.0% | 15.0% | 4.04 / 11.61 | 0.190289 |
| Claude Sonnet 5.5 | 58/60 | 59/60 | 96.3% / 96.3% | 16.7% | 2.97 / 7.61 | 0.468954（缺1条账单） |

费用口径更正（2026-10-03交接核对）：原Sonnet表值0.475764包含C12第1次调用的 `response.usage.cost=0.006810`，但该调用没有generation账单，不能称已核费用。上表改为其余76次调用的已核小计0.468954。原始 `operations.json`、`turn_metrics.csv` 和 `summary.json` 保留冻结时的值；它们的 `known_billed_cost_usd` / `billed_cost_usd` 可能采用接口usage作为fallback，不能不加区分地引用。其他五模型行不受影响。按response_id重新核对，完成案例的已核账单合计1.344598703，另有中断Luna E04规划调用已核0.000202600，共1.344801303，与计数差值相符；缺失Sonnet记录仍未补齐，不能据此假定该请求免费或退款。累计实际消耗3.224528503不变。依据见 `results/billing_clarification.json`。

“允许标注分歧”仅使用实验前已有的 accepted_outcomes。C11 同时允许保守复核与一个回答地点的动作；不是为本次 GPT 结果修改答案。严格评分和允许结果都公开。

横评阶段前后 key usage 差值 **1.344801303 USD**，当时总额度剩余 **3.655198697 USD**；消融完成后的累计费用与剩余额度见第11节。595 条已知 generation 账单合计与该差值一致到浮点精度；另有 1 条 generation 记录缺失，完整审计仍标记 pending。中断时还有未收到返回的请求，其可能扣费包含在总体计数窗口内。比较表只统计完成案例，不能把它与含中断开销的实验总费用混为一谈。

Luna 与 Sol 的状态分数一致，但当前账单 Sol 约为 Luna 的 15.4 倍；Sonnet已核费用小计约为Luna的38.0倍（Sonnet缺1条账单，非完整费用比），P50 更低。Flash 标价较低但实际流程费用高于 Sonnet，不能用目录单价替代实际完成任务成本。Flash Lite 的低耗时主要来自早期失败/转复核，不能解释为同等任务质量下速度最快。

## 3. 分类别结果：差距在哪个环节扩大

| 案例类别 | 数量 | Luna | GLM | Flash Lite | Flash | Sol | Sonnet |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 无任务 | 15 | 15/15 | 14/15 | 0/15 | 15/15 | 15/15 | 15/15 |
| 显式请求 | 15 | 15/15 | 15/15 | 4/15 | 14/15 | 15/15 | 15/15 |
| 上下文/归属 | 10 | 9/10 | 8/10 | 3/10 | 9/10 | 9/10 | 8/10 |
| 外部内容 | 10 | 10/10 | 6/10 | 0/10 | 0/10 | 10/10 | 10/10 |
| 真实附件 | 4 | 4/4 | 3/4 | 1/4 | 1/4 | 4/4 | 4/4 |
| 长内容 | 2 | 2/2 | 1/2 | 0/2 | 1/2 | 2/2 | 2/2 |
| 混合链接 | 2 | 2/2 | 2/2 | 1/2 | 1/2 | 2/2 | 2/2 |
| 限制/恶意内容 | 2 | 2/2 | 2/2 | 1/2 | 1/2 | 2/2 | 2/2 |

关键读法：GLM 的显式请求仍为 15/15，但在上下文、外部信息和长内容中下降。Flash 的无任务案例为 15/15、显式请求为 14/15，外部内容却为 0/10；这种断崖首先应检查多阶段机制，不应直接判成阅读能力消失。Flash Lite 所有最终结果都为 needs_review，10/60 是恰好与复核标注相同，不是 10 次正常任务提取成功。

## 4. 格式、修复、输出预算：将失败机制拆开

| 模型 | 调用数 | 触发修复的案例 | 修复成功 / 失败 | 因共享次数已用完而跳过 | 达到输出上限的调用 | 修复实际费用 USD |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| GPT-6 Luna | 76 | 0/60 | 0 / 0 | 0 | 0 | 0.000000 |
| GLM-5.3 Flash | 110 | 34/60 | 31 / 3 | 4 | 8 | 0.016110 |
| Gemini 3.5 Flash Lite | 120 | 60/60 | 0 / 60 | 0 | 0 | 0.048971 |
| Gemini 3.8 Flash | 136 | 60/60 | 57 / 3 | 16 | 5 | 0.218346 |
| GPT-6.1 Sol | 76 | 0/60 | 0 / 0 | 0 | 0 | 0.000000 |
| Claude Sonnet 5.5 | 77 | 1/60 | 1 / 0 | 0 | 0 | 0.012984 |

修复成功指当次结果通过验证，不等于最终整条 workflow 成功。例如规划修复成功后，提取仍可能失败。所有阶段共享每邮件一次修复，表中跳过次数是事件数，不是新增模型请求。

### Google：围栏 JSON 与跨阶段放大

Flash Lite 的 120/120 条回复均被最外层 Markdown JSON 围栏包裹。Frozen parser 直接 json.loads，不会先移除围栏；每个案例都耗费一次修复，但修复输出仍有围栏，全部失败。43 个案例在提取阶段失败，17 个带外部来源的案例在阅读计划阶段已经失败。

Flash 的 60/60 案例都触发修复，57 次修复当次成功。但 17 个外部来源案例先在规划阶段触发修复，其中 16 个随后在提取阶段再次格式失败，修复预算已用完。例 E01：规划带围栏 → 规划修复为裸 JSON → 读取附件 → 提取再次带围栏 → skipped_retry_budget → 最终 needs_review。日志中的提取原始内容实际上已列出 approve invoice 的动作，不能将最终漏检解释为“没有理解附件”。

这是通用 workflow 的缺陷：它把可机械处理的格式包装问题与原文证据纠错一起消耗同一个昂贵的 LLM 修复预算。冻结实验保留这个行为以避免中途调参，但报告必须将其作为产品兼容性损失披露。

### GLM：格式损失之外还有推理预算与路由

GLM 共 110 次请求，34 案例触发修复；31 次修复成功，2 次在修复调用中 API 正文缺失，1 次仍未通过验证。共有 8 次 finish_reason=length，其中 5 次没有可用正文，最后安全回退人工复核。这不是普通任务语义判断错误。

GLM 日志合计 completion_tokens=91,455，其中 reasoning_tokens=77,777；Flash 分别为 100,735 / 81,955。相同 2048 输出 cap 没有控制“可见回答 + 隐藏推理”的实际分配。请求也没有显式 reasoning 设置，默认推理行为没有做到可比较。不能因为统一参数值就宣称各家获得同等有效输出预算。

GLM 的 110 次请求由 12 个 provider 标签承接，包括 Together、Relace、SiliconFlow 等；速度/超限现象可能受到路由影响，单次实验无法把服务商和模型贡献拆开。其他模型本次分别是 OpenAI、Google，以及 Sonnet 的 Claude Platform on AWS。当前结论应以“请求模型 + 实际路由”表述。

### 原文匹配修复：目前直接证据有限

只有 GLM 与 Sonnet 各 1 个事件具有非空 quote_diagnostics。Sonnet 在 C12 首次引用了并非原文的 “CHASE - READY TO EXECUTE ASAP!”；没有找到原文候选，但模型修复后通过验证。GLM 在 S02 忽略了原邮件的软换行，诊断给出相似度 0.9959、来源唯一且没有关键数字差异的候选；候选不会自动接受，随后修复请求达到输出上限而没有正文，最终复核。它展示了原文匹配诊断确实进入重试链，但不证明本次修复成功。整体修复收益大多来自格式。Luna、Sol 无修复事件，不代表机制对它们无价值，只表示这一次运行没有触发。需要 no_repair 配对消融和机制注入，才能量化证据修复的因果作用。

## 5. 不花钱的格式诊断：证明混杂存在，而非重写成绩

对所有模型采用同一个离线转换：仅当整个回复是一个 Markdown 代码围栏时，删除最外层围栏；不改 JSON 字段、任务、引文、提示词或正文。用冻结 schema 重新检查既有回复，没有重新调用模型。

| 模型 | 完整围栏回复 | 去围栏后可解析 JSON | 通过对应冻结 schema |
| --- | ---: | ---: | ---: |
| GPT-6 Luna | 0 | 0 | 0 |
| GLM-5.3 Flash | 36 | 36 | 35 |
| Gemini 3.5 Flash Lite | 120 | 120 | 118 |
| Gemini 3.8 Flash | 73 | 73 | 73 |
| GPT-6.1 Sol | 0 | 0 | 0 |
| Claude Sonnet 5.5 | 0 | 0 | 0 |

在不含外部来源、首轮直接提取且去围栏后 schema 合格的子集中，Flash Lite 41 条里 36 条状态与标注相同，41 条均通过冻结原邮件证据验证；Flash 42 条里 40 条原始状态匹配，证据验证后为 39 条。该子集有格式和阶段筛选，分母与正式 60 案例不同，不能与主表直接排排名。它足以否定“Flash Lite 的 10/60 主要证明理解能力差”这种解释，同时保留了仍然存在的语义分歧。

规划 schema 能解析不代表规划语义和证据正确；阅读计划修复可能改变后续读取，离线转换没有重放那些未执行的后续调用。因此 **不生成所谓“修正后 60 案例准确率”**。原始成绩始终保留。逐条诊断见 fence_only_diagnostics.jsonl。

## 6. 具体案例：语义差异与系统失败不能混计

| 案例 | 输入/标注要点 | 观察 | 含义 |
| --- | --- | --- | --- |
| N01 | “Looks great. I like it!”；无任务 | Flash Lite 裸内容实际写 no_action，但两次围栏导致最终复核；Flash 修复后正确 | 纯格式失败足以造成巨大总分差 |
| N03 | “FYI. sj”；无任务 | GLM 正常返回复核，认为转发内容未给出而无法判断；其余可用模型返回无任务 | 真正的缺失信息政策/保守程度分歧，不是解析失败 |
| E01 | 附件要求 Alex 批准发票并给出日期 | Flash 已读附件、原始提取中已有动作，但共享修复耗尽；Flash Lite 规划就失败 | 多阶段格式损失，不能归因于附件理解 |
| A18 | 要提交表格，但发件人不确定税表还是供应商表；应复核 | Flash 正常通过格式验证却输出“提交讨论过的表格”；其他可用模型复核 | 存在真实语义过度确定，兼容修复不会解决它 |
| C10 | “we are waiting to hear from Darrell”；标注需要回应 | Luna / Sol / GLM / Flash 提出回应；Sonnet认为具体下一步不明确而复核 | Sonnet 在上下文义务判断更保守；需检查原线程，不能自动认定更大模型更准确 |
| C11 | “Where do you sit?” + 资料清单；严格 gold 为复核，预先允许一个回答动作 | Luna / Sol / Sonnet / Flash 提出回答地点；严格评分扣一分，允许结果匹配 | 标注敏感性；不得把这一个分差当模型能力排序 |
| S04 | workbook 三项任务，包括 confirm projector availability | Luna / Sol / Sonnet 都取出三项，但都使用 perform_task；gold 的第三项是 answer_question | 状态/数量满分仍可能掩盖动作类型差异，语义复核不可省略 |

这些案例只是日志级问题分析，不是已完成的全量语义评分。未对 360 行完成任务单位匹配、承诺强度、证据支持与截止日期复核。

## 7. 公平性审计：确认的事实与仍未解决的风险

| 维度 | 日志/源码证据 | 解释与限制 |
| --- | --- | --- |
| 首轮输入一致 | 60/60 案例各六模型首轮 payload 去掉 model 后相同 | 无按模型增加首轮上下文；后续上下文因模型规划/修复而分叉，是被测行为 |
| 参数一致 | 所有 595 条正式调用均只有 model/messages/temperature/max_tokens；temperature=0、max_tokens=2048 | 相同参数并不控制默认推理、tokenizer、服务商适配后的行为 |
| 代码分支 | 冻结运行时代码检索只发现 UI 默认模型 Luna；未发现按家族分支的推理/解析 | 未发现显式家族优惠，不等于消除了开发数据与输出习惯的偏向 |
| 输出约束 | 没有请求 response_format 或 structured_outputs；靠文字要求 JSON，使用同一严格 parser | 跨家族兼容不足；提示要求已给出，但自动包装应作为接口问题单独评估 |
| 修复公平 | 每邮件、所有阶段共享一次，所有模型相同 | 表面相同却会被格式错误占满，未充分隔离格式与原文纠错 |
| 推理预算 | 日志有 reasoning tokens，但请求未显式控制 | 长推理模型可能在返回正文前耗尽 cap，影响速度、费用及成功率 |
| provider | 未固定 provider，GLM 多 provider | 不能区分模型和服务部署差异 |
| 开发数据偏向 | 文档记录 60 案例已用于开发调参；默认开发模型为 Luna | 可存在对 Luna 的隐性适配；必须新增未参与开发、独立标注案例验证泛化 |
| 缓存/成本 | Luna cached input=63,612；Sol=62,496；Google/Sonnet本次为0 | 当前实付账单真实，但共享长系统提示的暖缓存优势不等于冷启动部署价格。应单列缓存，不能做估算替换 |
| 单次实验 | 每案例一个 trial，样本仅60 | 一分差不是稳健排名；重复实验只测一致性，仍不替代独立测试集 |

预算只对整个实验约束，所有模型跑同样 60 案例，无按成功率提前淘汰；中断后补齐完整矩阵。费用、原始失败、修复和暂停记录全部保留。

## 8. 后续消融选型与建议的兼容性补充实验

### 主消融：Luna + Sonnet，固定原 workflow

Luna：低成本、无需格式修复，在本套数据上状态召回率 100%，适合测量线程、外部读取、规划和修复是否改变任务解决率。Sonnet：另一个家族，状态召回率 96.3%，本次仅一个引文修复，对上下文义务更保守，能检查机制收益是否跨家族成立。两者均达到预先 action precision / recall ≥90% 的候选条件。

Sol：与 Luna 同家族、相同状态错误 C11、相同任务数量表现，暂时缺少足够额外差异支持完整第三份消融；若语义复核揭示遗漏/承诺强度不同，可再讨论加入。

GLM：当前召回率 81.5%，不满足效果主消融门槛；若加入只能明确作为“兼容与失败机制诊断模型”，不能悄悄降低门槛。Google：在原 pipeline 中失败高度集中于格式/共享重试，直接做深消融容易得到“每组都失败”的无信息结果。暂缓它们的效果消融不等于判定其模型能力不合格。

主消融保持原有矩阵：完整方案、one-call prompt baseline、无线程、无外部读取、read-all、无修复以及预先指定案例的重复运行。完整方案需要 fresh run 作为同批配对参考，不把横评观察冒充新 trial。用户已确认Luna与Sonnet并授权完成付费消融，实际执行见第11节，随后语义复核见第12节。

### 单独的通用兼容性协议 V2：建议，尚未实施

先隔离两个因素，不针对任何单一模型改提示词：
1. **格式因素**：所有模型统一仅移除整个回复的外层代码围栏，仍严格验证 schema、动作限制、原文引文和安全回退。用现有围栏诊断验证转换边界后，再在预先定义的相同案例上运行独立新协议；不能覆盖冻结结果。
2. **输出预算因素**：先只提高所有模型相同的输出 cap，保持提示、格式策略、推理设置不变，比较 finish_reason、正文成功率、时间、reasoning tokens 和实际费用。若再实验显式推理设置，需要单独记录各家参数能力，并承认相同 reasoning_effort 文字值不必代表相同计算量。
3. **部署因素**：GLM 若继续做速度结论，固定可用 provider 或至少按 provider 分层。固定路由会改变所测配置，必须另立版本与记录。
4. **泛化因素**：建立未参与开发、独立标注的收件人/线程/外部材料案例，再验证经过上述通用修正的方案；不能用已调参的60案例再次证明家族中立。

格式、输出预算、provider、提示词和数据集都属于实验因素，不应一次全部修改后声称某一个修正有效。修改业务代码前先向用户说明；目前只新增离线分析和改写报告。付费补充实验与消融共享剩余 3.6552 USD，需要据预计请求量划分额度并以实际计数控制，不把目录单价预算当最终成本。

## 9. 可追溯材料与尚待完成项

- 原始正式日志：rows.jsonl、calls.jsonl、events.jsonl；中断开销：orphan_calls.jsonl。
- 可读模型映射：model_mapping.csv；每案例/每请求数据：case_metrics.csv、turn_metrics.csv。
- 本次审计：model_difference_audit.json；围栏离线诊断：fence_only_diagnostics.jsonl。
- 账单：billing.json、generations.jsonl；实验身份/冻结 hashes：run.json、config.json。
- 尚待完成：六模型横评360条语义复核、独立测试集、缺失账单记录核对；500条消融与局部重复性实验及其Codex语义复核已完成。

主表数值来自原始 summary / operations；本次围栏诊断与原始指标分别保存。历史过程文件统一归档于 archive/development-history.zip，不作为当前报告版本。

## 10. 原始回答与格式/输出上限解释

以下附录给出逐字原始回答，避免只看分类统计无法理解问题。所有原始回答实例已直接包含在本报告中。

### 原始最终回答与失败现场

以下模型回答 content 按日志逐字展示，不改写、不补字段。API 元数据仅摘录明确列出的字段；缺失正文显示为 null，不用推理过程冒充最终回答。新分析没有付费调用。

## 代码围栏到底是什么

三个反引号是 Markdown 的代码块显示标记，后面的 json 只是显示语言标签。它们不属于 JSON。网页聊天中通常会把它渲染成漂亮的代码块，但这里接口实际返回的字符串包含这些字符。程序 json.loads 期待第一个非空字符是合法 JSON 的起始符号；碰到反引号立即拒收，所以报错 line 1 column 1 (char 0)。

两层区别：HTTP 接口的外层 JSON 正常；外层 message.content 里存放的模型回答，包了一层 Markdown，因此它本身不是直接可解析的 JSON。这次失败发生在内层回答解析，不能称为网络或外层接口 JSON 失败。

所有模型的文字提示都要求 Return only JSON，但没有使用接口的 response_format 强制格式，冻结解析器也没有移除这层展示标记。模型没有严格遵守格式要求；workflow 对可机械消除的包装问题也缺乏兼容，造成不必要的付费重试。

## 逐条原始回答

N01 的邮件正文是 “Looks great. I like it!”；标注为 no_action。E01 正文指向发票附件，附件要求批准 INV-104，标注为 action。C11 为包含地点问题和资料清单的邮件线程。

### Gemini 3.5 Flash Lite · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris expressed approval for the filing (\"Looks great. I like it!\") but did not assign any new tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 97,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006652,
  "wall_ms": 1124.6195998974144,
  "local_error": null
}
```

### Gemini 3.5 Flash Lite · N01 · 第 2 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "Steven Harris approved the filing without assigning any tasks or requests to Bill Rapp.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1628,
  "completion_tokens": 83,
  "reasoning_tokens": 0,
  "response_reported_cost_usd": 0.0006959,
  "wall_ms": 981.9823999423534,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 1 次调用

原始回答：

````text
```json
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback on prior material and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1409,
  "completion_tokens": 302,
  "reasoning_tokens": 219,
  "response_reported_cost_usd": 0.00218925,
  "wall_ms": 4018.7505000503734,
  "local_error": null
}
```

### Gemini 3.8 Flash · N01 · 第 2 次调用

原始回答：

````text
{
  "status": "no_action",
  "actions": [],
  "reason": "The sender is only providing positive feedback and requests no action.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Looks great. I like it!"
    }
  ]
}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1611,
  "completion_tokens": 409,
  "reasoning_tokens": 334,
  "response_reported_cost_usd": 0.002742,
  "wall_ms": 4750.226700096391,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 1 次调用

原始回答：

````text
```json
{
  "sources": [
    {
      "source_id": "attachment:1",
      "relevance": "decisive",
      "reason": "The email directly instructs the recipient to review the attached invoice instructions to determine their next step.",
      "evidence": [
        {
          "source_id": "body",
          "quote": "Please check the attached invoice instructions for your next step."
        }
      ]
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 775,
  "completion_tokens": 367,
  "reasoning_tokens": 256,
  "response_reported_cost_usd": 0.0019575,
  "wall_ms": 4289.634299930185,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 2 次调用

原始回答：

````text
{"sources": [{"source_id": "attachment:1", "relevance": "decisive", "reason": "The sender explicitly directs the recipient to check the attached instructions to determine their next step, delegating the required action/content to the attachment.", "evidence": [{"source_id": "body", "quote": "Please check the attached invoice instructions for your next step."}]}]}
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1005,
  "completion_tokens": 302,
  "reasoning_tokens": 221,
  "response_reported_cost_usd": 0.00188625,
  "wall_ms": 4841.576800099574,
  "local_error": null
}
```

### Gemini 3.8 Flash · E01 · 第 3 次调用

原始回答：

````text
```json
{
  "status": "action",
  "actions": [
    {
      "kind": "perform_task",
      "text": "Approve invoice INV-104",
      "deadline": "2026-10-01",
      "evidence": [
        {
          "source_id": "attachment:1",
          "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
        }
      ]
    }
  ],
  "reason": "The sender directs you to the attached instructions, which ask you to approve invoice INV-104 by October 1, 2026.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Please check the attached invoice instructions for your next step."
    },
    {
      "source_id": "attachment:1",
      "quote": "Alex, please approve invoice INV-104 by 2026-10-01."
    }
  ]
}
```
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Google",
  "request_max_tokens": 2048,
  "finish_reason": "stop",
  "native_finish_reason": "STOP",
  "prompt_tokens": 1477,
  "completion_tokens": 1757,
  "reasoning_tokens": 1502,
  "response_reported_cost_usd": 0.0076965,
  "wall_ms": 13597.290700068697,
  "local_error": null
}
```

### GLM-5.3 Flash · C11 · 第 1 次调用

原始回答：

````text
null
````

接口返回字段摘录（费用为该响应报告值，完整审计仍看 billing.json）：

```json
{
  "provider": "Relace",
  "request_max_tokens": 2048,
  "finish_reason": "length",
  "native_finish_reason": "length",
  "prompt_tokens": 1579,
  "completion_tokens": 2048,
  "reasoning_tokens": 2069,
  "response_reported_cost_usd": 0.001079265,
  "wall_ms": 27332.371900090948,
  "local_error": "Model API response has no text completion (finish_reason=length, completion_tokens=2048)"
}
```

## Gemini 的失败链，按实际回答解释

N01：Flash Lite 第一次已经写出正确的 no_action，但是开头/结尾都有围栏。解析器未进入 status 字段就报错。重试的回答仍有围栏，于是再次拒收，最终输出由系统回退成 needs_review。这不是模型把赞许邮件理解成任务。Flash 第一次也有围栏，但重试返回裸 JSON，才被接受。

E01：Flash 第一次规划有围栏，第二次规划修复为裸 JSON，用掉唯一修复；第三次任务提取已给出批准发票的 action，但又有围栏。各阶段共享一次修复，没有第二次机会，系统最终复核。正文和任务其实很短，失败来自串联的格式验证与预算规则。

## GLM 为什么短答案也会达到上限

这次请求的 max_tokens=2048 没有另外控制 reasoning。多数 OpenRouter provider 会把模型推理与最终回答合并计入输出上限。可能最终答案只需一两百 token，但模型在输出答案前已经使用了大量推理 token。官方说明明确包含 finish_reason=length、content 为空且推理仍收费的情况：[OpenRouter reasoning tokens 文档](https://openrouter.ai/docs/guides/best-practices/reasoning-tokens)。

C11 的事实是：接口返回 finish_reason=length、completion_tokens=2048、content=null，同时有大量推理输出；因此程序根本没有收到最终 JSON。请求未显式设置 reasoning，当前推理默认值不受实验统一控制。这应归类为输出/推理预算兼容失败，不能判为已经给出错误最终答案。

该条 provider 报告 reasoning_tokens=2069，竟然大于 completion_tokens=2048，两字段不完全自洽。保留原值并标注计数差异，不使用两者相减去杜撰可见输出长度，也不声称精确到 token 的消耗分配。可确认的行为依据是 length 和 content=null；原因与文档所述预算耗尽一致。

我的设计问题在于：以“最终 JSON 很短”为理由设置统一 cap，却没有单独校验各家的默认推理行为。这一设置既不能证明 GLM 能力差，也不足以支持公平的纯模型能力排名。

## 所有达到上限的调用

| 模型 | 案例 / 调用 | provider | 最终正文字符数 | completion tokens | reasoning tokens |
| --- | --- | --- | ---: | ---: | ---: |
| Gemini 3.8 Flash | A20 / 1 | Google | 285 | 2044 | 1963 |
| Gemini 3.8 Flash | A20 / 2 | Google | 297 | 2044 | 1964 |
| GLM-5.3 Flash | C11 / 1 | Relace | 0 | 2048 | 2069 |
| GLM-5.3 Flash | C02 / 2 | Together | 0 | 2048 | 2048 |
| GLM-5.3 Flash | C03 / 1 | StreamLake | 0 | 2048 | 2049 |
| GLM-5.3 Flash | C13 / 1 | StreamLake | 461 | 2048 | 1950 |
| GLM-5.3 Flash | C12 / 1 | SiliconFlow | 761 | 2048 | 1859 |
| GLM-5.3 Flash | C10 / 1 | SiliconFlow | 460 | 2048 | 1927 |
| Gemini 3.8 Flash | E08 / 3 | Google | 232 | 2044 | 1964 |
| GLM-5.3 Flash | S02 / 2 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S02 / 2 | Google | 293 | 2044 | 1964 |
| GLM-5.3 Flash | S04 / 3 | Together | 0 | 2048 | 2048 |
| Gemini 3.8 Flash | S04 / 3 | Google | 271 | 2044 | 1962 |

## 11. 两模型消融结果（已完成）

2026-10-03 新加坡时间08:56完成，GPT-6 Luna与Claude Sonnet 5.5各250分析，共500/500。579次请求，冻结核心、提示、解析与接口配置均未改变；强制JSON升级未混入本轮。500条消融输出已完成Codex语义复核，见第12节；不等同独立人工复核。

本轮实际扣费 **1.8797272 USD**，579/579 generation账单完整且与前后使用计数一致。横评与消融累计 **3.2245285 USD**，5 USD总额度剩余 **1.7754715 USD**。推理刚结束时计数尚未完全结算，已以最终账单核对后的计数更新；不使用token估算作为费用。阶段一缺失账单记录的审计限制仍保留。

### 完整条件表

这里的正确率是严格状态匹配，不是完整任务语义评分。不同条件分母不同；机制结论使用下方同案例配对表。重复运行24条为8案例各3次，不能当24个独立案例。

| 条件 | Luna 状态正确 | Luna P50 秒 / 实际费用 USD | Sonnet 状态正确 | Sonnet P50 秒 / 实际费用 USD |
| --- | ---: | ---: | ---: | ---: |
| 完整方案 | 58/60 | 3.59 / 0.013395 | 59/60 | 3.00 / 0.480094 |
| 一次提示基线 | 44/60 | 2.98 / 0.007212 | 44/60 | 2.73 / 0.382232 |
| 无历史线程 | 9/12 | 3.78 / 0.002504 | 9/12 | 4.66 / 0.097756 |
| 无外部读取 | 3/17 | 2.89 / 0.001478 | 3/17 | 2.97 / 0.126428 |
| 读取全部来源 | 16/17 | 3.04 / 0.002552 | 16/17 | 2.87 / 0.111690 |
| 无模型修复 | 59/60 | 3.49 / 0.010359 | 58/60 | 2.87 / 0.464616 |
| 重复运行 | 21/24 | 2.84 / 0.004734 | 21/24 | 2.93 / 0.174678 |

### 同案例对照

每行的完整方案只取与消融条件相同案例，避免拿12/17案例与全量60案例直接比较。费用同样在共同案例中比较。

| 模型 | 移除/替换因素 | 完整方案正确 | 条件正确 | 完整方案费用 / 条件费用 USD |
| --- | --- | ---: | ---: | ---: |
| GPT-6 Luna | 一次提示基线 | 58/60 | 44/60 | 0.013395 / 0.007212 |
| GPT-6 Luna | 无历史线程 | 11/12 | 9/12 | 0.004282 / 0.002504 |
| GPT-6 Luna | 无外部读取 | 16/17 | 3/17 | 0.005275 / 0.001478 |
| GPT-6 Luna | 读取全部来源 | 16/17 | 16/17 | 0.005275 / 0.002552 |
| GPT-6 Luna | 无模型修复 | 58/60 | 59/60 | 0.013395 / 0.010359 |
| Claude Sonnet 5.5 | 一次提示基线 | 59/60 | 44/60 | 0.480094 / 0.382232 |
| Claude Sonnet 5.5 | 无历史线程 | 11/12 | 9/12 | 0.114298 / 0.097756 |
| Claude Sonnet 5.5 | 无外部读取 | 17/17 | 3/17 | 0.184226 / 0.126428 |
| Claude Sonnet 5.5 | 读取全部来源 | 17/17 | 16/17 | 0.184226 / 0.111690 |
| Claude Sonnet 5.5 | 无模型修复 | 59/60 | 58/60 | 0.480094 / 0.464616 |

### 可以支持的机制结论与边界

**外部读取的作用最明显。** 在同17案例上，Luna从16/17降至3/17，Sonnet从17/17降至3/17。无读取时两模型均16/17转复核，很多不是错误地猜测任务，而是缺少必要内容后谨慎回退。说明正文无法替代附件/链接信息；可用解决率下降，但安全回退仍有效。

**线程有跨家族作用。** 同12案例，两个模型都是完整方案11/12、无线程9/12。Luna在C02/C09失去上下文后复核；Sonnet在C10复核、C13把原先应复核的情况当动作。它们失分案例并非完全相同，不能只报告一个“下降两分”。

**一次提示基线不够覆盖本任务。** 两模型均44/60，完整方案分别58/60、59/60。基线同时移除了读取、修复与分段合并，是架构差异；不能把这14/15分全部归因于某一个组件。

**选择性规划与read-all的总分接近，但并非没有价值。** Luna完整方案和read-all同为16/17，却是不同失败：完整方案E07输出格式失败，read-all读取S07的无关损坏材料而复核。Sonnet完整17/17、read-all16/17，损失同为S07。规划能避开无关损坏来源；read-all少一次规划调用更省钱。准确率、故障暴露及费用的取舍都应报告。

**不能宣称修复稳定提高总分。** Luna完整58/60、无修复59/60；Sonnet完整59/60、无修复58/60。这是不同模型请求，格式/判断存在波动，不能解读成Luna修复有害、Sonnet修复一定有益。Sonnet总分差来自C10的语义判断变化，不是该案例触发修复。Luna完整E07修复前后都格式失败，而无修复组该案例首答正常。应看实际修复事件、原文质量和失败链，必要时用固定首答重放隔离修复的作用。

**原文修复机制有真实触发。** Luna完整方案3次尝试：C12缺解释证据修复成功、E07格式修复失败、S02引文修复成功。S02候选相似度0.994，但存在“$25k-$50”与“$25k-$50k”的关键差异；候选未自动接受，模型重新生成后通过验证。Sonnet完整C12引文修复成功。这是原文验证成功；本次逐条语义复核确认C12解释得到恢复、S02最终判断仍为无任务，见第12节。

**重复性局部良好，不代表60案例全部稳定。** 预先指定8案例、每模型各3次，16个模型/案例组的状态与动作数都一致。每模型严格21/24，三次失分均为C11的标注分歧；允许解释则24/24。第12节进一步复核这些重复输出：两模型均24/24语义交付通过，措辞有差异；不据此推断所有案例稳定。

完整方案新一轮与横评不同：Luna横评59/60、本轮58/60；Sonnet横评58/60、本轮59/60。因此此前一分差不应当作确定的模型排名。

### 关键失败的原始回答

Luna完整方案E07：第1次调用是正常阅读规划。第2次提取与第3次修复均报 Extra data：完整JSON对象结尾多了两个字符，一个双引号和一个右花括号。解析完有效对象后仍有多余文字，导致拒收。说明格式失败并非只发生在Gemini。以下为接口的最终回答content逐字展示，非模型推理过程。

第1次调用：

````text
{"sources":[{"source_id":"link:1","relevance":"decisive","reason":"The message points to the client request as its main content, so the link is needed to determine what is being requested.","evidence":[{"source_id":"body","quote":"The client request is at https://example.org/actionmail/client-request"}]}]}
````

第2次调用：

````text
{"status":"action","actions":[{"kind":"perform_task","text":"Send Maya the updated budget.","deadline":"2026-10-02","evidence":[{"source_id":"link:1","quote":"Alex, send the updated budget to Maya by 2026-10-02."}]}],"reason":"The linked client request directs Alex to send Maya the updated budget by the stated date.","evidence":[{"source_id":"body","quote":"The client request is at https://example.org/actionmail/client-request"},{"source_id":"link:1","quote":"Alex, send the updated budget to Maya by 2026-10-02."}]}"}
````

第3次调用：

````text
{"status":"action","actions":[{"kind":"perform_task","text":"Send Maya the updated budget.","deadline":"2026-10-02","evidence":[{"source_id":"link:1","quote":"Alex, send the updated budget to Maya by 2026-10-02."}]}],"reason":"The linked client request directs Alex to send Maya the updated budget by the stated date.","evidence":[{"source_id":"body","quote":"The client request is at https://example.org/actionmail/client-request"},{"source_id":"link:1","quote":"Alex, send the updated budget to Maya by 2026-10-02."}]}"}
````

结果与账单：`results/ablation/`；同案例变化及解释：`paired_status_changes.json`。消融语义复核见第12节；六模型横评360条语义复核、独立测试集和接口强制JSON升级仍未完成。目前无推理进程运行。

## 12. 以旧Luna人工裁决为参考的语义复核

本节回应“修复机制的总分变化存在波动”：该说法指两组独立模型请求的严格状态分数出现±1分，不是同一条回答经过修复后时好时坏。Luna完整58/60、无修复59/60；Sonnet完整59/60、无修复58/60。C11已有允许的替代解释却仍被严格分数扣分；C12即使解析失败后的兜底恰好也是复核，也不能代表解释合格。下面重新阅读任务内容、原文依据和失败链。

### 参考与评审方法

参考用户当时使用Luna的 `data/owner_adjudications/`（整理前原路径为 `ActionMail/backup/v2.0/results/evaluation/v2-full-20261001/`），尤其是 `adjudication.json`、`reference_adjudication.json` 和旧原始输出。该文件明确保存的用户裁决只有A16、C11、C13、E10四条，不能称60条均已完成人工语义标注。本次由 **Codex进行AI语义复核**，对冻结的60条输入及500条消融输出的不同回答逐一检查；重复或相同回答保留独立行，未另请人工评审，也未再调用实验模型。原始输入、gold、回答和原始分数均未修改。

核查目标收件人及新旧任务归属、义务强度、独立任务单位、时间含义、原文是否支持结论，以及复核是否合理。缺执行资料不自动否定可识别任务；缺决定任务内容的材料则需要复核。原文匹配与语义支持分别看。

沿用原裁决：A16需要两项任务；C11允许保守复核或只回答座位位置；C13必须考虑缺失材料和旧邮件收件人；E10不能未读链接便断言无任务。C11输出一个允许的回答任务时以1项为分母，保守复核时为0项；本轮所有组均采取动作解释。其余分母维持冻结参考。

### 语义结果

“交付通过”要求：允许的状态和数量、所有预期与提出的任务均正确匹配、归属/义务/期限/证据/复核标准没有no。这包含解释可用性，因此仅报解析错误、没有原文证据的复核输出不算通过。任务匹配另列；完整任务须能定位对象或问题，缺细节的泛化任务记为未完整匹配。

| 条件 | GPT-6 Luna：语义交付通过 | Luna：匹配任务 / 预期任务 | Claude Sonnet 5.5：语义交付通过 | Sonnet：匹配任务 / 预期任务 |
| --- | ---: | ---: | ---: | ---: |
| 完整方案 | 59/60 | 31/32 | 60/60 | 32/32 |
| 一次提示基线 | 45/60 | 19/32 | 42/60 | 18/32 |
| 无历史线程 | 9/12 | 4/7 | 6/12 | 4/7 |
| 无外部读取 | 3/17 | 0/13 | 3/17 | 0/13 |
| 读取全部来源 | 15/17 | 12/13 | 15/17 | 12/13 |
| 无模型修复 | 59/60 | 32/32 | 58/60 | 31/32 |
| 重复运行 | 24/24 | 15/15 | 24/24 | 15/15 |

60案例有27条action邮件，但多任务案例和C11允许解释使任务单位总数为32；不是把32当邮件数量。重复运行分母24为8案例×3次，任务分母15也含重复，不代表15个独立任务。各消融分母不同，仍须配对比较。无线程共同12案例的完整方案，两模型都是12/12语义交付、7/7任务；无线程分别降至9/12、6/12。无外部读取/读取全部共同17案例的完整方案，Luna16/17交付、12/13任务，Sonnet17/17交付、13/13任务。

完整方案任务语义精确率两模型均100%；召回率Luna31/32=96.9%，Sonnet32/32=100%。Luna缺的一项是E07格式拒收；该日志中的可读JSON部分实际上正确识别了任务，但无法交付。Sonnet C10已识别Duke合同及具体变更事项，按冻结的广义回应任务匹配1项；未直接写出“是否正式修约申请”的问题，另外标记具体性不足，不能说措辞与Luna一样精确。

这些数字不等于统一“总质量分”。S04确认投影仪的任务文字正确时仍匹配，但kind不合参考的answer_question另记；Luna完整/全读/无修复与Sonnet无修复均出现此分类差异。字段类型差异不直接否定相同任务义务。CSV的false_additions字段是提出但未完整匹配的任务数，含信息不足的泛化任务，不能全部翻译为幻觉新增。

### 核心差异与修复机制

- **C12揭示状态分数盲点。** 两模型完整方案均在修复后给出“新正文为空/旧任务归属不明”的解释和原文证据；无修复组均只有格式/引文错误与空证据。两者状态同为needs_review，原评分都给正确，本次只有解释完整的版本通过。修复确实改善了可解释性；但独立运行并非相同首答的随机对照，不能据此估计纯因果收益。
- **E07不能归咎于修复伤害理解。** Luna完整方案首答与修复答都识别对了预算任务及期限，但都在完整JSON后多出字符，最终没有交付。无修复组首答合法，匹配同一任务。因此总分差来自两次运行首答格式不同；当前修复没救回这条，不是把正确任务改错。
- **C10更体现模型解释差异。** Luna保留正式修约问题；Sonnet完整方案给广义回应，提示基线及无修复组则过度保守复核。该案例未触发修复，Sonnet严格状态的一分改善不能写成修复收益。
- **线程损失比状态分数显示得更大。** Sonnet无线程C11额外要求提供三类数据；C02只说恢复“引用文件”，没有可定位文件；C09只说回答WIC问题，丢失Medicine Bow容量影响；C13忽略缺关键材料。Luna无线程C10也只说回应Duke合同号，丢失具体问题。泛化任务与原文凭空新增任务分开说明。
- **安全复核与成功交付分开。** 移除附件/页面后，大多数复核在当时可见内容下合理，但完整任务没有交付。E04/E05/E09虽含FYI/awareness，现行冻结政策要求读取主内容指针，本次不事后修改gold或政策；没有原文证据的系统拦截另算解释缺失。S07不同：隐私footer明确无关，正文任务自包含，因该链接不可读而复核是不必要阻断。
- **read-all的额外盲点。** S08损坏关键工作簿，复核正确；read-all组却没有引文，解释质量不合格，因此语义交付15/17而状态为16/17。完整方案读取失败时保留正文依据。
- **预选8案例局部语义稳定。** 两模型各24次重复输出均保持允许的任务含义、归属和期限；只有措辞变化。不能推断60案例全部稳定。

### 保存的回答示例

以下“最终记录”逐字保留日志中已解析的字符串，展示最终用户获得的内容；API原始content示例从调用记录读取，未展示内部推理过程。

Luna完整方案C12：修复后的最终记录：

```json
{
  "status": "needs_review",
  "actions": [],
  "reason": "The newest message has an empty body, so Marie’s current next steps cannot be determined. The older amendment request was addressed to Sara, not Marie.",
  "evidence": [
    {
      "source_id": "subject",
      "quote": "CHASE - READY TO EXECUTE ASAP!"
    },
    {
      "source_id": "thread:1:headers",
      "quote": "To: Shackleton, Sara"
    },
    {
      "source_id": "thread:1",
      "quote": "Please review the amendment and, if satisfactory, arrange for the execution\nof two copies."
    }
  ]
}
```

Luna无修复C12：系统兜底最终记录：

```json
{
  "status": "needs_review",
  "actions": [],
  "reason": "Invalid V2 model response: Explanation must cite available original text",
  "evidence": []
}
```

Sonnet完整方案C12：修复后的最终记录：

```json
{
  "status": "needs_review",
  "actions": [],
  "reason": "The newest message body is empty, so it gives Marie Heard no explicit request. The subject suggests urgency about executing a Chase document, but it does not say what Marie should do. The only detailed request is in an older message addressed to Sara, and the newest message does not clearly renew it for Marie. The amendment it refers to was also not supplied.",
  "evidence": [
    {
      "source_id": "subject",
      "quote": "CHASE - READY TO EXECUTE ASAP!"
    },
    {
      "source_id": "thread:1",
      "quote": "arrange for the execution\nof two copies"
    }
  ]
}
```

Sonnet无修复C12：系统兜底最终记录：

```json
{
  "status": "needs_review",
  "actions": [],
  "reason": "Invalid V2 model response: Evidence quote is absent from source: body",
  "evidence": []
}
```

Sonnet无线程C11：新增义务：

```json
{
  "status": "action",
  "actions": [
    {
      "kind": "answer_question",
      "text": "Tell Mike where you sit.",
      "deadline": null,
      "evidence": [
        {
          "source_id": "body",
          "quote": "Where do you sit?"
        }
      ]
    },
    {
      "kind": "perform_task",
      "text": "Provide the three requested gas curve items: the curve relationship list, the volatility curve list with correlation methodology, and the volumetric position data as of 11/30/01.",
      "deadline": null,
      "evidence": [
        {
          "source_id": "body",
          "quote": "just to confirm, we are looking for:"
        },
        {
          "source_id": "body",
          "quote": "Volumetric poistion data by curve for gas as of 11/30/01"
        }
      ]
    }
  ],
  "reason": "Mike directly asks where the recipients sit and restates the three gas curve deliverables he is looking for. The email gives no explicit deadline, and 1:30pm has no date.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Where do you sit?"
    },
    {
      "source_id": "body",
      "quote": "we are looking for:"
    }
  ]
}
```

Sonnet无线程C02：任务对象缺失：

```json
{
  "status": "action",
  "actions": [
    {
      "kind": "perform_task",
      "text": "Restore the file referenced in the forwarded File Restore Request.",
      "deadline": null,
      "evidence": [
        {
          "source_id": "body",
          "quote": "Please restore the below referenced file as requested."
        }
      ]
    }
  ],
  "reason": "Lynn Blair directly asks the target recipient to restore the referenced file. This is a clear request, and no deadline is given.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Please restore the below referenced file as requested."
    }
  ]
}
```

Luna无线程C10：具体问题缺失：

```json
{
  "status": "action",
  "actions": [
    {
      "kind": "follow_up",
      "text": "Respond regarding Duke k#27579.",
      "deadline": null,
      "evidence": [
        {
          "source_id": "body",
          "quote": "Yes, but we are waiting to hear from Darrell on this one."
        }
      ]
    }
  ],
  "reason": "The newest message says the sender is waiting to hear from Darrell about this matter.",
  "evidence": [
    {
      "source_id": "body",
      "quote": "Yes, but we are waiting to hear from Darrell on this one."
    }
  ]
}
```

GPT-6 Luna C12 第1次调用的API原始content：

````text
{"status":"needs_review","actions":[],"reason":"The newest message has an empty body, so Marie’s current next steps cannot be determined; the older request was addressed to Sara. No body text is available to quote.","evidence":[]}
````

GPT-6 Luna C12 第2次调用的API原始content：

````text
{"status":"needs_review","actions":[],"reason":"The newest message has an empty body, so Marie’s current next steps cannot be determined. The older amendment request was addressed to Sara, not Marie.","evidence":[{"source_id":"subject","quote":"CHASE - READY TO EXECUTE ASAP!"},{"source_id":"thread:1:headers","quote":"To: Shackleton, Sara"},{"source_id":"thread:1","quote":"Please review the amendment and, if satisfactory, arrange for the execution of two copies."}]}
````

Claude Sonnet 5.5 C12 第1次调用的API原始content：

````text
{"status":"needs_review","actions":[],"reason":"The newest message has an empty body, so it gives no explicit request to Marie Heard. The subject, \"CHASE - READY TO EXECUTE ASAP!\", suggests urgency. The only detailed request is in an older thread to Sara, and the newest message does not renew it for Marie.","evidence":[{"source_id":"body","quote":"CHASE - READY TO EXECUTE ASAP!"},{"source_id":"thread:1","quote":"Please review the amendment and, if satisfactory, arrange for the execution of two copies."}]}
````

Claude Sonnet 5.5 C12 第2次调用的API原始content：

````text
{"status":"needs_review","actions":[],"reason":"The newest message body is empty, so it gives Marie Heard no explicit request. The subject suggests urgency about executing a Chase document, but it does not say what Marie should do. The only detailed request is in an older message addressed to Sara, and the newest message does not clearly renew it for Marie. The amendment it refers to was also not supplied.","evidence":[{"source_id":"subject","quote":"CHASE - READY TO EXECUTE ASAP!"},{"source_id":"thread:1","quote":"arrange for the execution of two copies"}]}
````

### 如何使用这些结论

后续保留Luna作为主要低成本实验模型、Sonnet作为跨家族对照。完整方案在本开发集上的意义识别差距很小；线程丢失时的解释方式、保守程度、字段类型和费用差异更值得报告。保留原文验证与一次修复，因为C12/S02显示真实解释和引文质量收益；当前结果不支持宣称其稳定提高总体准确率。要隔离修复因果作用，需要固定首答重放或机制注入，属于后续实验，不混入本次已冻结成绩。

逐条复核：`results/ablation/semantic_review.csv`（500行，均有评审身份与中文备注）；汇总：`semantic_summary.json`；补充的具体性、错误类型、原裁决路径与文件hash：`semantic_audit.json`。本次完成的是消融500条AI复核，六模型横评360条全量语义复核仍待完成；独立测试集、独立人工评审及强制JSON升级仍未完成。无新增付费调用，累计实际费用仍为3.224528503 USD。
