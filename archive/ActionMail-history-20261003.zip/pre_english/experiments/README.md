# ActionMail 实验

老师阅读实验时，从本页进入即可。最终课程报告见 [FINAL_REPORT.pdf](../report/FINAL_REPORT.pdf)，证据解释见 [report/README.md](../report/README.md)。

## 阅读顺序

1. [实验报告](REPORT.md)：结果、模型差异、原始回答、公平性分析和消融选型。这是唯一持续维护的结果报告。
2. [实验方案](PROTOCOL.md)：问题、数据、指标、冻结条件、预算及后续消融矩阵。
3. 核对数据：[模型名称对照](results/model-benchmark/model_mapping.csv)、[每案例数据](results/model-benchmark/case_metrics.csv)、[每轮数据](results/model-benchmark/turn_metrics.csv)。

## 当前进度（实验已封板）

六模型各60案例，共360次分析已完成。横评与消融实际累计费用3.224528503 USD，总上限5 USD。消融500条已完成Codex语义复核（非独立人工复核）；用户已选择 GPT-6 Luna + Claude Sonnet 5.5，500次消融已完成。进度见 results/ablation/progress.json。横评Sonnet费用口径更正见 `results/billing_clarification.json` 和主报告第2节，原冻结派生表保留。

2026-10-03已封板，进入课程报告与demo制作。冻结数据和输出的校验清单见 `results/finalization.json`；验收及结论边界见 `PROTOCOL.md` 最后一节。

60案例曾用于开发调参，是开发/回归数据，不是盲测。格式兼容、共享重试、推理预算和服务商影响均已在报告披露。

## 目录

```text
experiments/
├── README.md              阅读入口
├── REPORT.md              唯一主报告，内含原始回答附录
├── PROTOCOL.md            当前实验方案
├── code/                  当前实验代码、配置及测试
├── data/frozen-core/      60案例、原始来源与冻结业务核心
├── results/
│   ├── model-benchmark/   横评数据、指标、请求日志和账单
│   ├── rules-baseline/    规则基线数据
│   └── ablation/          两模型消融及实时进度
└── data/owner_adjudications/ 原有四条用户裁决的原始证据
```

`code/` 是唯一当前实验代码；`data/frozen-core/runtime/` 是复现本次实验所需的业务核心快照，避免正在开发的相邻 ActionMail 项目改变实验行为。过去的快照及恢复脚本已归档，不作为当前入口。

原始日志保留运行时路径及字节。开发历史已集中到根目录 archive/ 的唯一压缩包；提交包不包含该归档。封板文件的哈希与相对路径不变。

## 本地检查

在项目根目录执行：

```powershell
python experiments/code/pipeline.py --help
python -m unittest discover -s experiments/code/tests
```

这些检查不调用真实模型。code/configs/model-benchmark.json 是批准的六模型/5 USD配置；其他配置用于已有工程检查，不代表付费授权。

重新评分只更新结构化指标和复核表，不生成另一份简短报告。文字结论统一编辑 REPORT.md。不要直接运行归档中的暂停恢复脚本。

## 给老师提交什么

提交本页、主报告、方案、code/、data/ 和 results/。不要提交 archive/、本地 .env、缓存或任何API key。.env 是本机凭证文件。
