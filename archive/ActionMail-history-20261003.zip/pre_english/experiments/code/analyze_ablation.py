"""Update the single human report from completed ablation logs; no inference."""
from pathlib import Path
import json
root=Path(__file__).resolve().parent.parent
folder=root/'results/ablation'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
summary=read(folder/'summary.json'); operations=read(folder/'operations.json')
config=read(folder/'config.json'); meta=read(folder/'run.json'); billing=read(folder/'billing.json')
rows=[json.loads(x) for x in (folder/'rows.jsonl').read_text(encoding='utf-8').splitlines()]
calls=[json.loads(x) for x in (folder/'calls.jsonl').read_text(encoding='utf-8').splitlines()]
from pipeline import scheduled_tasks,jsonl
expected={(a['id'],c['case_id'],t) for a,c,t in scheduled_tasks(config,jsonl(root/'data/frozen-core/dataset.jsonl'),None)}
observed={(r['arm'],r['case_id'],r['trial']) for r in rows}
assert meta['complete'] and len(rows)==500 and len(observed)==500 and observed==expected
assert billing['reconciled'] and billing['generation_cost_calls']==579
global_bill=read(folder/'global-billing.json')
if 'snapshot_at_inference_end' not in global_bill:
    global_bill['snapshot_at_inference_end']=global_bill['after']
global_bill['after']=billing['after']
global_bill['actual_counter_delta_usd']=billing['after']['key_usage_usd']-global_bill['baseline']['key_usage_usd']
global_bill['updated_from']='Final settled ablation billing audit; replaces provisional inference-end counter.'
(folder/'global-billing.json').write_text(json.dumps(global_bill,indent=2)+'\n',encoding='utf-8')
names={'m01':'GPT-6 Luna','m06':'Claude Sonnet 5.5'}
modes=[('full','完整方案'),('prompt_only','一次提示基线'),('no_thread','无历史线程'),('no_external','无外部读取'),('read_all','读取全部来源'),('no_repair','无模型修复'),('stability','重复运行')]
lines=['## 11. 两模型消融结果（已完成）','',
'2026-10-03 新加坡时间08:56完成，GPT-6 Luna与Claude Sonnet 5.5各250分析，共500/500。579次请求，冻结核心、提示、解析与接口配置均未改变；强制JSON升级未混入本轮。语义复核仍pending。', '',
f"本轮实际扣费 **{billing['key_usage_delta_usd']:.7f} USD**，579/579 generation账单完整且与前后使用计数一致。横评与消融累计 **{global_bill['actual_counter_delta_usd']:.7f} USD**，5 USD总额度剩余 **{5-global_bill['actual_counter_delta_usd']:.7f} USD**。推理刚结束时计数尚未完全结算，已以最终账单核对后的计数更新；不使用token估算作为费用。阶段一缺失账单记录的审计限制仍保留。", '',
'### 完整条件表','',
'这里的正确率是严格状态匹配，不是完整任务语义评分。不同条件分母不同；机制结论使用下方同案例配对表。重复运行24条为8案例各3次，不能当24个独立案例。', '',
'| 条件 | Luna 状态正确 | Luna P50 秒 / 实际费用 USD | Sonnet 状态正确 | Sonnet P50 秒 / 实际费用 USD |',
'| --- | ---: | ---: | ---: | ---: |']
for mode,label in modes:
 values=[]
 for key in names:
  arm=f'{mode}_{key}'; m=summary['arms'][arm]; o=operations['by_arm'][arm]
  values.extend([f"{m['strict_status_match']}/{m['analyses']}",f"{o['case_wall_ms']['p50']/1000:.2f} / {o['known_billed_cost_usd']:.6f}"])
 lines.append('| '+label+' | '+' | '.join(values)+' |')
lines+=['','### 同案例对照','',
'每行的完整方案只取与消融条件相同案例，避免拿12/17案例与全量60案例直接比较。费用同样在共同案例中比较。', '',
'| 模型 | 移除/替换因素 | 完整方案正确 | 条件正确 | 完整方案费用 / 条件费用 USD |',
'| --- | --- | ---: | ---: | ---: |']
changes=[]
case_metrics={}
import csv
with (folder/'case_metrics.csv').open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):case_metrics[(r['arm'],r['case_id'],int(r['trial']))]=r
for key,name in names.items():
 for mode,label in modes[1:-1]:
  arm=f'{mode}_{key}'; pair=summary['paired_comparisons'][arm]; n=pair['paired_analyses']
  selected={r['case_id'] for r in rows if r['arm']==arm}
  ref=f'full_{key}'
  def cost(a):return sum(float(r.get('billed_cost_usd') or 0) for (ar,c,t),r in case_metrics.items() if ar==a and c in selected and t==1)
  lines.append(f"| {name} | {label} | {pair['comparator_metrics']['strict_status_match']}/{n} | {pair['arm']['strict_status_match']}/{n} | {cost(ref):.6f} / {cost(arm):.6f} |")
  reference={r['case_id']:r for r in rows if r['arm']==ref}
  for r in rows:
   if r['arm']!=arm:continue
   f=reference[r['case_id']]; gold=r['gold']['status']
   a=f['result']['prediction']['status']; b=r['result']['prediction']['status']
   if a!=b:changes.append({'model':name,'condition':label,'case_id':r['case_id'],'gold':gold,'full':a,'condition_status':b,'full_reason':f['result']['prediction']['reason'],'condition_reason':r['result']['prediction']['reason']})
(folder/'paired_status_changes.json').write_text(json.dumps(changes,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
lines+=['', '### 可以支持的机制结论与边界','',
'**外部读取的作用最明显。** 在同17案例上，Luna从16/17降至3/17，Sonnet从17/17降至3/17。无读取时两模型均16/17转复核，很多不是错误地猜测任务，而是缺少必要内容后谨慎回退。说明正文无法替代附件/链接信息；可用解决率下降，但安全回退仍有效。', '',
'**线程有跨家族作用。** 同12案例，两个模型都是完整方案11/12、无线程9/12。Luna在C02/C09失去上下文后复核；Sonnet在C10复核、C13把原先应复核的情况当动作。它们失分案例并非完全相同，不能只报告一个“下降两分”。', '',
'**一次提示基线不够覆盖本任务。** 两模型均44/60，完整方案分别58/60、59/60。基线同时移除了读取、修复与分段合并，是架构差异；不能把这14/15分全部归因于某一个组件。', '',
'**选择性规划与read-all的总分接近，但并非没有价值。** Luna完整方案和read-all同为16/17，却是不同失败：完整方案E07输出格式失败，read-all读取S07的无关损坏材料而复核。Sonnet完整17/17、read-all16/17，损失同为S07。规划能避开无关损坏来源；read-all少一次规划调用更省钱。准确率、故障暴露及费用的取舍都应报告。', '',
'**不能宣称修复稳定提高总分。** Luna完整58/60、无修复59/60；Sonnet完整59/60、无修复58/60。这是不同模型请求，格式/判断存在波动，不能解读成Luna修复有害、Sonnet修复一定有益。Sonnet总分差来自C10的语义判断变化，不是该案例触发修复。Luna完整E07修复前后都格式失败，而无修复组该案例首答正常。应看实际修复事件、原文质量和失败链，必要时用固定首答重放隔离修复的作用。', '',
'**原文修复机制有真实触发。** Luna完整方案3次尝试：C12缺解释证据修复成功、E07格式修复失败、S02引文修复成功。S02候选相似度0.994，但存在“$25k-$50”与“$25k-$50k”的关键差异；候选未自动接受，模型重新生成后通过验证。Sonnet完整C12引文修复成功。成功是验证通过，不等于已完成任务语义审查。', '',
'**重复性局部良好，不代表60案例全部稳定。** 预先指定8案例、每模型各3次，16个模型/案例组的状态与动作数都一致。每模型严格21/24，三次失分均为C11的标注分歧；允许解释则24/24。未证明措辞/动作类型/语义均一致，也不能据此对所有案例推断稳定性。', '',
'完整方案新一轮与横评不同：Luna横评59/60、本轮58/60；Sonnet横评58/60、本轮59/60。因此此前一分差不应当作确定的模型排名。', '',
'### 关键失败的原始回答','',
'Luna完整方案E07：第1次调用是正常阅读规划。第2次提取与第3次修复均报 Extra data：完整JSON对象结尾多了两个字符，一个双引号和一个右花括号。解析完有效对象后仍有多余文字，导致拒收。说明格式失败并非只发生在Gemini。以下为接口的最终回答content逐字展示，非模型推理过程。']
for c in calls:
 if c['arm']=='full_m01' and c['case_id']=='E07':
  content=((c.get('transport') or {}).get('response_json') or {}).get('choices',[{}])[0].get('message',{}).get('content')
  lines+=['',f"第{c['call']}次调用：",'', '````text',content or 'null','````']
lines+=['','结果与账单：`results/ablation/`；同案例变化及解释：`paired_status_changes.json`。全量语义复核、独立测试集和接口强制JSON升级仍未完成。目前无推理进程运行。']
p=root/'REPORT.md'; s=p.read_text(encoding='utf-8')
marker='\n## 11.'
# Preserve the separately reviewed semantic section when refreshing log metrics.
semantic_tail = '\n## 12.' + s.split('\n## 12.', 1)[1] if '\n## 12.' in s else ''
if (folder/'semantic_summary.json').exists() and read(folder/'semantic_summary.json').get('complete'):
    lines = [line.replace('语义复核仍pending。', '500条消融输出已完成Codex语义复核，见第12节；不等同独立人工复核。')
             .replace('全量语义复核、独立测试集和接口强制JSON升级仍未完成。', '消融语义复核见第12节；六模型横评360条语义复核、独立测试集和接口强制JSON升级仍未完成。')
             for line in lines]
s=s.split(marker)[0]+'\n'+'\n'.join(lines)+'\n'+semantic_tail; p.write_text(s,encoding='utf-8')
for name in ['README.md','PROTOCOL.md']:
 p=root/name; s=p.read_text(encoding='utf-8')
 s=s.replace('500次消融正在运行','500次消融已完成').replace('实验二：机制消融（运行中）','实验二：机制消融（已完成）')
 s=s.replace('Luna与Sonnet各250分析、共500分析已启动。','Luna与Sonnet各250分析、共500分析已完成，579条账单核对一致。目前无模型调用。')
 s=s.replace('实际累计费用1.344801303 USD，总上限5 USD。','横评与消融实际累计费用3.224528503 USD，总上限5 USD。')
 s=s.replace('横评实际1.344801303 USD，剩余3.655198697 USD。','横评实际1.344801303 USD，消融实际1.879727200 USD，累计3.224528503 USD，剩余1.775471497 USD。')
 p.write_text(s,encoding='utf-8')
print('Verified canonical 500 observations and 579 bills; updated sole report. Actual global USD:',global_bill['actual_counter_delta_usd'])
