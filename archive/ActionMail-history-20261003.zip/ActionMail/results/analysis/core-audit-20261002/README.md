# Offline core audit, 2 October 2026

No model API calls, private mailbox access, calendar operations or source edits were performed. Original results and references remain intact. The audit replays the immutable saved model run and executes the existing deterministic rule function against the active 60-case input registry. It is not a new model evaluation or a completed semantic review.

## Files

- `summary.json`: strict and C11 sensitivity classification metrics, review metrics, cost/latency, deadline breakdown and check results.
- `case_checks.jsonl`: each case's rule/model prediction, quote checks, recorded-span hashes and reference comparisons.
- `provenance.json`: Git HEAD plus input/runtime/output-source hashes; stable during audit. These describe the audit, not a promise that another chat will leave the development tree unchanged.
- `semantic_review.csv`: 60-row review worksheet. Review fields are intentionally blank; no owner Pass judgments have been invented. Read original sources in the review UI/local corpus before filling them.

## Headline

Strict status match: model 59/60, rules 31/60, majority action 27/60. Fixing C11 to the approved action interpretation for all methods: model 60/60, rules 32/60. Accepted-outcome model status/count match: 60/60. Final quotes 129/129 exact; source and recorded-span hash checks pass in all 60 cases. Coverage hash identity is not complete semantic/content coverage.

Deadline rule: gold action plus exactly one predicted action with scalar reference deadline gives 22/22 matches, comprising ten non-null dates and twelve nulls. Existing 23/23 documentation needs an explicit denominator reconciliation; do not advertise 23 successful date extractions.

Existing offline checks executed: 96 tests pass, active 60-case registry validates. They are engineering evidence; fake provider/scripted model tests do not measure model quality. Paid experiment and semantic review status are tracked in `docs/core_experiments.md`.

## Reproduction

Use the pinned input/runtime hashes in provenance; load `evaluation/active_suite.json` with `load_suite`, preserving owner overrides and local `../data` dependencies. Apply unmodified `predict_rules(case.email)` to each case. Compare only status for the classification baseline; its one generic action is not a semantic extraction baseline. Load predictions from the immutable saved `cases.jsonl`; do not regenerate model replies.

For provenance checks, reconstruct the case's original source map with historical headers. Replay only the source IDs in saved successful `read_sources`, using `read_external_sources` with local bytes/snapshots. Match each explanation/task quote literally against its supplied source and rehash each recorded coverage interval. Classification FN counts an action case predicted no_action, review or error. Null metric denominators are reported as null. C11 sensitivity fixes the reference before scoring both systems, rather than selecting a reference based on each prediction. The semantic-review worksheet remains separate from these automated results.
