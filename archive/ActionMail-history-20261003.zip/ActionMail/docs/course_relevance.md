# Lecture relevance to ActionMail

Reviewed 2 October 2026. Text-skimming inventory: 28 local PDFs, 441 pages, across classes 1-6. This is a targeted content review, not a layout audit. Page numbers below are one-based PDF pages. Course sources remain local at `E:/NTU Learn/PE6201/Lecture/`; do not redistribute lecture text or originals into Git.

## Highest priority

| Local source | Pages | Apply to this project |
| --- | --- | --- |
| `class2/PE6201_Class2_C4_Evals_and_A1.pdf` | 3-7 | Silent failure; deterministic checks versus semantic judgment; judge calibration; metrics tied to useful outcomes. Class/schema accuracy cannot stand in for task completeness. |
| `class3/PE6201_Class3_C2_Steer_it_and_prove_it.pdf` | 9-10, 13-15 | Enforce and validate structured output; freeze evaluation before tuning; change one experimental factor at a time; distinguish meaningful improvement from different wording. |
| `class4/PE6201_Class4_C2_Build_it_and_harden_it_STUDENT.pdf` | 3-6, 8-11 | Put constraints in interfaces/code; bound calls and recovery; assess final outcomes; include negative cases and isolated repeated trials. Applies even with no external write. |
| `class6/PE6201_Class6_C1_How_each_kind_of_AI_breaks_STUDENT.pdf` | 18-21 | Guardrails are proxies, not truth; sample silent failures; human review needs time, evidence and authority; slice results. |
| `class6/PE6201_Class6_C2_What_you_owe_and_how_it_breaks_STUDENT.pdf` | 14-17 | External content is untrusted; prompts alone do not justify a security guarantee; reducing capabilities and halting consumption limits damage. Keep model tools read-only in core. |

## Supporting business and architecture argument

| Local source | Pages | Apply to this project |
| --- | --- | --- |
| `class2/PE6201_Class2_C2_Build_vs_buy.pdf` | 2-3 | Own/rent decisions by layer and business/technical factor; explain ownership of domain policy and renting the foundation model. |
| `class3/PE6201_Class3_C3_Token_economics_and_case.pdf` | 3-5, 14 | Count input/output and repeated calls; additional prompting/repair/repetition has a bill. Use recorded usage rather than unsupported ROI. |
| `class5/PE6201_Class5_C2_What_does_it_actually_cost_STUDENT.pdf` | 4, 16-18, 21, 23 | Distinguish model spend, expected human fallback and fixed costs. Review burden is part of cost; a low token bill is not measured cost per successful task. |
| `class4/PE6201_Class4_C1_What_is_an_agent_STUDENT.pdf` | 9 | Choose the cheapest architecture that meets the observed task. The delivered system is a bounded workflow, with model-guided source selection, not an unrestricted autonomous operator. |
| `class2/PE6201_Class2_C3_RAG.pdf` | 9, 11 | Relevant context and groundedness matter, but the core does not require a vector database. Selective reading of declared attachments is not evidence of implementing a general RAG search engine. |

## Lower priority for this delivery

Class 1 intuition exercises and broad business cases, transformer internals, corporate case narratives, opening/closing decks, online A/B testing and frontier technology surveys are background. They do not justify additional features in the core. A1 notebook/harness instructions and A2 deliverable instructions appearing in lectures are not automatically end-of-course requirements. No need to add training, fine-tuning, vector retrieval, multi-agent orchestration or a new UI merely to cover syllabus terms.

## Concrete experiment mapping

- Structured contracts/source hashes/quote matching: deterministic checks (Class 2 C4 p.4-5; Class 3 C2 p.9-10,15).
- Recipient/currentness/commitment/completeness: explicit semantic rubric and original-source review (Class 2 C4 p.5-6).
- Fixed-code full versus body-only comparison: frozen conditions and a single factor (Class 3 C2 p.13-14).
- Repeat trials and unreadable/ambiguous negatives: isolated trials and safe refusal (Class 4 C2 p.9-11).
- Review rate plus review appropriateness: uncertainty is measured, not merely offered (Class 6 C1 p.18-21; project Watch-outs section 7).
- Cost per email plus human fallback sensitivity: saved variable spend and explicitly unmeasured review time (Class 5 C2 p.21).

The lecture material is an explanation of the course, not independent verification of third-party statistics or current regulations. Check primary sources before making such external factual claims in the final report. This review makes no claim of OWASP/IMDA compliance or certification.
