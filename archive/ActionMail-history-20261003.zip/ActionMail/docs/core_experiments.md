# Core experiments and acceptance protocol

## Historical proposal — superseded after finalization

Updated 3 October 2026. The audit and proposed experiments below are historical. The final executed protocol, results and acceptance scope are [here](../../experiments/PROTOCOL.md); [writing handoff](../../REPORT_HANDOFF.md). Do not execute the old proposed paid commands, interpret them as pending work, or use the old estimated fee/deadline denominator as the final report numbers.


Updated 2 October 2026. Owner scope: core experiments first; real Gmail -> model -> Google Calendar is optional enrichment. Another chat is optimizing the code. This work changes no runtime, prompts, references or frozen experiment records. Proposed implementation changes must be explained to the owner before editing code.

## What counts as success

For a named recipient and the newest work email, propose the current obligations without strengthening the sender's request, preserve explicit supported deadlines, attach inspectable original evidence, and return needs_review when decisive information is unavailable. Local JSON/EML input and CLI execution are sufficient for the core deliverable. Account integration is not an acceptance gate.

Status, task count, semantic correctness, task completeness, deadline correctness and literal quote provenance are separate measurements. Passing one does not establish another. A review is a legitimate outcome on an ambiguous case, but a review on a clear action also counts as a missed action for overall action recall.

## Completed evidence, 2 October

Independent offline replay is under `results/analysis/core-audit-20261002/`. `provenance.json` records the source/runtime hashes and Git HEAD; hashes were unchanged during the audit. The model outputs are the immutable 1 October v2 run, not new inference from the concurrently developing v3 code. Rules were freshly executed using the existing pure `predict_rules` function. Packaging their status into a common analysis representation does not change the rule logic.

| Experiment | Result | Scope |
| --- | --- | --- |
| Active input validation | 60 cases; component hashes verified | Data integrity |
| Existing offline engineering checks | 96/96 pass | Regression/engineering; includes synthetic integration tests |
| Original-source hash replay | 60/60 | Input identity |
| Final quotes matched to locally supplied originals | 129/129 quotes across 60 cases | Provenance, not semantic support |
| Recorded segment hashes replay | 60/60 cases | Identity of recorded spans, not a claim of complete coverage |
| Model status, strict single stored gold | 59/60 | Classification on reused development suite |
| Existing rule status, same strict gold | 31/60 | One-task, body/subject rule with unread-source abstention |
| Always-majority action, strict gold | 27/60 | Majority class baseline |
| Model status, approved outcome alternatives | 60/60 | C11 alternative disclosed |
| Model action count | 60/60 | Count agreement only |

Under strict stored gold, model action precision is 27/28 (96.43%), recall 27/27 (100%), F1 98.18%. Rules are 12/20 (60%), 12/27 (44.44%), F1 51.06%. C11 alone changes the classification conclusion: fixing C11's gold to the approved action interpretation for **both** methods gives model status 60/60 and rules 32/60, with action precision/recall 100%/100% and 65%/46.43%, respectively. This sensitivity analysis does not validate arbitrary alternative C11 task wording.

The comparison is between available systems, not a controlled attribution to source reading or repair. The rules cannot read attachments or produce multiple meaningful tasks, while v2 can. The model suite was reused for tuning. Neither statistical generalization to natural inbox traffic nor a blind held-out claim follows.

Model reviews: 9/60 (15%). Strict gold: review precision 9/9, review recall 9/10; C11 is the unreturned conservative review. With C11 fixed to action, review precision/recall are both 9/9. Rules review 16/60; 2/16 align with review gold and 14 are unnecessary under this contract. These are reference-class measures, not proof that the review signal predicts every semantic error. Among 51 model decisions, strict status correctness is 50/51; report the review rate alongside it.

Cost: USD 0.018384 total, USD 0.0003064/email, 78 calls. Median summed model-call latency is 3.48 seconds/email, mean 4.39, nearest-rank p95 7.58. These are recorded provider-call timings, not end-to-end application response time. User review, storage and development cost are unmeasured. C12/S02 used one successful repair each; these observational traces do not establish a causal repair benefit or universal robustness.

### Deadline denominator discrepancy

With the rule "stored gold is action, a single task is predicted, and a scalar gold deadline exists", replay produces **22/22 field matches: 10 non-null dates and 12 nulls**. Restricting to absent or resolvable deadline kinds produces 20/20, with the same 10 non-null dates. Existing documentation says 23/23; this audit cannot reproduce that denominator under the stated rule. C11 is predicted action but has review gold and null; including it needs an explicitly defined alternative action deadline reference. Do not put 23 successful date extractions in the report. Keep original files intact and resolve this discrepancy with the code/report owner before finalizing claims.

## Next experiments, after the code is frozen

The following are predeclared experiments, **not completed results**. Freeze the model, prompt, code hash, input hashes, references and scoring policy before inference. Use public/authored inputs only, fresh output directories and separately authorized paid calls. Do not resume against a different code/prompt snapshot. Do not run experiments while the other chat is changing the code.

### E1. Final full-core regression

Run all 60 cases once with v2 schema and snapshot/actual-attachment reading on the final code. Preserve the approved A16/C11 rules. Score the same metrics as this audit, slice by scenario and real-derived/authored origin, and compare disagreements with the saved v2 run. This validates the final code; it remains a regression experiment, not held-out generalization.

Existing command, run only after paid approval:

```powershell
python -m actionmail.evaluation.cli --benchmark v2-60 --schema v2 --external-mode snapshots --model openai/gpt-6-luna --output-dir results/evaluation/core-final-full-NEWID
```

### E2. External-context ablation

Run the same 60 inputs with the same final code/model/v2 prompt and body-only mode. Keep newest-message headers and available historical thread context the same. Only attachment/link reading is disabled. Score against the unchanged full-information references and identify cases where disabled required reading appropriately produces review. Compare overall recall, review burden and saved cost; slice the 10 base external cases and 10 supplements separately. This asks whether external context improves resolution, not whether cautious refusal is a safety defect. Token counts and trajectories necessarily differ between arms.

```powershell
python -m actionmail.evaluation.cli --benchmark v2-60 --schema v2 --external-mode body-only --model openai/gpt-6-luna --output-dir results/evaluation/core-final-body-NEWID
```

The current CLI already supports both modes; this experiment requires no source edit. E1 must be a fresh paired arm: a historical run on different code is not the controlled comparator.

### E3. Repeatability on eight preselected cases

Select N01 (informational), A23 (relative deadline), A16 (two tasks), C11 (ownership ambiguity), E01 (attachment), S01 (long content), S02 (quote repair) and S08 (malformed workbook). Run three fresh snapshot trials each: 24 email analyses, separate outputs/stores, no cached inference. Three batches can each select the same eight `--case-id` arguments. Measure status/count agreement, semantic differences, invalid/unseen quotes, supported dates, repair/read-failure behavior, call count, cost and latency. A successful first trial does not substitute for repeatability.

### E4. Semantic review and missing-task audit

`semantic_review.csv` contains all 60 cases with expected/predicted outcomes and deliberately blank reviewer fields. The reviewer must read original source material, including thread and decisive attachments, rather than just the cited spans. The current review UI can display original materials without new inference. An AI-assisted review may propose flags but must be labelled as such and must not populate owner Pass judgments.

Use binary criteria with reasons: (1) ownership/currentness correct; (2) requested commitment preserved; (3) all independently completable obligations represented; (4) explicit dates faithful and unknown dates null; (5) evidence actually supports the meaning; (6) review/no-action appropriate. Match task units by meaning, one-to-one. Task precision = matched supported proposed tasks / proposed tasks; task recall = matched expected tasks / expected tasks, counting review/error as missed tasks on answerable cases. Report false additions and omissions separately. Expected-task references must be fixed before reviewing new outputs. Any proposed reference amendment requires owner adjudication and preserved original scores.

An aligned LLM judge would require separately labelled human examples and measured agreement. No judge API or calibration code is needed merely to complete human review; do not build one unless the owner requests it.

### E5. Generalization, if time and independently reviewed labels are available

Prepare 20 unused public/email cases: five informational, five direct requests, five context/ownership cases and five source-dependent or genuinely unavailable-content cases. Category selection is not the answer label. Disclose real versus authored origins. A reviewer other than the prompt-tuning agent defines outcome conditions before inference; freeze labels and hashes. Run once after final code freeze and do not tune on these cases. If a failure leads to tuning, report the original result and classify subsequent runs as development. Twenty cases give coarse evidence; report numerator/denominator and do not imply population certainty. This set is not built or run yet and cannot be invented from the existing tuned 60.

## Proposed project acceptance criteria

These are project targets for future evaluation, not instructor-mandated numbers and not retroactively predeclared for the saved run.

| Gate | Proposed criterion | Evidence / current status |
| --- | --- | --- |
| Reproducible local core | Documented install; included JSON/EML input reaches structured output without accounts; explicit external-corpus setup | Final clean-checkout verification pending |
| Classification | >=90% action precision and >=90% recall; all three classes and per-category counts reported; exceeds same-set rules/majority | Saved regression supports this; final paired run pending |
| Task meaning and omissions | >=90% semantic task precision and >=90% task recall; owner-reviewed matching with reasons | Pending E4; no automatic Pass claim |
| Deadline quality | >=90% supported non-null deadline accuracy, zero invented dates on designated missing-anchor cases; nulls reported separately | 10/10 comparable non-null fields observed; broader review pending |
| Evidence gate | All released quotes match actually supplied original sources; deliberately altered/unseen evidence is rejected or revalidated once | Offline replay and existing engineering tests pass |
| Safe uncertainty | Required unreadable source, unknown ownership and more-than-three-task cases produce review; report review precision/recall and burden | Fixture/regression evidence; semantics separately reviewed |
| Bounded workflow | At most one validation repair/email; configured source/input limits enforced; failures visible | Existing engineering checks, recorded repair traces |
| Repeatability | >=90% case groups have stable accepted status/count across three trials; every safety-negative trial safe | Pending E3; denominator eight groups and 24 trials stated |
| Cost / latency | Proposed model-cost mean <=USD 0.002/email; median summed calls <=10 seconds and p95 <=20 seconds on this suite | Saved result below targets; final run pending; not a production SLA |
| Communication | Report <=1,200 words; video/report/code identify the same final commit, data and limitations | Final hand-in work pending |

Do not make genuine-account OAuth or Calendar writes a core gate. Failure to meet a target is an experimental finding: document and prioritize the failure rather than change labels or silently weaken criteria. If fresh independent evaluation is omitted, explicitly limit the final claim to the development/regression suite.

## Paid scope for owner decision

E1 + E2 + E3 = **144 email analyses** (not 144 API calls; full context may require several calls). At the saved full-run mean, a rough allowance is USD 0.0441; actual cost depends on current prices, input length and repairs. Request a conservative **USD 0.20 maximum planned spend**, with fresh preflight pricing before starting and no private mail. This is a planning cap, not an implemented hard billing limit. Preflight estimates are not a guarantee. If existing controls cannot enforce the intended bound, stop or split into bounded batches; explain any needed budget-control code before editing it. E5 would need separately frozen independent labels and is outside this 144-analysis request.

## Report and demo evidence

Report: one persona/problem -> why rules versus rented model -> owned normalization/source/evidence/review controls -> data and paired experiment results -> measured cost plus unmeasured human fallback -> limitations. Use strict single-reference numbers alongside the C11 sensitivity; disclose repeated tuning and authored data. Keep the deadline discrepancy visible until resolved.

Core demo: one direct request with exact source; one thread/ownership example; one attachment-dependent action; one malformed/missing-source refusal; one saved evidence-repair trace. Show the actual core version and distinguish a new live model call from replaying saved replies. CLI is sufficient. Demonstrate user edits/rejection only as local application engineering evidence. Optional calendar export/integration can follow after the scientific result, without replacing it.
