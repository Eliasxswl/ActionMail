# PE6201 report writing guide

Updated 3 October 2026. This is the existing report guide, updated in place after experiment finalization; it is not another report draft. Start with the [final writing handoff](../../REPORT_HANDOFF.md), then the [sole detailed experiment report](../../experiments/REPORT.md) and [final protocol](../../experiments/PROTOCOL.md).

## Submission requirements and source authority

Read the originals in [course/](course/README.md). The project is individual; write in the first person and distinguish implemented, measured, demonstrated and proposed work.

| Original source | Requirement / verified point |
| --- | --- |
| `PE6201_Assessment_Timeline.pdf`, p.1 | End-of-course project is 44% of the course grade. Submit problem statement, business/technical trade-off analysis capped at 1,200 words, working code in GitHub, and a recorded presentation/demo; NTULearn unless another brief applies. |
| `PE6201_Project_Proposal_Watchouts (1).pdf`, pp.1–3 | Rubric: problem/significance 15%, trade-offs 25%, implementation/code 35%, demonstration/communication 25%. Name a baseline, dataset and measured target; reason about own/rent by layer, costs, limitations and mitigations; another person should be able to run the repository. Low-code is optional. |
| `PE6201_Project_Problem_Statement_Template (1).docx` | Formative problem-statement milestone, approximately one page. The template calls the smallest first version optional, while later Watchouts requires it. |
| `PE6201_Project_Problem_Statement_ZHANGPEIQ.pdf`, pp.1–3 | Submitted initial plan: workplace-action extraction, contextual reading, user confirmation, rented model, initially UiPath and email/calendar OAuth. This is the proposal, not proof of delivered integration. |
| Owner-reported feedback / extension | Owner reports a 4 October extension and requests concerning case/category counts, authored attachments/links and the UiPath versus own-orchestration decision. The original feedback message is absent locally; attribute this to the owner. |

The original timeline has an older September deadline. Exact extended cutoff, video length, whether references/appendices count within 1,200 words, and final upload naming remain unconfirmed. Do not invent these. Three notebooks belong to A1, not automatically to this final project. Keep a conservative word count including captions/tables until exceptions are confirmed.

## Final scope and single output

The user finalized core experiments on 3 October. Real Gmail → model → Google Calendar remains optional enrichment; CLI is foundational and GUI is an optional demonstration aid. Python owns the bounded workflow; UiPath integration is not implemented. Do not resume development or new paid experiments for the report.

Maintain one course report, recommended `../../report/FINAL_REPORT.md`, revising in place. The experiment REPORT is supporting evidence, not the 1,200-word submission. Cite data origins, disclose Codex assistance and label synthetic demonstrations. If figures are useful, keep them together under `../../report/figures/` rather than creating more report versions.

## Recommended argument and word budget

Main argument: a bounded, inspectable workflow extracts current obligations for a named recipient, and evaluation shows how context, source selection, validation and model choice affect quality, latency and actual service spend. The cross-model study is a core result, not merely a way to select GPT. Present differences as workflow/provider outcomes, not universal model-family intelligence rankings.

| Section | Suggested words | Evidence to develop |
| --- | ---: | --- |
| Problem and success criteria | 140 | Recipient-specific current obligations; risk of missed/overstated tasks; human-confirmed proposals |
| Business and technical trade-offs | 300 | Rules versus one call versus bounded workflow; own domain policies/rent model; Python rather than initial UiPath plan |
| Implemented workflow | 180 | Source planning, bounded reading, original evidence, shared repair allowance, explicit review |
| Data and measured findings | 280 | Development dataset, six-model comparison, two-model ablations, cost/latency and failure slices |
| Limitations and next steps | 180 | Data reuse, AI review, provider/format effects, unmeasured human effort, deferred real integration |
| Caption/reference/transitional headroom | 120 | Count conservatively; total at most 1,200 |

This is a writing recommendation, not an instructor-mandated section format. Prioritize decisions and evidence; omit generic AI history, development chronology and long lists of libraries. A compact quality/cost comparison or workflow diagram can help, but figures are not required by the located brief.

## Current evidence map

| Claim | Authority | Defensible interpretation |
| --- | --- | --- |
| Implemented core/application | `architecture.md`, `../src/actionmail/`, `v3_demo.md` | v2 decision contract on frozen c405d29; local v3 application exists, package remains development-versioned |
| Data and reference policy | `../../experiments/data/frozen-core/`, `../evaluation/annotation_policy.md` | 60 reused development/regression cases; A16/C11 amendments disclosed |
| Origins | Frozen dataset `origin` | 33 MailEx threads + 1 Enron export; 19 authored JSON + 7 authored EML: 34 existing-email-derived, 26 authored |
| External inventory | Frozen dataset `email.external_sources` | 20 per-case source entries across 17 cases: 13 attachments, 7 links; see handoff for authored/byte/snapshot distinctions |
| Current rule baseline | `../../experiments/results/rules-baseline/summary.json` | 31/60 strict status, 32/60 allowed interpretation; pure body/subject rules lack equivalent external/multi-task capability |
| Six-model experiment | `../../experiments/REPORT.md`, sections 2–10 | 360 observations, frozen initial payload except model; end-to-end compatibility is part of results |
| Mechanism comparisons | Same report section 11 and ablation results | 500 observations, two models; compare only shared case IDs; prompt baseline changes multiple components |
| Semantic review | Same report section 12; ablation semantic CSV/JSON | 500 explicitly attributed Codex AI reviews anchored to saved owner decisions, not independent human review |
| Actual cost | Billing counter deltas, ablation generation bills, `../../experiments/results/billing_clarification.json` | USD 3.224528503 total; ablation 579/579 bills reconciled; benchmark one missing bill retained |
| Latency and tokens | Stage `operations.json`, case/turn CSVs | Per-case wall-clock includes workflow/network; accounting overhead separate; not decode speed or inbox-to-calendar latency |
| Demo and Google boundary | `v3_demo.md`, `google_integrations.md` | Offline scripted integration verification and ICS; real-account connectivity unverified |
| Lesson mapping | `course_relevance.md` | Exact lecture pages for evaluation, own/rent, bounded recovery, proxy guardrails and total cost |

Use full model names, not full_m01-style internal IDs in the submission. Main model-selection recommendation is low-cost GPT-6 Luna plus Claude Sonnet 5.5 as a cross-family comparator; Sol and Google/GLM supply the benchmark trade-offs. Do not present a one-point difference as a statistically established ranking.

## Numerical traps to avoid

Strict status, accepted status/count, task-unit precision/recall and semantic delivery are different. The fresh full ablation is Luna 58/60 and Sonnet 59/60 strict; semantic delivery is 59/60 and 60/60 under the disclosed rubric; task units matched are 31/32 and 32/32. C11 was allowed before the experiment. Sonnet C10 is less specific; task-kind differences are separately flagged. Avoid a perfect-accuracy headline.

One repair allowance is shared across each email's planning/extraction/merge. C12 shows improved explanation/evidence even when status remains review; E07 shows correct task content rejected for malformed JSON. Independent first responses differ between full/no-repair runs, so current totals do not isolate a pure causal repair benefit. The three repeats on eight preselected cases are 24 observations, not 24 independent cases.

The six-model semantic review is not exhaustive. Gemini's fenced JSON and GLM's output/reasoning budget explain important workflow failures, not a universal loss of reading ability. Exact original quotes establish provenance, not task completeness, faithful paraphrase or general security.

Final model spend is measured using before/after usage counters, not price × tokens. For the complete ablation arms, Luna costs USD 0.013394660 / 60 = about USD 0.000223 per case; Sonnet USD 0.480094000 / 60 = about USD 0.008002. They are model-service costs only. Do not claim hours saved, ROI or total operational cost without measurements.

Benchmark billing clarification: original frozen derived tables include Sonnet C12's unaudited response usage cost of USD 0.006810, making the old Sonnet subtotal USD 0.475764. Generation-verified subtotal is USD 0.468954 with one bill missing; the main experiment report explains this correction and preserves the raw files. Total usage-counter cost is unchanged. Do not quote every `known_billed_cost_usd` field as fully audited actual spend.

The old October 1 run's USD 0.018384 estimate, summed-call median 3.48 s and 60/60 accepted match are historical development evidence, not the final experiment headline. Old 26/50 rules and 37/50 model figures use an older reference contract. The old 23/23 deadline denominator was challenged by later replay; do not reuse it or call null fields successful date extraction.

## Business, governance and limitations

Own normalization, recipient/currentness rules, evidence validation, bounded tools, review and evaluation; rent foundation-model inference. Explain why no training, vector database or unrestricted agent loop is necessary. Low-cost inference is not the same as low human fallback burden. Model quality, interface stability, reading exposure and spend are joint trade-offs.

Required disclosures: reused cases and original Luna tuning; 26 authored cases and explicit received-time anchors only where authored/known; saved owner judgments versus current AI review; private data/provider transmission limits; unsupported sources; one hostile fixture does not prove comprehensive prompt-injection resistance. Do not claim framework certification or compliance by name alone.

Future work is independent test data/human review, fixed-first-answer replay, forced-JSON transport, and optional live Google integration. Calendar writes require reviewed drafts and explicit confirmation; default demo writes are simulated. No real mailbox monitoring, reply sending or external task execution has been demonstrated.

## References and hand-in checks

Use MailEx's actual paper and source repository to credit provenance, distinguishing its event-extraction task from this project's recipient/action policy. The handoff supplies source links and counts; verify any formal external citation against the primary source before submission. Course documents are local-only; do not publish their text or the corpus indiscriminately.

Before finishing: verify word count; trace every numerical claim to its correct stage/denominator; make report/code/video describe the same version; label demo simulations; acknowledge AI assistance; preserve limits; exclude keys/private records/archive; identify unconfirmed submission rules. The workspace root is not Git: experiments lie outside the ActionMail repository, so pushing ActionMail alone will not publish the experiment package. Packaging/publishing is the owner's next action, not authorization for the writing Agent to commit or deploy.
